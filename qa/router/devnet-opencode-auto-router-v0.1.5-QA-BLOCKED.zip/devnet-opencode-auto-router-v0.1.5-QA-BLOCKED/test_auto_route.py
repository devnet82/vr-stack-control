import unittest
import tempfile
from pathlib import Path
from unittest.mock import patch, MagicMock
import auto_route

class SelectionTests(unittest.TestCase):
    def test_coding_terms(self):
        for task in ['Debug this Python function','Refactor my code','Implement API endpoint','Fix the script','Build a plugin','Write unit tests','Review repository']:
            with self.subTest(task=task):
                self.assertEqual(auto_route.select_model(task), auto_route.CODER)
    def test_reported_classification_failures(self):
        for task in ['Fix this failing test','Investigate my application crash',
                     'Review this diff','Write a shell command',
                     'Create a C# application','Help me with SQL query']:
            with self.subTest(task=task):
                self.assertEqual(auto_route.select_model(task), auto_route.CODER)
    def test_guard_against_general_misrouting(self):
        for task in ['Review this meeting agenda','Create a shopping list',
                     'Explain why the sky is blue','Write an email about an application']:
            with self.subTest(task=task):
                self.assertEqual(auto_route.select_model(task), auto_route.DEFAULT)
    def test_general_terms(self):
        for task in ['Summarise the meeting', 'Explain quantum mechanics', 'Write a polite email', 'Plan a meal']:
            with self.subTest(task=task):
                self.assertEqual(auto_route.select_model(task), auto_route.DEFAULT)
    def test_no_shell_and_correct_selection(self):
        with patch.object(auto_route, 'gaming_active', return_value=False), patch.object(auto_route, 'loaded_models', return_value=[]), patch.object(auto_route, 'execute_task', return_value=0) as run:
            self.assertEqual(auto_route.main(['Debug this Python function']), 0)
            run.assert_called_once_with(auto_route.CODER, 'Debug this Python function')
    def test_conflicting_model_blocks(self):
        with patch.object(auto_route, 'gaming_active', return_value=False), patch.object(auto_route, 'loaded_models', return_value=['qwen3.5:9b']), patch.object(auto_route, 'execute_task') as run:
            self.assertEqual(auto_route.main(['Debug this Python function']), 2)
            run.assert_not_called()
    def test_same_model_permitted(self):
        with patch.object(auto_route, 'gaming_active', return_value=False), patch.object(auto_route, 'loaded_models', return_value=['qwen3-coder:30b']), patch.object(auto_route, 'execute_task', return_value=0):
            self.assertEqual(auto_route.main(['Debug this Python function']), 0)
    def test_no_ollama_blocks(self):
        with patch.object(auto_route, 'gaming_active', return_value=False), patch.object(auto_route, 'loaded_models', side_effect=TimeoutError), patch.object(auto_route, 'execute_task') as run:
            self.assertEqual(auto_route.main(['Debug this Python function']), 2)
            run.assert_not_called()
    def test_dry_run_does_not_access_ollama(self):
        with patch.object(auto_route, 'gaming_active', return_value=False), patch.object(auto_route, 'loaded_models') as loaded:
            self.assertEqual(auto_route.main(['--dry-run', 'Write a Python function']), 0)
            loaded.assert_not_called()
    def test_empty_task_rejected(self):
        with self.assertRaises(SystemExit):
            auto_route.main([' '])

if __name__ == '__main__': unittest.main()

class ManagedNativeTests(unittest.TestCase):
    def test_native_mode_routes_with_other_model_loaded(self):
        with patch.object(auto_route, 'gaming_active', return_value=False), patch.object(auto_route, 'loaded_models', return_value=['qwen3-coder:30b']), \
             patch.object(auto_route, 'execute_task', return_value=0) as run:
            self.assertEqual(auto_route.main(['--managed-native', 'Explain why the sky is blue']), 0)
            self.assertEqual(run.call_args.args[0], auto_route.DEFAULT)

    def test_native_mode_does_not_force_unload(self):
        with patch.object(auto_route, 'gaming_active', return_value=False), patch.object(auto_route, 'loaded_models', return_value=['qwen3-coder:30b']), \
             patch.object(auto_route, 'execute_task', return_value=0), \
             patch.object(auto_route.urllib.request, 'urlopen') as urlopen:
            self.assertEqual(auto_route.main(['--managed-native', 'Explain the weather']), 0)
            urlopen.assert_not_called()

    def test_native_lock_blocks_overlap(self):
        with auto_route.router_lock():
            with self.assertRaisesRegex(RuntimeError, 'Another router task'):
                with auto_route.router_lock():
                    pass

    def test_opencode_error_propagates(self):
        with patch.object(auto_route, 'gaming_active', return_value=False), patch.object(auto_route, 'loaded_models', return_value=[]), \
             patch.object(auto_route, 'execute_task', return_value=13):
            self.assertEqual(auto_route.main(['--managed-native', 'Debug Python']), 13)

import contextlib

class LockOrderTests(unittest.TestCase):
    def test_residency_check_occurs_inside_lock(self):
        events = []
        @contextlib.contextmanager
        def ordered_lock():
            events.append('lock_acquired')
            try:
                yield
            finally:
                events.append('lock_released')
        def check():
            events.append('residency_checked')
            return []
        def run(*args, **kwargs):
            events.append('opencode_executed')
            return 0
        with patch.object(auto_route, 'gaming_active', return_value=False), patch.object(auto_route, 'router_lock', ordered_lock), patch.object(auto_route, 'loaded_models', check), patch.object(auto_route, 'execute_task', run):
            self.assertEqual(auto_route.main(['--managed-native', 'Debug Python']), 0)
        self.assertEqual(events, ['lock_acquired', 'residency_checked', 'opencode_executed', 'lock_released'])

    def test_busy_lock_never_checks_or_launches(self):
        @contextlib.contextmanager
        def busy_lock():
            raise RuntimeError('Another router task is running')
            yield
        with patch.object(auto_route, 'router_lock', busy_lock), patch.object(auto_route, 'loaded_models') as check, patch.object(auto_route, 'execute_task') as run:
            self.assertEqual(auto_route.main(['--managed-native','Debug Python']), 2)
            check.assert_not_called()
            run.assert_not_called()

    def test_guard_blocks_while_lock_held(self):
        with patch.object(auto_route, 'gaming_active', return_value=False), patch.object(auto_route, 'loaded_models', return_value=['qwen3.5:9b']), patch.object(auto_route, 'execute_task') as run:
            self.assertEqual(auto_route.main(['Debug Python']), 2)
            run.assert_not_called()

    def test_native_mode_does_not_unload_any_model(self):
        with patch.object(auto_route,'gaming_active',return_value=False), \
             patch.object(auto_route,'loaded_models',return_value=['qwen3.5:9b']), \
             patch.object(auto_route,'execute_task',return_value=0) as task, \
             patch.object(auto_route.urllib.request,'urlopen') as http:
            self.assertEqual(auto_route.main(['--managed-native','Debug Python']),0)
            task.assert_called_once()
            http.assert_not_called()



class GamingSafetyTests(unittest.TestCase):
    def test_manual_pause_blocks(self):
        with tempfile.TemporaryDirectory() as directory:
            root=Path(directory); (root/'gaming-on').touch()
            with patch.object(auto_route,'PAUSE',root/'gaming-on'), patch.object(auto_route,'STOP',root/'stop-all'):
                self.assertTrue(auto_route.gaming_active())

    def test_manual_stop_blocks(self):
        with tempfile.TemporaryDirectory() as directory:
            root=Path(directory); (root/'stop-all').touch()
            with patch.object(auto_route,'PAUSE',root/'gaming-on'), patch.object(auto_route,'STOP',root/'stop-all'):
                self.assertTrue(auto_route.gaming_active())

    def test_detector_missing_blocks(self):
        with tempfile.TemporaryDirectory() as directory:
            root=Path(directory)
            with patch.object(auto_route,'PAUSE',root/'gaming-on'), patch.object(auto_route,'STOP',root/'stop-all'), patch.object(auto_route,'AGENT_FILE',root/'missing-agent.py'):
                self.assertTrue(auto_route.gaming_active())

    def test_game_blocks_before_residency(self):
        with patch.object(auto_route, 'gaming_active', return_value=True), patch.object(auto_route, 'loaded_models') as check, patch.object(auto_route, 'execute_task') as run:
            self.assertEqual(auto_route.main(['--managed-native','Debug Python']),2)
            check.assert_not_called()
            run.assert_not_called()

    def test_game_blocks_before_spawn(self):
        with patch.object(auto_route, 'gaming_active', return_value=True), patch.object(auto_route.subprocess, 'Popen') as spawn:
            self.assertEqual(auto_route.execute_task(auto_route.CODER, 'Debug Python'),2)
            spawn.assert_not_called()

    def test_game_transition_stops_only_owned_process_group(self):
        process = MagicMock(pid=717171)
        process.poll.side_effect = [None, None, None]
        with patch.object(auto_route, 'gaming_active', side_effect=[False, True]), patch.object(auto_route.subprocess, 'Popen', return_value=process) as popen, patch.object(auto_route.os, 'killpg') as kill:
            self.assertEqual(auto_route.execute_task(auto_route.CODER, 'Debug Python'),2)
            popen.assert_called_once()
            self.assertTrue(popen.call_args.kwargs['start_new_session'])
            kill.assert_called_once_with(717171, auto_route.signal.SIGTERM)

    def test_completed_process_exit_propagates(self):
        process = MagicMock(pid=717171)
        process.poll.return_value = 13
        with patch.object(auto_route, 'gaming_active', return_value=False), patch.object(auto_route.subprocess, 'Popen', return_value=process):
            self.assertEqual(auto_route.execute_task(auto_route.CODER, 'Debug Python'),13)


class SessionAndCheckpointTests(unittest.TestCase):
    def test_session_id_is_forwarded(self):
        cmd=auto_route.command_for_task(auto_route.CODER,'Fix this bug',session_id='ses_abcd1234')
        self.assertEqual(cmd, ['/usr/bin/opencode','run','--model',auto_route.CODER,'--session','ses_abcd1234','Fix this bug'])

    def test_continue_session_supported(self):
        self.assertIn('--continue',auto_route.command_for_task(auto_route.DEFAULT,'Summarise',continue_session=True))

    def test_no_implicit_continuation(self):
        cmd=auto_route.command_for_task(auto_route.DEFAULT,'Summarise')
        self.assertNotIn('--continue',cmd)
        self.assertNotIn('--session',cmd)

    def test_session_validation_rejects_injection(self):
        for candidate in ['--help','a/b','ses_x ; rm -rf /','ses_','ses_x\nfoo']:
            with self.subTest(candidate=candidate),self.assertRaises(ValueError):
                auto_route.command_for_task(auto_route.DEFAULT,'hello',session_id=candidate)

    def test_session_mode_exclusive(self):
        with self.assertRaises(ValueError):
            auto_route.command_for_task(auto_route.DEFAULT,'hello',session_id='ses_abcde',continue_session=True)

    def test_session_option_reaches_executor(self):
        with patch.object(auto_route,'gaming_active',return_value=False),patch.object(auto_route,'loaded_models',return_value=[]),patch.object(auto_route,'execute_task',return_value=0) as runner:
            self.assertEqual(auto_route.main(['--session-id','ses_abcde','Review Python code']),0)
            runner.assert_called_once_with(auto_route.CODER,'Review Python code',session_id='ses_abcde',continue_session=False)

    def test_dry_run_has_no_state(self):
        with patch.object(auto_route,'record_task_state') as writer,patch.object(auto_route,'loaded_models') as loader:
            self.assertEqual(auto_route.main(['--dry-run','--continue-session','Debug Python']),0)
            writer.assert_not_called(); loader.assert_not_called()

    def test_private_durable_checkpoint(self):
        with tempfile.TemporaryDirectory() as d,patch.object(auto_route,'STATE_DIR',Path(d)/'router'):
            auto_route.record_task_state('COMPLETE',auto_route.CODER,'Super secret request',exit_code=0,session_id='ses_abcd')
            file=auto_route.STATE_DIR/'latest.json'
            data=file.read_text()
            self.assertNotIn('Super secret',data)
            self.assertEqual(auto_route.json.loads(data)['status'],'COMPLETE')
            self.assertEqual(file.stat().st_mode & 0o777,0o600)
            self.assertEqual(auto_route.STATE_DIR.stat().st_mode & 0o777,0o700)
            self.assertFalse(auto_route.json.loads(data)['release_approved'])

    def test_checkpoint_refuses_symlink_directory(self):
        with tempfile.TemporaryDirectory() as d:
            root=Path(d); (root/'real').mkdir(); (root/'link').symlink_to(root/'real',target_is_directory=True)
            with patch.object(auto_route,'STATE_DIR',root/'link'),self.assertRaises(RuntimeError):
                auto_route.record_task_state('STARTING',auto_route.CODER,'test')

    def test_checkpoint_refuses_public_directory(self):
        with tempfile.TemporaryDirectory() as d:
            root=Path(d); path=root/'public'; path.mkdir(mode=0o755); path.chmod(0o755)
            with patch.object(auto_route,'STATE_DIR',path),self.assertRaises(RuntimeError):
                auto_route.record_task_state('STARTING',auto_route.CODER,'test')

    def test_checkpoint_refuses_symlink_file(self):
        with tempfile.TemporaryDirectory() as d:
            root=Path(d); root.chmod(0o700); (root/'victim').write_text('intact'); (root/'latest.json').symlink_to(root/'victim')
            with patch.object(auto_route,'STATE_DIR',root),self.assertRaises(RuntimeError):
                auto_route.record_task_state('STARTING',auto_route.CODER,'test')
            self.assertEqual((root/'victim').read_text(),'intact')

    def test_real_executor_exit_checkpoint(self):
        with tempfile.TemporaryDirectory() as d,patch.object(auto_route,'STATE_DIR',Path(d)/'router'),patch.object(auto_route,'gaming_active',return_value=False):
            with patch.object(auto_route.subprocess,'Popen') as spawn:
                proc=spawn.return_value; proc.poll.return_value=0
                self.assertEqual(auto_route.execute_task(auto_route.DEFAULT,'Explain physics',continue_session=True),0)
                self.assertIn('--continue',spawn.call_args.args[0])
                self.assertEqual(auto_route.json.loads((auto_route.STATE_DIR/'latest.json').read_text())['status'],'COMPLETE')

    def test_game_pre_spawn_no_checkpoint(self):
        with patch.object(auto_route,'gaming_active',return_value=True),patch.object(auto_route,'record_task_state') as write:
            self.assertEqual(auto_route.execute_task(auto_route.CODER,'Debug Python'),2)
            write.assert_not_called()


class AdditionalFailClosedTests(unittest.TestCase):
    def test_spawn_failure_checkpoint(self):
        with tempfile.TemporaryDirectory() as d,patch.object(auto_route,'STATE_DIR',Path(d)/'router'),patch.object(auto_route,'gaming_active',return_value=False),patch.object(auto_route.subprocess,'Popen',side_effect=OSError('cannot execute')):
            with self.assertRaises(OSError):
                auto_route.execute_task(auto_route.CODER,'Debug code')
            data=auto_route.json.loads((auto_route.STATE_DIR/'latest.json').read_text())
            self.assertEqual(data['status'],'LAUNCH_FAILED')
            self.assertFalse(data['release_approved'])

    def test_foreign_lock_permissions_block(self):
        with tempfile.TemporaryDirectory() as d:
            lock=Path(d)/'lock'; lock.write_text(''); lock.chmod(0o666)
            with patch.object(auto_route,'LOCKFILE',lock),self.assertRaises(RuntimeError):
                with auto_route.router_lock(): pass

    def test_game_transition_checkpoint(self):
        with tempfile.TemporaryDirectory() as d,patch.object(auto_route,'STATE_DIR',Path(d)/'router'),patch.object(auto_route,'gaming_active',side_effect=[False,True]),patch.object(auto_route.os,'killpg'):
            with patch.object(auto_route.subprocess,'Popen') as spawn:
                proc=spawn.return_value; proc.pid=123456; proc.poll.return_value=None
                self.assertEqual(auto_route.execute_task(auto_route.CODER,'Debug code'),2)
                data=auto_route.json.loads((auto_route.STATE_DIR/'latest.json').read_text())
                self.assertEqual(data['status'],'PAUSED_INTERRUPTED')
                self.assertFalse(data['release_approved'])
