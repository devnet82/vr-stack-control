#!/usr/bin/env python3
"""Conservative OpenCode model router with opt-in managed handover."""
import argparse
import hashlib
import tempfile
import contextlib
import fcntl
from pathlib import Path
import json
import os
import re
import subprocess
import sys
import time
import signal
import importlib.util
import urllib.request
import urllib.error

DEFAULT = 'ollama/qwen3.5:9b'
CODER = 'ollama/qwen3-coder:30b'
CODE_TERMS = re.compile(r'\b(code|coding|program|programming|python|javascript|typescript|rust|c\+\+|bash|fish\s+shell|script|function|class|debug|bug|fix\s+(?:the\s+)?(?:code|script|app|program)|refactor|compile|build\s+(?:an?\s+)?(?:app|program|plugin)|repository|repo|unit\s+tests?|integration\s+tests?|pull\s+request|git\s+commit|api\s+endpoint|implement|failing\s+tests?|application\s+crash|app\s+crash|stack\s*trace|review\s+(?:this\s+)?diff|diff|shell\s+commands?|c#|csharp|sql\s+quer(?:y|ies)|fix\s+(?:this\s+)?failing\s+test|investigate\s+(?:my\s+)?application\s+crash)\b', re.I)

def select_model(task):
    return CODER if (CODE_TERMS.search(task) or re.search(r'\bc#(?=\s|$)', task, re.I)) else DEFAULT

def loaded_models():
    req = urllib.request.Request('http://127.0.0.1:11434/api/ps')
    with urllib.request.urlopen(req, timeout=5) as response:
        data = json.load(response)
    if not isinstance(data, dict) or not isinstance(data.get('models', []), list):
        raise RuntimeError('Unexpected Ollama response')
    return [m['name'] for m in data['models'] if isinstance(m, dict) and isinstance(m.get('name'), str)]

# Advisory lock coordinates router invocations, not independent Ollama clients.
LOCKFILE = Path('/tmp/devnet-opencode-auto-router-' + str(os.getuid()) + '.lock')
STATE_DIR = Path.home() / '.local/state/devnet-model-router'



# The existing QA detector is the policy source for Steam/Proton/VRChat/WiVRn.
# Missing/unreadable detector, procfs errors, or malformed status => BLOCK.
AGENT_FILE = Path.home() / '.local/lib/devnet-qa-automation/agent.py'
PAUSE = Path.home() / '.config/devnet-qa-automation/gaming-on'
STOP = Path.home() / '.config/devnet-qa-automation/stop-all'

def gaming_active():
    if PAUSE.exists() or STOP.exists():
        return True
    try:
        if not AGENT_FILE.is_file() or AGENT_FILE.is_symlink():
            return True
        spec = importlib.util.spec_from_file_location('devnet_existing_game_detector', AGENT_FILE)
        if spec is None or spec.loader is None:
            return True
        agent = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(agent)
        result = agent.gaming_now()
        if type(result) is not bool:
            return True
        if result:
            return True
        # Supplement the shared detector with WayVR, which it does not name.
        # SlimeVR may idle in the background; do not call it an active VR session.
        proc = Path('/proc')
        if not proc.is_dir():
            return True
        for entry in proc.iterdir():
            if not entry.name.isdigit():
                continue
            try:
                name = (entry / 'comm').read_text(errors='replace').strip().lower()
            except (PermissionError, FileNotFoundError, ProcessLookupError):
                continue
            if name in {'wayvr', 'wayvr-bin'}:
                return True
        return False
    except Exception:
        return True

def stop_owned_process(proc):
    # A fresh session isolates the spawned OpenCode process group; no global pkill.
    if proc.poll() is not None:
        return
    try:
        os.killpg(proc.pid, signal.SIGTERM)
        proc.wait(timeout=5)
    except subprocess.TimeoutExpired:
        os.killpg(proc.pid, signal.SIGKILL)
        proc.wait(timeout=5)
    except ProcessLookupError:
        pass

def command_for_task(model, task, *, session_id=None, continue_session=False):
    """Explicit OpenCode session handover; never invent a session id."""
    if session_id and continue_session:
        raise ValueError('Choose --session-id or --continue-session, not both')
    cmd = ['/usr/bin/opencode', 'run', '--model', model]
    if session_id:
        if not re.fullmatch(r'ses_[A-Za-z0-9_-]{4,128}', session_id):
            raise ValueError('Invalid OpenCode session id')
        cmd += ['--session', session_id]
    elif continue_session:
        cmd += ['--continue']
    return cmd + [task]


def record_task_state(status, model, task, *, exit_code=None, session_id=None):
    """Durable, private metadata only; no prompt or secret content."""
    STATE_DIR.mkdir(mode=0o700, parents=True, exist_ok=True)
    if STATE_DIR.is_symlink() or STATE_DIR.stat().st_mode & 0o077:
        raise RuntimeError('Unsafe router state directory permissions')
    state_file = STATE_DIR / 'latest.json'
    if state_file.is_symlink():
        raise RuntimeError('Refusing symlinked state file')
    payload = {'schema':'devnet-router-checkpoint-v1','status':status,'model':model,
               'task_sha256':hashlib.sha256(task.encode('utf8')).hexdigest(),
               'session_id':session_id, 'exit_code':exit_code, 'release_approved':False}
    fd, temp_name = tempfile.mkstemp(prefix='.checkpoint-', dir=STATE_DIR)
    try:
        with os.fdopen(fd, 'w', encoding='utf8') as f:
            os.fchmod(f.fileno(),0o600)
            json.dump(payload, f, sort_keys=True)
            f.flush()
            os.fsync(f.fileno())
        os.replace(temp_name,state_file)
        dirfd=os.open(STATE_DIR, os.O_RDONLY | os.O_DIRECTORY)
        try: os.fsync(dirfd)
        finally: os.close(dirfd)
    finally:
        if os.path.exists(temp_name): os.unlink(temp_name)


def execute_task(model, task, *, session_id=None, continue_session=False):
    if gaming_active():
        print('BLOCKED: Gaming, VR, manual pause or unverified detection', file=sys.stderr)
        return 2
    cmd = command_for_task(model, task, session_id=session_id, continue_session=continue_session)
    record_task_state('STARTING',model,task,session_id=session_id)
    try:
        proc = subprocess.Popen(cmd, start_new_session=True)
    except OSError:
        record_task_state('LAUNCH_FAILED',model,task,exit_code=2,session_id=session_id)
        raise
    try:
        while True:
            rc = proc.poll()
            if rc is not None:
                record_task_state('COMPLETE' if rc == 0 else 'FAILED',model,task,exit_code=rc,session_id=session_id)
                return rc
            if gaming_active():
                print('BLOCKED: Gaming/VR started; stopping router-owned OpenCode process group', file=sys.stderr)
                stop_owned_process(proc)
                record_task_state('PAUSED_INTERRUPTED',model,task,exit_code=2,session_id=session_id)
                return 2
            time.sleep(1)
    except BaseException:
        stop_owned_process(proc)
        record_task_state('INTERRUPTED',model,task,exit_code=2,session_id=session_id)
        raise

@contextlib.contextmanager
def router_lock():
    fd = os.open(LOCKFILE, os.O_CREAT | os.O_RDWR | os.O_NOFOLLOW, 0o600)
    try:
        info = os.fstat(fd)
        if info.st_uid != os.getuid() or (info.st_mode & 0o077):
            raise RuntimeError('Unsafe or foreign router lock file')
        try:
            fcntl.flock(fd, fcntl.LOCK_EX | fcntl.LOCK_NB)
        except BlockingIOError as exc:
            raise RuntimeError('Another router task is running') from exc
        yield
    finally:
        os.close(fd)

def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('task', help='Task to give OpenCode')
    parser.add_argument('--dry-run', action='store_true', help='Show choice without running OpenCode')
    sessions = parser.add_mutually_exclusive_group()
    sessions.add_argument('--session-id', help='Continue this existing OpenCode session ID')
    sessions.add_argument('--continue-session', action='store_true', help='Continue most recent OpenCode session')
    parser.add_argument('--allow-loaded-other', action='store_true', help='Explicitly permit Ollama native scheduling; may affect other Ollama clients')
    parser.add_argument('--managed-native', action='store_true', help='Opt in to Ollama native eviction and sequential router locking; no forced unload')
    args = parser.parse_args(argv)
    if not args.task.strip():
        parser.error('Empty task')
    try:
        command_for_task(select_model(args.task), args.task, session_id=args.session_id, continue_session=args.continue_session)
    except ValueError as exc:
        parser.error(str(exc))
    model = select_model(args.task)
    print('Selected:', model, flush=True)
    if args.dry_run:
        return 0
    # Acquire the router lock BEFORE checking residency. Otherwise another
    # router invocation could change Ollama state between check and launch.
    try:
        with router_lock():
            if gaming_active():
                print('BLOCKED: Gaming, VR, manual pause or unverified detection', file=sys.stderr)
                return 2
            try:
                active = loaded_models()
            except (urllib.error.URLError, TimeoutError, ValueError, RuntimeError, KeyError, OSError) as exc:
                print(f'BLOCKED: Cannot verify Ollama model residency: {type(exc).__name__}', file=sys.stderr)
                return 2
            other = [name for name in active if 'ollama/' + name != model]
            if other and not (args.allow_loaded_other or args.managed_native):
                print('BLOCKED: Other model resident (' + ', '.join(other) + '). No automatic unloading; avoid interrupting other work.', file=sys.stderr)
                return 2
            # Native scheduler handles eviction, never force-unload foreign models.
            # Lock only coordinates router-launched subprocesses, NOT outside clients.
            if args.session_id or args.continue_session:
                return execute_task(model, args.task, session_id=args.session_id, continue_session=args.continue_session)
            return execute_task(model, args.task)
    except (OSError, RuntimeError) as exc:
        print(f'BLOCKED: Cannot launch OpenCode safely: {type(exc).__name__}: {exc}', file=sys.stderr)
        return 2

if __name__ == '__main__':
    sys.exit(main())
