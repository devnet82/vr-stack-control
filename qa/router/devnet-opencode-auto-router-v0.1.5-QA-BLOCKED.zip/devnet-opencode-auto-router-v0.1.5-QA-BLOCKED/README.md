# Devnet OpenCode Auto-Router v0.1.5 — QA BLOCKED

Continues the original v0.1.4 candidate; the user's separate underlying model-router v0.4.1 is **not replaced**.

- Preserve Qwen3.5:9b (general) / Qwen3-Coder:30b (coding) selection and opt-in `--managed-native` Ollama scheduling.
- Fix all five failing v0.1.4 bundled tests on Python 3.13, without deleting tests or bypassing gaming checks.
- OpenCode documented `opencode run --session <ID>` and `--continue` supported by wrapper options `--session-id` and `--continue-session`. A launch failure or gaming interruption records an explicit fail-closed status. Lock ownership and permissions are verified. The OpenCode server owns conversation/session state; the router does not copy model context itself.
- Private persistent checkpoint `~/.local/state/devnet-model-router/latest.json` contains only task SHA-256, selected model, explicit session ID if supplied, process status, exit code and `release_approved:false`. This is *not* crash resumption or a production QA attestation.
- Gaming check still fail-closed via existing installed detector. Router stops only its owned OpenCode process group if game/VR starts; interrupted application edits are not guaranteed rollback-safe. OpenCode clients outside the wrapper are uncoordinated.
- No model force-unloading, no installation changes, no auto-approval. `--managed-native` permits Ollama's native scheduling but does not guarantee one model resident across all external clients.
- Offline regression: `python3 -m unittest discover -s <extracted directory> -p 'test_*.py' -v`.
- Next QA required: GitHub-first + isolated CachyOS VM full suite, real OpenCode session continuation (both model directions), GPU residency, crash/game transition, install/rollback, Master QA 100% checklist and user acceptance. Full Master QA remains BLOCKED.
