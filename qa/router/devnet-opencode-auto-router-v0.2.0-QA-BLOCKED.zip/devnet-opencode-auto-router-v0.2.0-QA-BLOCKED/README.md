# Devnet OpenCode Auto-Router v0.2.0 — QA BLOCKED

**Status: experimental QA candidate; no installation, production attestation or release approval.** This continues the verified v0.1.7 router without replacing the separate installed model router or Master QA controller.

## Previous verified evidence

- v0.1.7: GitHub 88/88 and CachyOS VM 88/88 PASS.
- On the host: real OpenCode session-ID capture, automatic Qwen3.5:9b ↔ Qwen3-Coder:30b model switching and conversation retention PASS; isolated manual game flag, a WayVR-named `/proc` stand-in and a controlled live inference interruption/recovery using the exact session ID PASS_LIMITED.
- True game/VR launch, independent trusted production attestation, installation/upgrade/rollback and full GUI/tray QA remain **NOT TESTED**.
- The model previously printed fake `shell` tool-call markup instead of invoking the approved QA program. That is **not** successful tool execution.

## v0.2.0 Ollama review schema fix (QA CANDIDATE)

- Verified v0.1.9 GitHub 125/125 PASS and CachyOS VM 125/125 PASS. Live host dispatcher: baseline 88/88 PASS, simulated interrupted exact-session recovery PASS_LIMITED, but optional Qwen3-Coder:30b advisory returned `AI_REVIEW_SCHEMA_INVALID`. The cycle correctly stayed `BLOCKED` with `release_approved:false`.
- The v0.1.9 worker requested only generic JSON, which does not guarantee **field types**. v0.2.0 asks Ollama for an explicit JSON Schema requiring exactly three advisory strings: `summary`, `remaining_risks`, `next_checks`.
- Defensive backwards compatibility accepts **bounded** string lists for risks/checks, converts them to advisory text, and still rejects nested objects, mixed/oversized lists, missing/extra keys, failed completions and attempted release-approval fields. No model field can change test statuses or approve a release.
- Fourteen new test cases cover schema content, success, list normalization, all key fail-closed cases, response truncation and evidence immutability. Full candidate regression tests run before any GitHub/VM/host phase. **This version has not yet proven a real AI review against the user's live Ollama.**

## v0.1.9 host regression fix and review diagnostics

- **Observed 2026-10-30:** v0.1.8 GitHub and VM each passed 119/119, but a real host invocation of `--qa-run all --qa-ai-review` stopped after the inherited 88-test job failed 2 tests and AI review returned `LOCAL_AI_WORKER_FAILED`. **Do not treat this host cycle as a PASS.**
- The two failed inherited assertions (`test_conflicting_model_blocks`, `test_guard_blocks_while_lock_held`) assume strict default Ollama model-conflict blocking. The user's host may have explicitly enabled **persistent native auto-handover**, which legitimately permits the model and invalidates those test assumptions. v0.1.9 runs the pinned old tests under a **private HOME and XDG directories** instead of disabling or changing the user's setting. The supervising dispatcher still uses the genuine host game/VR detector before and during subprocess execution.
- Fixed codes (`AI_REVIEW_HTTP_<status>`, `AI_REVIEW_CONNECTION`, `AI_REVIEW_TIMEOUT`, `AI_REVIEW_JSON_INVALID`, `AI_REVIEW_SCHEMA_INVALID`, etc.) now distinguish AI-review worker failures. Full error bodies, model responses and secret prompts are **not** included in diagnostics. They remain fail-closed and untrusted; the actual host AI review failure cause is still **NOT VERIFIED** pending a new live run.
- Six new automated regression checks cover the enabled host setting, preserved source config and isolated subprocess environment, worker HTTP/schema errors, and safe diagnostic forwarding. **125/125 local tests PASS; GitHub, VM and host checks for this exact v0.2.0 package remain PENDING.**
- The v0.1.7 recovery fixture still tests a controlled interruption, not a real game. No release is approved.

## What v0.1.8 introduced

1. `auto_route.py --qa-list` lists only approved tests.
2. `auto_route.py --qa-run router-regressions-v017` executes the exact SHA-256-pinned v0.1.7 ZIP in a **real** isolated Python subprocess and requires all 88 tests to pass.
3. `auto_route.py --qa-run exact-session-recovery-v017` invokes the exact SHA-256-pinned known-good recovery fixture in a separate supervised process, verifies the result.json evidence, and preserves the original ZIP. The original v0.1.7 ZIP is expected in `~/Downloads` for this fixture.
4. `auto_route.py --qa-run all` executes the two approved checks, stopping on a failure or unsafe condition. The controller **never accepts arbitrary commands or paths from a language model**. Execution occurs outside the OpenCode task lock, avoiding nested-lock deadlocks.
5. `--qa-ai-review` optionally asks **local Qwen3-Coder:30b** to review the evidence through a supervised non-shell Ollama subprocess. It can provide only advisory text; gaming/VR detection is checked during the request and stops the owned client process. If requested AI review fails, the overall cycle stays BLOCKED even when the individual tests passed. It cannot edit sources, approve a release or alter the test verdicts.
6. Results and bounded logs are written to uniquely named private directories under `/mnt/devnet-ai/qa/router-qa-<24 hex ID>/`. Report and log files carry SHA-256 digests and `release_approved: false`, `trusted_evidence: false`, `user_acceptance_ready: false`. `--qa-status <run-id>` inspects the private report without executing tests.
7. The optional **project-local** `.opencode/tools/devnet_qa.ts` exposes only the fixed v0.1.7 regression job to the model. `opencode.json` denies other tool actions in this QA project. A model can still fail to call its tool; the controller's deterministic `--qa-run` path is the reliable fallback, independent of model-generated shell markup. Live session recovery is not exposed as a nested OpenCode tool because the outer router may already hold the concurrency lock.

## Execution (host, after GitHub and VM first)

Only from the extracted exact v0.2.0 ZIP, while not gaming:

```
python3 auto_route.py --qa-run all --qa-ai-review
```

The Ollama review is optional; omit `--qa-ai-review` for purely deterministic checks. The fixed v0.1.7 input ZIP is inside the v0.2.0 package for the regression job; the original `~/Downloads/devnet-opencode-auto-router-v0.1.7-QA-BLOCKED.zip` is independently verified by the approved recovery runner.

`python3 auto_route.py --qa-list` or `python3 auto_route.py --qa-status <run-id>` are read-only.

## Limits and fail-closed policy

- A **local** test result is preliminary, even if all checks pass. No local AI can sign release approval; no new build bypasses GitHub-first → existing VM → host/hardware → user acceptance.
- Running a Python subprocess or a custom OpenCode tool on the host does not by itself sandbox it. Only bundled, SHA-256-pinned fixed QA scripts and fixed arguments are allowed; run candidates only in the intended isolated QA setup.
- The optional OpenCode TypeScript tool has **not yet been verified live** on the user's particular OpenCode build; its execution cannot be claimed solely from static tests. Never trust text that looks like a tool call without independent evidence.
- The regression job checks the **known-good v0.1.7 baseline**. v0.1.9's own complete suite is tested separately by GitHub and the QA VM for each revision.
- The recovery job is a controlled *simulated gaming interruption* of real inference, not a real game launch. It requires an otherwise idle computer. If a game is detected, operations stop, and any model request may take time to release GPU residency at Ollama level.
- The QA dispatcher can **only** collect and inspect preliminary evidence, not install upgrades, invoke unrestricted shells, test arbitrary applications, publish releases, or approve releases.

**Master QA release gate: BLOCKED.**
