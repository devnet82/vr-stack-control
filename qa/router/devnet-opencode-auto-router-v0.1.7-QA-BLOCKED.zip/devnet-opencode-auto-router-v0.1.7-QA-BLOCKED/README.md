# Devnet OpenCode Auto-Router v0.1.7 — QA BLOCKED

Continues the existing v0.1.6 candidate and all 62 regression tests; does **not** install over the user's existing separate router v0.4.1, OpenCode, Ollama, or Master QA controller.

## Verified baseline (from user-controlled tests before v0.1.7)

- v0.1.6: GitHub-first Python suite 62/62 PASS, existing CachyOS VM suite 62/62 PASS.
- Live Qwen3.5:9b and Qwen3-Coder:30b runs in OpenCode succeeded, with automatic two-way model handover and `--continue-session` conversational continuity.
- Local user tested a gaming flag and a genuine Linux `/proc` gaming process detector using a harmless WayVR-named stand-in. Detection, process-group termination and safe **new** invocation passed.
- The prior tests **did not** demonstrate recovery of the **exact** interrupted OpenCode session. They did not launch an actual VR game.

## New in v0.1.7 — exact session-ID checkpoints

- Uses documented `opencode run --format json` event output to capture the **actual sessionID** from the launched OpenCode process. It prints `text` parts to the terminal and does not persist prompts, generated text, tool data or full JSON events.
- Rejects JSON event corruption, missing/unverifiable session ID, changes of ID during a task, mismatches with an explicitly selected session, oversize and incomplete events. The router never claims success for unverified session metadata.
- Saves the captured ID in the private `~/.local/state/devnet-model-router/latest.json` checkpoint. When a game/VR process interrupts the router-owned process group, the checkpoint records `PAUSED_INTERRUPTED` and that exact ID, if captured.
- New **explicit** recovery option: `python3 auto_route.py --resume-interrupted 'A NEW instruction to continue the paused conversation'`. Reads the prior verified private interrupted checkpoint, enforces its exact session ID, and asks OpenCode to continue that exact conversation.
- **Never automatically replays an interrupted task.** The old prompt may have partially executed side effects; the user must provide a new instruction. Missing/tampered/ambiguous checkpoints fail closed.
- Preserves one-time auto-handover opt-in, privacy, existing gaming detector, router-owned process-group protection, model-choice rules, and `--session-id` / `--continue-session` flags.

## Safety and known limits

- Test fixtures with a stand-in CLI prove the recovery logic in unit/integration tests; actual OpenCode JSON output, a real interrupted AI inference, and recovery of the **same real OpenCode conversation** are NOT TESTED in v0.1.7 yet.
- OpenCode events could have version-specific changes; unrecognised output blocks recovery. Availability of a saved session does **not** prove every unfinished external side effect or tool operation can be resumed safely.
- No global model unload or kill, no changes to installed OpenCode or Ollama config, and no automatic session replay. A router-owned lock does not protect independent Ollama clients. Managed Ollama residency can evict idle foreign models.
- This is not a substitute for the full Master Application QA Gate: GitHub-first and VM testing of the *exact v0.1.7 package*, real host/VR behavior, installation/upgrade/rollback, trusted evidence and user acceptance remain required. **Release BLOCKED.**

Offline suite: `python3 -m unittest discover -s <extracted directory> -p 'test_*.py' -v`.
