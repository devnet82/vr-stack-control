"""Integration-contract regression tests for deterministic Master QA handoff."""
from __future__ import annotations
import contextlib
import hashlib
import io
import json
import os
from pathlib import Path
import subprocess
import sys
import tempfile
import unittest
from unittest import mock
import auto_route as router
import master_qa_bridge as bridge

BUNDLE = Path(__file__).resolve().parent
MASTER = Path(os.environ.get('DEVNET_PINNED_MASTER_ZIP','/mnt/data/devnet-master-qa-unified-v0.3.8-QA-BLOCKED.zip'))


class ProjectFixture:
    def __enter__(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.top = Path(self.tmp.name)
        self.projects = self.top/'projects'
        self.projects.mkdir()
        self.qa = self.top/'qa'
        self.qa.mkdir()
        self.root = self.projects/'registered-app'
        self.root.mkdir()
        (self.root/'app.py').write_text('def value():\n return 1\n')
        (self.root/'test_app.py').write_text('import unittest\nclass T(unittest.TestCase):\n def test_ok(self): self.assertTrue(True)\n')
        self.work = self.qa/'workspace'
        self.digest = bridge.source_digest(self.root)
        self.job={'schema':'devnet-master-auto-repair-job-v1','job_id':'test-registered',
                  'revision_sha256':self.digest,'allowed_files':['app.py'],
                  'max_attempts':1,'authorised_vm_diagnostic':True}
        self.plan={'schema':'devnet-test-plan-v1','revision_sha256':self.digest,
                   'tests':[{'name':'test','stage':'vm','kind':'python-unittest','target':'test_app.py','timeout':20}]}
        self.web={'schema':'devnet-master-web-research-config-v1','job_id':'test-registered',
                  'revision_sha256':self.digest,'topics':[{'product':'Ollama','version':'0.40.13',
                            'repository':'ollama/ollama','queries':['qwen3 coder tool calls']}]}
        self.registration={'schema':'devnet-master-auto-repair-registration-v1',
                           'source_root':str(self.root),'workspace':str(self.work),
                           'job':self.job,'plan':self.plan,'web_research':self.web}
        self.regfile = self.top/'master-repair-job.json'
        self.save()
        self.stack=contextlib.ExitStack()
        # Host-only tests isolate CI's GITHUB_ACTIONS=true; a separate test proves the real guard remains enforced.
        self.stack.enter_context(mock.patch.dict(os.environ,{'GITHUB_ACTIONS':'false'}))
        self.stack.enter_context(mock.patch.object(bridge,'registration_path',return_value=self.regfile))
        self.stack.enter_context(mock.patch.object(bridge,'PROJECTS',self.projects))
        self.stack.enter_context(mock.patch.object(bridge,'EVIDENCE',self.qa))
        return self

    def save(self):
        self.regfile.write_text(json.dumps(self.registration))
        self.regfile.chmod(0o600)

    def __exit__(self,*a):
        self.stack.close()
        self.tmp.cleanup()


def router_sandbox():
    stack=contextlib.ExitStack()
    stack.enter_context(mock.patch.object(router,'loaded_models',return_value=[]))
    stack.enter_context(mock.patch.object(router,'gaming_active',return_value=False))
    stack.enter_context(mock.patch.object(router,'router_lock',side_effect=lambda:contextlib.nullcontext()))
    return stack


class MasterHandoffTests(unittest.TestCase):
    def test_master_038_zip_pinned_and_manifest_checked(self):
        self.assertRegex(bridge.MASTER_SHA256,r'^[0-9a-f]{64}$')
        if 'DEVNET_PINNED_MASTER_ZIP' in os.environ:
            self.assertTrue(MASTER.is_file(), 'CI must supply exact Master QA baseline')
        if MASTER.exists():
            self.assertEqual(hashlib.sha256(MASTER.read_bytes()).hexdigest(),bridge.MASTER_SHA256)
            self.assertTrue(bridge.check_master_package(MASTER))
            with tempfile.TemporaryDirectory() as d:
                self.assertTrue(bridge.extract_pinned_master(MASTER,Path(d)).is_file())

    def test_tampered_master_zip_refused(self):
        with tempfile.TemporaryDirectory() as temp:
            f=Path(temp)/'master.zip';f.write_bytes(b'not the pinned package')
            with self.assertRaises(bridge.MasterBridgeBlocked) as cm:
                bridge.check_master_package(f)
            self.assertEqual(cm.exception.reason,'MASTER_ZIP_SHA256_MISMATCH')

    def test_master_qa_must_not_implicitly_use_router_88_test_job(self):
        import inspect
        txt=inspect.getsource(router.run_master_qa_after_success)
        self.assertNotIn('run_qa_after_success(',txt)
        self.assertNotIn('router-regressions-v017',txt)
        self.assertNotIn('qa_dispatch',txt)

    def test_legacy_qa_after_still_exactly_router_specific(self):
        import inspect
        self.assertIn("['--run','all','--ai-review']",inspect.getsource(router.run_qa_after_success))

    def test_no_job_registration_fails_before_model_launch(self):
        with tempfile.TemporaryDirectory() as temp, router_sandbox(), \
             mock.patch.object(bridge,'registration_path',return_value=Path(temp)/'missing.json'), \
             mock.patch.object(router,'execute_task',side_effect=AssertionError('MODEL MUST NOT START')):
            with contextlib.redirect_stderr(io.StringIO()),contextlib.redirect_stdout(io.StringIO()):
                self.assertEqual(router.main(['--master-qa-after','--master-qa-zip','/tmp/irrelevant.zip','Debug Python']),2)

    def test_registration_private_with_exact_revision(self):
        with ProjectFixture() as a:
            r=bridge.read_registered_job()
            self.assertEqual(r['revision_sha256'],a.digest)
            self.assertEqual(r['root'],a.root)
            bridge.recheck_registration(r)

    def test_registration_disallows_group_read(self):
        with ProjectFixture() as a:
            a.regfile.chmod(0o640)
            with self.assertRaises(bridge.MasterBridgeBlocked):bridge.read_registered_job()

    def test_registration_symlink_is_refused(self):
        with ProjectFixture() as a:
            real=a.regfile.with_suffix('.real');a.regfile.rename(real)
            a.regfile.symlink_to(real)
            with self.assertRaises(bridge.MasterBridgeBlocked):bridge.read_registered_job()

    def test_no_research_topic_registration_refused(self):
        with ProjectFixture() as a:
            a.registration.pop('web_research');a.save()
            with self.assertRaises(bridge.MasterBridgeBlocked):bridge.read_registered_job()

    def test_research_revision_mismatch_blocks(self):
        with ProjectFixture() as a:
            a.registration['web_research']['revision_sha256']='0'*64;a.save()
            with self.assertRaises(bridge.MasterBridgeBlocked):bridge.read_registered_job()

    def test_missing_tests_blocks_before_model(self):
        with ProjectFixture() as a:
            a.registration['plan']['tests']=[];a.save()
            with self.assertRaises(bridge.MasterBridgeBlocked):bridge.read_registered_job()

    def test_unregistered_project_location_refused(self):
        with ProjectFixture() as a:
            a.registration['source_root']=str(a.top/'outside');a.save()
            with self.assertRaises(bridge.MasterBridgeBlocked):bridge.read_registered_job()

    def test_stale_source_revision_blocks(self):
        with ProjectFixture() as a:
            (a.root/'app.py').write_text('def value():\n return 7\n')
            with self.assertRaises(bridge.MasterBridgeBlocked) as cm:bridge.read_registered_job()
            self.assertEqual(cm.exception.reason,'REGISTERED_SOURCE_REVISION_STALE')

    def test_source_change_after_open_code_task_blocks_master(self):
        with ProjectFixture() as a:
            pre=bridge.read_registered_job()
            (a.root/'app.py').write_text('def value():\n return 7\n')
            with self.assertRaises(bridge.MasterBridgeBlocked) as cm:bridge.recheck_registration(pre)
            self.assertEqual(cm.exception.reason,'REGISTERED_SOURCE_CHANGED_DURING_TASK')

    def test_job_change_after_model_task_blocks_master(self):
        with ProjectFixture() as a:
            pre=bridge.read_registered_job()
            a.registration['job']['max_attempts']=2;a.save()
            with self.assertRaises(bridge.MasterBridgeBlocked) as cm:bridge.recheck_registration(pre)
            self.assertEqual(cm.exception.reason,'REGISTERED_JOB_CHANGED_DURING_TASK')

    def test_github_environment_blocks_vm_bridge(self):
        with ProjectFixture(),mock.patch.dict(os.environ,{'GITHUB_ACTIONS':'true'}):
            with self.assertRaises(bridge.MasterBridgeBlocked) as cm:bridge.read_registered_job()
            self.assertEqual(cm.exception.reason,'MASTER_VM_REPAIR_HOST_ONLY')

    def test_missing_zip_option_rejected(self):
        with contextlib.redirect_stderr(io.StringIO()),self.assertRaises(SystemExit):
            router.main(['--master-qa-after','Debug Python'])

    def test_zip_option_not_allowed_without_master_mode(self):
        with contextlib.redirect_stderr(io.StringIO()),self.assertRaises(SystemExit):
            router.main(['--master-qa-zip','/tmp/test.zip','Debug Python'])

    def test_master_and_router_modes_are_mutually_exclusive(self):
        with contextlib.redirect_stderr(io.StringIO()),self.assertRaises(SystemExit):
            router.main(['--qa-after','--master-qa-after','--master-qa-zip','/tmp/test.zip','Debug Python'])

    def test_qa_run_cannot_be_combined_with_master_mode(self):
        with contextlib.redirect_stderr(io.StringIO()),self.assertRaises(SystemExit):
            router.main(['--qa-run','all','--master-qa-after','--master-qa-zip','/tmp/test.zip'])

    def test_settings_cannot_be_combined_with_master_mode(self):
        with contextlib.redirect_stderr(io.StringIO()),self.assertRaises(SystemExit):
            router.main(['--enable-auto-handover','--master-qa-after','--master-qa-zip','/tmp/test.zip'])

    def test_master_mode_runs_registered_cwd_and_dispatcher_outside_lock(self):
        with ProjectFixture() as a,router_sandbox(), \
             mock.patch.object(router,'run_master_qa_after_success',return_value=0) as after, \
             mock.patch.object(router,'execute_task',return_value=0) as exec_task, \
             mock.patch.object(bridge,'check_master_package',return_value=True), \
             mock.patch.object(router,'load_master_bridge',return_value=bridge), \
             contextlib.redirect_stdout(io.StringIO()):
            self.assertEqual(router.main(['--master-qa-after','--master-qa-zip','/tmp/pinned.zip','Debug Python']),0)
            exec_task.assert_called_once_with(router.CODER,'Debug Python',track_session=True,reject_fake_tool_text=True,cwd=BUNDLE)
            self.assertNotEqual(BUNDLE,a.root, 'Never run OpenCode directly on registered original source')
            after.assert_called_once_with(bridge,mock.ANY,'/tmp/pinned.zip')

    def test_master_mode_does_not_dispatch_if_opencode_fails(self):
        with ProjectFixture(),router_sandbox(), \
             mock.patch.object(router,'load_master_bridge',return_value=bridge), \
             mock.patch.object(bridge,'check_master_package',return_value=True), \
             mock.patch.object(router,'execute_task',return_value=2), \
             mock.patch.object(router,'run_master_qa_after_success',side_effect=AssertionError('DO NOT DISPATCH')), \
             contextlib.redirect_stdout(io.StringIO()):
            self.assertEqual(router.main(['--master-qa-after','--master-qa-zip','/tmp/pinned.zip','Debug Python']),2)

    def test_master_result_advisory_cannot_flip_release(self):
        with mock.patch.object(bridge,'run_pinned_master',return_value={
                'status':'BLOCKED','reason':'MASTER_STAGE_BLOCKED','release_approved':False}), \
             contextlib.redirect_stdout(io.StringIO()):
            self.assertEqual(router.run_master_qa_after_success(bridge,{},'/tmp/master.zip'),2)

    def test_controller_without_registration_is_blocked_not_smoke_pass(self):
        with tempfile.TemporaryDirectory() as temp,router_sandbox(), \
             mock.patch.object(bridge,'registration_path',return_value=Path(temp)/'missing.json'), \
             contextlib.redirect_stdout(io.StringIO()),contextlib.redirect_stderr(io.StringIO()):
            self.assertEqual(router.main(['--master-qa-after','--master-qa-zip','/tmp/none','Just say hello']),2)


    @staticmethod
    def prepare_checkpoint(a, result):
        a.work.mkdir(mode=0o700,exist_ok=True)
        state={'phase':'AWAITING_GITHUB_RETEST','job_id':a.job['job_id'],
               'revision_sha256':a.digest,'release_approved':False,
               'user_acceptance_ready':False,'attempts':result['attempts'],
               'history':[result['report']]}
        f=a.work/'checkpoint.json'
        f.write_text(json.dumps(state));f.chmod(0o600)

    def test_real_subprocess_good_master_record_is_still_limited(self):
        with ProjectFixture() as a:
            report={'stage':'vm','release_approved':False,'initial':{'t1':'FAIL','t2':'PASS'},
                    'outcome':'VM_DIAGNOSTIC_PASS_GITHUB_RETEST_REQUIRED',
                    'retest':{'t1':'PASS','t2':'PASS'},
                    'web_research':{'status':'RESEARCH_COMPLETE_UNTRUSTED','evidence_sha256':'a'*64}}
            result={'decision':'AWAITING_GITHUB_RETEST','attempts':1,
                    'release_approved':False,'user_acceptance_ready':False,'trusted_evidence':False,
                    'report':report}
            self.prepare_checkpoint(a,result)
            folder=a.work/'attempt-1';folder.mkdir(mode=0o700)
            evidence={'evidence_sha256':'a'*64,'job_id':a.job['job_id'],
                      'revision_sha256':a.digest,'decision':'RESEARCH_COMPLETE_UNTRUSTED',
                      'trusted_evidence':False,'release_approved':False}
            r=folder/'web-research.json';r.write_text(json.dumps(evidence));r.chmod(0o600)
            fake=a.top/'fake-master.py'
            fake.write_text('import json\nprint(json.dumps('+repr(result)+'))\n')
            with mock.patch.object(bridge,'extract_pinned_master',return_value=fake):
                found=bridge.run_pinned_master(a.top/'unused.zip',bridge.read_registered_job(),gaming=lambda:False,timeout=10)
            self.assertEqual(found['status'],'PASS_LIMITED')
            self.assertIs(found['release_approved'],False)
            self.assertIs(found['trusted_evidence'],False)
            self.assertEqual(found['next_stage'],'GITHUB_RETEST_REQUIRED')

    def test_model_forged_release_approval_blocked(self):
        with ProjectFixture() as a:
            fake=a.top/'fake-master.py'
            result={'decision':'AWAITING_GITHUB_RETEST','attempts':1,'trusted_evidence':False,
                    'release_approved':True,'user_acceptance_ready':False}
            fake.write_text('import json\nprint(json.dumps('+repr(result)+'))\n')
            with mock.patch.object(bridge,'extract_pinned_master',return_value=fake):
                with self.assertRaises(bridge.MasterBridgeBlocked) as cm:
                    bridge.run_pinned_master(a.top/'unused.zip',bridge.read_registered_job(),gaming=lambda:False,timeout=10)
            self.assertEqual(cm.exception.reason,'MASTER_QA_RESULT_UNVERIFIED')

    def test_master_qa_rejects_unreadable_output(self):
        with ProjectFixture() as a:
            fake=a.top/'fake-master.py'
            fake.write_text('print("not structured")\n')
            with mock.patch.object(bridge,'extract_pinned_master',return_value=fake):
                with self.assertRaises(bridge.MasterBridgeBlocked) as cm:
                    bridge.run_pinned_master(a.top/'unused.zip',bridge.read_registered_job(),gaming=lambda:False,timeout=10)
            self.assertEqual(cm.exception.reason,'MASTER_QA_JSON_INVALID')

    def test_gaming_prevents_master_subprocess(self):
        with ProjectFixture() as a:
            with mock.patch.object(bridge,'extract_pinned_master',side_effect=AssertionError('master should not run')):
                with self.assertRaises(bridge.MasterBridgeBlocked) as cm:
                    bridge.run_pinned_master(a.top/'unused.zip',bridge.read_registered_job(),gaming=lambda:True)
            self.assertEqual(cm.exception.reason,'GAMING_OR_VR_ACTIVE')

    def test_master_qa_process_nonzero_blocks(self):
        with ProjectFixture() as a:
            fake=a.top/'fake-master.py'
            fake.write_text('import sys\nsys.exit(3)\n')
            with mock.patch.object(bridge,'extract_pinned_master',return_value=fake):
                with self.assertRaises(bridge.MasterBridgeBlocked) as cm:
                    bridge.run_pinned_master(a.top/'unused.zip',bridge.read_registered_job(),gaming=lambda:False,timeout=10)
            self.assertEqual(cm.exception.reason,'MASTER_QA_PROCESS_NONZERO')

    def test_master_qa_gaming_mid_process_kills_only_child_group(self):
        with ProjectFixture() as a:
            fake=a.top/'fake-master.py'
            fake.write_text('import time\ntime.sleep(9)\n')
            checks=iter((False,True))
            with mock.patch.object(bridge,'extract_pinned_master',return_value=fake):
                with self.assertRaises(bridge.MasterBridgeBlocked) as cm:
                    bridge.run_pinned_master(a.top/'unused.zip',bridge.read_registered_job(),gaming=lambda:next(checks),timeout=10)
            self.assertEqual(cm.exception.reason,'GAMING_INTERRUPTED_MASTER_QA')

    def test_master_subprocess_no_release_approval_even_if_already_passes(self):
        with ProjectFixture() as a:
            result={'decision':'AWAITING_GITHUB_RETEST','attempts':1,
                    'release_approved':False,'user_acceptance_ready':False,'trusted_evidence':False,
                    'report':{'stage':'vm','release_approved':False,'initial':{'t1':'PASS'},
                              'outcome':'ALREADY_PASSES_PRELIMINARY_ONLY'}}
            self.prepare_checkpoint(a,result)
            fake=a.top/'fake-master.py';fake.write_text('import json\nprint(json.dumps('+repr(result)+'))\n')
            with mock.patch.object(bridge,'extract_pinned_master',return_value=fake):
                found=bridge.run_pinned_master(a.top/'unused.zip',bridge.read_registered_job(),gaming=lambda:False,timeout=10)
            self.assertEqual(found['status'],'PASS_LIMITED')
            self.assertIs(found['release_approved'],False)

    def test_research_not_verified_blocks_preliminary_success(self):
        with ProjectFixture() as a:
            result={'decision':'AWAITING_GITHUB_RETEST','attempts':1,
                    'release_approved':False,'user_acceptance_ready':False,'trusted_evidence':False,
                    'report':{'stage':'vm','release_approved':False,'initial':{'t1':'FAIL'},
                              'outcome':'VM_DIAGNOSTIC_PASS_GITHUB_RETEST_REQUIRED',
                              'retest':{'t1':'PASS'},'web_research':{'status':'RESEARCH_MISSING'}}}
            self.prepare_checkpoint(a,result)
            fake=a.top/'fake-master.py';fake.write_text('import json\nprint(json.dumps('+repr(result)+'))\n')
            with mock.patch.object(bridge,'extract_pinned_master',return_value=fake):
                with self.assertRaises(bridge.MasterBridgeBlocked) as cm:
                    bridge.run_pinned_master(a.top/'unused.zip',bridge.read_registered_job(),gaming=lambda:False,timeout=10)
            self.assertEqual(cm.exception.reason,'MASTER_WEB_RESEARCH_OR_VM_RETEST_NOT_VERIFIED')



if __name__=='__main__':
    unittest.main()
