"""Pinned, fail-closed handoff to the existing Master QA v0.3.8 VM repair path.

No model tool calling, shell, registry writes, release signing or production
application changes. Registered source revision must be unchanged end-to-end.
"""
from __future__ import annotations
import hashlib
import json
import os
from pathlib import Path
import re
import signal
import stat
import subprocess
import sys
import tempfile
import time
import zipfile

MASTER_SHA256 = 'de83312d81636c8f92802060fc516188dc46b62b6d246bf6cc3d2361f0a1500c'
MASTER_ROOT = 'devnet-master-qa-unified-v0.3.8-QA-BLOCKED'
MASTER_REGISTRATION = 'master-repair-job.json'
PROJECTS = Path('/mnt/devnet-ai/projects')
EVIDENCE = Path('/mnt/devnet-ai/qa')
HEX = re.compile(r'[0-9a-f]{64}\Z')
IDENT = re.compile(r'[A-Za-z0-9_.-]{1,80}\Z')


class MasterBridgeBlocked(Exception):
    """Stable fail-closed bridge rejection; never echo private exception text."""
    def __init__(self, reason):
        super().__init__(reason)
        self.reason = reason


def _private_regular_file(path: Path, max_size: int) -> bytes:
    try:
        fd = os.open(path, os.O_RDONLY | os.O_NOFOLLOW)
        try:
            st = os.fstat(fd)
            if (not stat.S_ISREG(st.st_mode) or st.st_uid != os.getuid()
                    or st.st_mode & 0o077 or st.st_size < 1 or st.st_size > max_size):
                raise MasterBridgeBlocked('UNSAFE_PROTECTED_FILE')
            with os.fdopen(fd, 'rb') as f:
                fd = -1
                data = f.read(max_size + 1)
            if len(data) > max_size:
                raise MasterBridgeBlocked('OVERSIZE_PROTECTED_FILE')
            return data
        finally:
            if fd >= 0:
                os.close(fd)
    except (FileNotFoundError, PermissionError, IsADirectoryError, OSError) as exc:
        raise MasterBridgeBlocked('PROTECTED_FILE_UNAVAILABLE') from exc


def source_digest(root: Path) -> str:
    """Byte-for-byte match to Master QA master_source_tree_digest v0.3.8."""
    root = Path(root)
    if root.is_symlink() or not root.is_dir():
        raise MasterBridgeBlocked('INVALID_REGISTERED_SOURCE')
    h = hashlib.sha256(b'devnet-source-tree-v1\0')
    try:
        entries = sorted(root.rglob('*'), key=lambda p: p.relative_to(root).as_posix())
        if len(entries) > 4096:
            raise MasterBridgeBlocked('SOURCE_VOLUME_LIMIT')
        for p in entries:
            mode = p.lstat().st_mode
            if stat.S_ISLNK(mode):
                raise MasterBridgeBlocked('SOURCE_SYMLINK_REFUSED')
            if stat.S_ISDIR(mode):
                continue
            if not stat.S_ISREG(mode):
                raise MasterBridgeBlocked('SOURCE_NONREGULAR_FILE')
            rel = p.relative_to(root).as_posix().encode('utf-8')
            size = p.stat().st_size
            if size > 256 * 1024:
                raise MasterBridgeBlocked('SOURCE_VOLUME_LIMIT')
            data = p.read_bytes()
            if len(data) != size:
                raise MasterBridgeBlocked('SOURCE_CHANGED_DURING_DIGEST')
            h.update(len(rel).to_bytes(8, 'big'))
            h.update(rel)
            h.update(len(data).to_bytes(8, 'big'))
            h.update(data)
        return h.hexdigest()
    except (OSError, RuntimeError, ValueError) as exc:
        raise MasterBridgeBlocked('SOURCE_NOT_VERIFIABLE') from exc


def registration_path():
    return Path.home() / '.config/devnet-qa-automation' / MASTER_REGISTRATION


def read_registered_job():
    if os.environ.get('GITHUB_ACTIONS') == 'true':
        raise MasterBridgeBlocked('MASTER_VM_REPAIR_HOST_ONLY')
    path = registration_path()
    if path.parent.is_symlink():
        raise MasterBridgeBlocked('UNSAFE_REGISTRATION_DIRECTORY')
    data = _private_regular_file(path, 32768)
    try:
        record = json.loads(data)
    except (json.JSONDecodeError, UnicodeDecodeError) as exc:
        raise MasterBridgeBlocked('INVALID_JOB_REGISTRATION') from exc
    if (type(record) is not dict or set(record) != {'schema','source_root','workspace','job','plan','web_research'}
            or record['schema'] != 'devnet-master-auto-repair-registration-v1'
            or any(type(record[k]) is not dict for k in ('job','plan','web_research'))):
        raise MasterBridgeBlocked('INVALID_JOB_REGISTRATION')
    job, plan, research = (record[k] for k in ('job','plan','web_research'))
    if (set(job) != {'schema','job_id','revision_sha256','allowed_files','max_attempts','authorised_vm_diagnostic'}
            or job['schema'] != 'devnet-master-auto-repair-job-v1'
            or type(job['job_id']) is not str or not IDENT.fullmatch(job['job_id'])
            or type(job['revision_sha256']) is not str or not HEX.fullmatch(job['revision_sha256'])
            or job['authorised_vm_diagnostic'] is not True
            or type(job['max_attempts']) is not int or not 1 <= job['max_attempts'] <= 3
            or type(job['allowed_files']) is not list or not job['allowed_files']):
        raise MasterBridgeBlocked('INVALID_REGISTERED_JOB')
    if (plan.get('schema') != 'devnet-test-plan-v1' or plan.get('revision_sha256') != job['revision_sha256']
            or type(plan.get('tests')) is not list or not plan['tests']
            or research.get('schema') != 'devnet-master-web-research-config-v1'
            or research.get('job_id') != job['job_id']
            or research.get('revision_sha256') != job['revision_sha256']
            or type(research.get('topics')) is not list or not research['topics']):
        raise MasterBridgeBlocked('INCOMPLETE_REGISTERED_QA_SCOPE')
    root = Path(record['source_root']) if type(record['source_root']) is str else Path('.')
    work = Path(record['workspace']) if type(record['workspace']) is str else Path('.')
    if (not root.is_absolute() or not work.is_absolute() or root.is_symlink() or work.is_symlink()
            or not root.resolve().is_relative_to(PROJECTS)
            or not work.resolve().is_relative_to(EVIDENCE)
            or root == PROJECTS or work == EVIDENCE):
        raise MasterBridgeBlocked('UNSAFE_REGISTERED_PROJECT_OR_WORKSPACE')
    if source_digest(root) != job['revision_sha256']:
        raise MasterBridgeBlocked('REGISTERED_SOURCE_REVISION_STALE')
    if work.exists() and (not work.is_dir() or work.stat().st_mode & 0o077):
        raise MasterBridgeBlocked('UNSAFE_QA_WORKSPACE')
    return {'root': root, 'work': work, 'job_id': job['job_id'],
            'revision_sha256': job['revision_sha256'],
            'registration_sha256': hashlib.sha256(data).hexdigest()}


def recheck_registration(record):
    if hashlib.sha256(_private_regular_file(registration_path(), 32768)).hexdigest() != record['registration_sha256']:
        raise MasterBridgeBlocked('REGISTERED_JOB_CHANGED_DURING_TASK')
    if source_digest(record['root']) != record['revision_sha256']:
        raise MasterBridgeBlocked('REGISTERED_SOURCE_CHANGED_DURING_TASK')


def check_master_package(zip_path: Path):
    """Early pin check; no archive member is executed or extracted here."""
    try:
        if (zip_path.is_symlink() or not zip_path.is_file()
                or not 1 <= zip_path.stat().st_size <= 1024 * 1024):
            raise MasterBridgeBlocked('MASTER_ZIP_UNAVAILABLE_OR_UNSAFE')
        if hashlib.sha256(zip_path.read_bytes()).hexdigest() != MASTER_SHA256:
            raise MasterBridgeBlocked('MASTER_ZIP_SHA256_MISMATCH')
    except (OSError, ValueError) as exc:
        raise MasterBridgeBlocked('MASTER_ZIP_UNAVAILABLE_OR_UNSAFE') from exc
    return True


def extract_pinned_master(zip_path: Path, directory: Path):
    try:
        if not zip_path.is_file() or zip_path.is_symlink() or zip_path.stat().st_size > 1024 * 1024:
            raise MasterBridgeBlocked('MASTER_ZIP_UNAVAILABLE_OR_UNSAFE')
        # Compare the whole exact archive before any extraction or execution.
        if hashlib.sha256(zip_path.read_bytes()).hexdigest() != MASTER_SHA256:
            raise MasterBridgeBlocked('MASTER_ZIP_SHA256_MISMATCH')
        with zipfile.ZipFile(zip_path, 'r') as archive:
            members = archive.infolist()
            files = [info for info in members if not info.is_dir()]
            if len(files) != 21 or sum(i.file_size for i in files) > 1024 * 1024:
                raise MasterBridgeBlocked('MASTER_ARCHIVE_MANIFEST_MISMATCH')
            seen = set()
            for info in members:
                name = info.filename
                parts = Path(name).parts
                if (name in seen or not parts or parts[0] != MASTER_ROOT or Path(name).is_absolute()
                        or '..' in parts or '\\' in name or '\x00' in name
                        or (info.external_attr >> 16) & 0o170000 == stat.S_IFLNK):
                    raise MasterBridgeBlocked('MASTER_ARCHIVE_UNSAFE_MEMBER')
                seen.add(name)
            if archive.testzip() is not None:
                raise MasterBridgeBlocked('MASTER_ZIP_CRC_INVALID')
            archive.extractall(directory)
    except (zipfile.BadZipFile, OSError) as exc:
        raise MasterBridgeBlocked('MASTER_ARCHIVE_UNREADABLE') from exc
    controller = directory / MASTER_ROOT / 'devnet-qa-automation' / 'controller.py'
    if not controller.is_file() or controller.is_symlink():
        raise MasterBridgeBlocked('MASTER_CONTROLLER_MISSING')
    return controller


def _stop_group(proc):
    if proc.poll() is not None:
        return
    try:
        os.killpg(proc.pid, signal.SIGTERM)
        proc.wait(timeout=4)
    except subprocess.TimeoutExpired:
        os.killpg(proc.pid, signal.SIGKILL)
        proc.wait(timeout=4)
    except ProcessLookupError:
        pass


def run_pinned_master(zip_path: Path, record, *, gaming, timeout=600):
    """Run exactly one existing registered Master QA VM-repair diagnostic."""
    recheck_registration(record)
    if gaming():
        raise MasterBridgeBlocked('GAMING_OR_VR_ACTIVE')
    with tempfile.TemporaryDirectory(prefix='devnet-master-bridge-v023-') as temporary:
        temp = Path(temporary)
        controller = extract_pinned_master(zip_path, temp)
        output = temp / 'master-output.txt'
        with output.open('xb') as f:
            os.fchmod(f.fileno(), 0o600)
            proc = subprocess.Popen([sys.executable, str(controller), 'master-autorepair'],
                                    stdin=subprocess.DEVNULL, stdout=f, stderr=subprocess.STDOUT,
                                    cwd=record['root'], start_new_session=True)
            started = time.monotonic()
            while proc.poll() is None:
                if gaming():
                    _stop_group(proc)
                    raise MasterBridgeBlocked('GAMING_INTERRUPTED_MASTER_QA')
                if time.monotonic() - started > timeout:
                    _stop_group(proc)
                    raise MasterBridgeBlocked('MASTER_QA_TIMEOUT')
                if output.stat().st_size > 65536:
                    _stop_group(proc)
                    raise MasterBridgeBlocked('MASTER_QA_OUTPUT_TOO_LARGE')
                time.sleep(0.25)
        if proc.returncode != 0:
            raise MasterBridgeBlocked('MASTER_QA_PROCESS_NONZERO')
        if output.stat().st_size > 65536:
            raise MasterBridgeBlocked('MASTER_QA_OUTPUT_TOO_LARGE')
        lines = output.read_text(encoding='utf-8').strip().splitlines()
        if len(lines) != 1:
            raise MasterBridgeBlocked('MASTER_QA_OUTPUT_NOT_MACHINE_READABLE')
        try:
            result = json.loads(lines[0])
        except (json.JSONDecodeError, UnicodeDecodeError) as exc:
            raise MasterBridgeBlocked('MASTER_QA_JSON_INVALID') from exc
        if (type(result) is not dict or result.get('release_approved') is not False
                or result.get('user_acceptance_ready') is not False
                or result.get('trusted_evidence') is not False):
            raise MasterBridgeBlocked('MASTER_QA_RESULT_UNVERIFIED')
        recheck_registration(record)
        phase = result.get('decision')
        # An in-progress/failed stage NEVER represents a complete release.
        if phase != 'AWAITING_GITHUB_RETEST':
            return {'status': 'BLOCKED', 'reason': 'MASTER_STAGE_' + str(phase)[:40],
                    'release_approved': False, 'trusted_evidence': False}
        report = result.get('report')
        if (type(report) is not dict or report.get('stage') != 'vm'
                or report.get('release_approved') is not False or result.get('attempts') not in (1, 2, 3)
                or report.get('outcome') not in ('VM_DIAGNOSTIC_PASS_GITHUB_RETEST_REQUIRED',
                                                  'ALREADY_PASSES_PRELIMINARY_ONLY')):
            raise MasterBridgeBlocked('MASTER_STAGE_REPORT_INVALID')
        state_file = record['work'] / 'checkpoint.json'
        state = json.loads(_private_regular_file(state_file, 65536))
        if (state.get('phase') != 'AWAITING_GITHUB_RETEST'
                or state.get('job_id') != record['job_id']
                or state.get('revision_sha256') != record['revision_sha256']
                or state.get('release_approved') is not False
                or state.get('user_acceptance_ready') is not False
                or state.get('attempts') != result['attempts']
                or type(state.get('history')) is not list or not state['history']
                or state['history'][-1] != report):
            raise MasterBridgeBlocked('MASTER_STAGE_CHECKPOINT_INVALID')
        initial = report.get('initial')
        if type(initial) is not dict or not initial or any(v not in ('PASS','FAIL') for v in initial.values()):
            raise MasterBridgeBlocked('MASTER_INITIAL_STAGE_NOT_VERIFIED')
        if report['outcome'] == 'VM_DIAGNOSTIC_PASS_GITHUB_RETEST_REQUIRED':
            if all(v == 'PASS' for v in initial.values()):
                raise MasterBridgeBlocked('MASTER_REPAIR_WITHOUT_FAILURE')
            retest = report.get('retest')
            research = report.get('web_research')
            if (type(retest) is not dict or not retest or set(retest) != set(initial)
                    or any(v != 'PASS' for v in retest.values())
                    or type(research) is not dict
                    or research.get('status') != 'RESEARCH_COMPLETE_UNTRUSTED'
                    or type(research.get('evidence_sha256')) is not str
                    or not HEX.fullmatch(research['evidence_sha256'])):
                raise MasterBridgeBlocked('MASTER_WEB_RESEARCH_OR_VM_RETEST_NOT_VERIFIED')
            research_path = record['work'] / ('attempt-' + str(result['attempts'])) / 'web-research.json'
            evidence = json.loads(_private_regular_file(research_path, 131072))
            if (type(evidence) is not dict or evidence.get('evidence_sha256') != research['evidence_sha256']
                    or evidence.get('job_id') != record['job_id']
                    or evidence.get('revision_sha256') != record['revision_sha256']
                    or evidence.get('decision') != 'RESEARCH_COMPLETE_UNTRUSTED'
                    or evidence.get('trusted_evidence') is not False
                    or evidence.get('release_approved') is not False):
                raise MasterBridgeBlocked('MASTER_RESEARCH_EVIDENCE_INVALID')
        elif any(v != 'PASS' for v in initial.values()):
            raise MasterBridgeBlocked('MASTER_PRELIMINARY_PASS_INCONSISTENT')
        return {'status': 'PASS_LIMITED', 'next_stage': 'GITHUB_RETEST_REQUIRED',
                'release_approved': False, 'trusted_evidence': False,
                'job_id': record['job_id'], 'registered_revision_sha256': record['revision_sha256'],
                'checkpoint': str(state_file)}
