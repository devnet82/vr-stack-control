# Devnet OpenCode Auto-Router v0.2.3 — QA BLOCKED

**Status:** New isolated experimental QA candidate. No installation, production changes, automated release or trusted evidence. All previous verified v0.2.2 and Master QA v0.3.8 inputs are unchanged.

## v0.2.3 — pinned Master QA handoff after OpenCode

This bridges the previously proven **deterministic** `--qa-after` architecture to the **existing** registered `master-autorepair` entrypoint of Devnet Unified Master QA v0.3.8. It adds `--master-qa-after` and mandatory `--master-qa-zip` (exact SHA-256 `de83312d81636c8f92802060fc516188dc46b62b6d246bf6cc3d2361f0a1500c`). The old `--qa-after` remains strictly ROUTER-ONLY and is not silently re-labelled as application QA.

1. Before requesting a model response, read the operator-approved, private `~/.config/devnet-qa-automation/master-repair-job.json`. Require a valid registered source below `/mnt/devnet-ai/projects`, a private workspace below `/mnt/devnet-ai/qa`, bounded VM test plan, exact revision hash, explicitly authorised VM diagnostic and approved upstream GitHub research topics. **If absent/stale, BLOCK before OpenCode launches.**
2. Validate the actual pinned Master QA ZIP before executing any source files. The bundled OpenCode task runs from this **router QA project directory**, which denies model-driven editing or shell commands; it is **never launched in the original application source tree**. A model's text cannot execute tests or modify protected registrations. An unexpected source or registration change causes a block.
3. After a successful real OpenCode task with structured session events and no fake tool-call text, the controller launches `master-autorepair` in a bounded child process **outside the router lock**. This is the one existing registered Master QA controller; it will run its authorised VM diagnostic, search approved upstream GitHub issues/PRs only after a verified failure, propose a narrowly bounded local Ollama repair and retest all declared VM tests on a disposable VM copy. Interruptions from gaming/VR stop only the owned child process group.
4. The bridge checks the exact Master QA JSON outcome, durable checkpoint, job/revision, research receipt and VM retest status before reporting **`PASS_LIMITED`**. The only acceptable next stage is `GITHUB_RETEST_REQUIRED`, never release approval. If the registered plan is missing or incomplete, or the VM job blocks, the bridge returns a nonzero result. It never substitutes the old 88-test router regression for application QA.
5. **No automatic full application testing or releases are claimed**. Master QA v0.3.8 only has registered, bounded Python VM diagnostics; real application GUI/tray, install/upgrade/rollback, trusted attestation, full GitHub post-repair retest and user acceptance remain separately BLOCKED/NOT TESTED. The local model's native Ollama tool-call parser is still broken in the reported scenario. This new mode does not attempt to parse or execute raw `<function=...>` text.

Example only after registering a specific authorised application and verifying GitHub and VM first:

```fish
python3 auto_route.py --master-qa-after --master-qa-zip ~/Downloads/devnet-master-qa-unified-v0.3.8-QA-BLOCKED.zip 'Explain the expected diagnostic path for my registered application. Do not use tools or modify files.'
```

**Current user environment:** the last read-only check found `master-repair-job.json` MISSING. Until an operator-reviewed real job is registered, this mode **must block before launching OpenCode**. Do not install a timer or create a default registration. Use the already demonstrated *disposable* v0.3.8 live VM+internet probe for any temporary integration tests.

### Upstream research consulted before this implementation

- OpenCode tool permissions, official: https://docs.opencode.ai/docs/tools/ (`permission` object; source configuration is restricted).
- OpenCode project custom tools, official: https://docs.opencode.ai/docs/custom-tools/ (the existence of a TypeScript file does not prove actual model invocation).
- OpenCode `opencode run` automation, official: https://dev.opencode.ai/v2/docs/cli/ (noninteractive execution).
- Ollama Qwen3-Coder parser failure: https://github.com/ollama/ollama/issues/18530 (structured `tool_calls` may be lost; do not use model text as a tool invocation).

---

# Devnet OpenCode Auto-Router v0.2.2 — QA BLOCKED

**Status: experimental QA candidate; no installation, production attestation or release approval.** This continues the verified v0.1.7 router without replacing the separate installed model router or Master QA controller.

## v0.2.2 — correct OpenCode config and deterministic QA after OpenCode

- Official OpenCode docs (https://opencode.ai/docs/permissions/) specify an object under `permission` (singular); the v0.2.1 package mistakenly used a `permissions` list. The uniquely named project-local tool remains unchanged; official custom-tool docs still use `@opencode-ai/plugin` under `.opencode/tools/` (https://opencode.ai/docs/custom-tools/). These are project-local settings, never a replacement for the user's production OpenCode configuration.
- Ollama issue https://github.com/ollama/ollama/issues/18530 matches the *real host* reproduction: qwen3-coder:30b emitted raw `<function=...>` text and no structured `tool_calls`. The parser fix is not verified in the installed 0.40.13. **This candidate does not repair the Ollama parser or falsely claim native model tool calls work.** No execution from raw text.
- New explicit `--qa-after` **only after an OpenCode task successfully exits**: runs the same approved `--qa-run all --qa-ai-review` controller outside the OpenCode router lock, preventing nested lock deadlocks, and saves private evidence. It can never expand its allowlist, approve release, or satisfy full Master QA by itself. If OpenCode text contains fake XML-style tool markup, the strict mode fails closed before QA-after is reported as passed.
- Default router behaviour remains unchanged without this flag. False model tool-call text is never interpreted as an executable command. Production Ollama/OpenCode/QA settings are not modified.
- Example from an extracted QA candidate directory: `python3 auto_route.py --qa-after "Debug Python script"`. This runs the approved 88-test router regression and limited simulated session-recovery job only **if** OpenCode exits successfully and emits no raw tool-call markup; it then requests advisory-only Ollama review. It does not test the edited application automatically. Both runs retain `release_approved:false`.
- Existing direct mode `python3 auto_route.py --qa-run all --qa-ai-review` remains available when OpenCode tool calling is broken. This is the proven, deterministic limited-QA workflow, and does not require any native tool-call parsing.
- Host OpenCode registration, model tool-calling reliability, full Master QA policy, actual gaming and application installation/rollback require separate evidence. A green unit suite is not sufficient.
- Required acceptance still includes GitHub, real CachyOS VM, and host end-to-end tests. Full Master QA release remains BLOCKED.

## Previous verified evidence

- v0.1.7: GitHub 88/88 and CachyOS VM 88/88 PASS.
- On the host: real OpenCode session-ID capture, automatic Qwen3.5:9b ↔ Qwen3-Coder:30b model switching and conversation retention PASS; isolated manual game flag, a WayVR-named `/proc` stand-in and a controlled live inference interruption/recovery using the exact session ID PASS_LIMITED.
- True game/VR launch, independent trusted production attestation, installation/upgrade/rollback and full GUI/tray QA remain **NOT TESTED**.
- The model previously printed fake `shell` tool-call markup instead of invoking the approved QA program. That is **not** successful tool execution.

## v0.2.1 — fix live OpenCode custom-tool collision (QA CANDIDATE)

- Actual v0.2.0 host integration probe returned the **existing** `DEVNET_MASTER_QA_v0.1.7_BLOCKED` report with eight old Master QA categories, rather than router regression evidence. OpenCode ran or described the wrong same-named tool `devnet_qa`; no new `/mnt/devnet-ai/qa/router-qa-*/result.json` appeared. **Live OpenCode router tool execution: NOT VERIFIED.** Do not touch, replace or reconfigure the installed Master QA integration.
- Rename the bundled project-local tool to **`devnet_router_regressions_v021`**. `opencode.json` denies all tools by default, explicitly denies the old `devnet_qa` name, and allows only this unique router tool. OpenCode names custom tools from filenames; the naming and collision rules are documented at https://docs.opencode.ai/docs/custom-tools/ .
- The new tool accepts **no user/model parameters**, invokes only the fixed pinned `router-regressions-v017` dispatcher and returns success **only** after checking the exact 88-test result, pinned source hash, run ID, `PASS_LIMITED`, release gate, the independent private evidence file, and the SHA-256 digest of the real regression log. No model-generated text or older Master QA output can satisfy its verification.
- Sixteen additional tests check collision avoidance, allowlist, fixed command, evidence authenticity conditions, safe output and no route to the old QA tool. Parent gaming policy and router locking remain unchanged; this custom tool cannot run the nested live interruption/recovery job.
- All GitHub, VM, host and custom-tool acceptance of this exact candidate remain PENDING until rerun. The previous v0.2.0 GitHub and VM 139/139 PASS, and real-host deterministic QA plus Qwen3-Coder advisory PASS_LIMITED (`QA_EXIT: 0`), are preserved as previous-version evidence only.

## v0.2.0 Ollama review schema fix (QA CANDIDATE)

- Verified v0.1.9 GitHub 125/125 PASS and CachyOS VM 125/125 PASS. Live host dispatcher: baseline 88/88 PASS, simulated interrupted exact-session recovery PASS_LIMITED, but optional Qwen3-Coder:30b advisory returned `AI_REVIEW_SCHEMA_INVALID`. The cycle correctly stayed `BLOCKED` with `release_approved:false`.
- The v0.1.9 worker requested only generic JSON, which does not guarantee **field types**. v0.2.0 asks Ollama for an explicit JSON Schema requiring exactly three advisory strings: `summary`, `remaining_risks`, `next_checks`.
- Defensive backwards compatibility accepts **bounded** string lists for risks/checks, converts them to advisory text, and still rejects nested objects, mixed/oversized lists, missing/extra keys, failed completions and attempted release-approval fields. No model field can change test statuses or approve a release.
- Fourteen new test cases cover schema content, success, list normalization, all key fail-closed cases, response truncation and evidence immutability. Full candidate regression tests run before any GitHub/VM/host phase. **Historical at v0.2.0 build time.** Subsequent v0.2.0 host run confirmed actual Qwen3-Coder advisory output (`ADVISORY_ONLY`) and `QA_EXIT: 0`; the separate custom-tool invocation failed because it used the existing Master QA integration instead.

## v0.1.9 host regression fix and review diagnostics

- **Observed 2026-10-30:** v0.1.8 GitHub and VM each passed 119/119, but a real host invocation of `--qa-run all --qa-ai-review` stopped after the inherited 88-test job failed 2 tests and AI review returned `LOCAL_AI_WORKER_FAILED`. **Do not treat this host cycle as a PASS.**
- The two failed inherited assertions (`test_conflicting_model_blocks`, `test_guard_blocks_while_lock_held`) assume strict default Ollama model-conflict blocking. The user's host may have explicitly enabled **persistent native auto-handover**, which legitimately permits the model and invalidates those test assumptions. v0.1.9 runs the pinned old tests under a **private HOME and XDG directories** instead of disabling or changing the user's setting. The supervising dispatcher still uses the genuine host game/VR detector before and during subprocess execution.
- Fixed codes (`AI_REVIEW_HTTP_<status>`, `AI_REVIEW_CONNECTION`, `AI_REVIEW_TIMEOUT`, `AI_REVIEW_JSON_INVALID`, `AI_REVIEW_SCHEMA_INVALID`, etc.) now distinguish AI-review worker failures. Full error bodies, model responses and secret prompts are **not** included in diagnostics. They remain fail-closed and untrusted; the actual host AI review failure cause is still **NOT VERIFIED** pending a new live run.
- Six new automated regression checks cover the enabled host setting, preserved source config and isolated subprocess environment, worker HTTP/schema errors, and safe diagnostic forwarding. **Historical v0.1.9 build notes.** This version subsequently passed GitHub and VM 125/125; the v0.1.9 host inherited tests and recovery passed, while AI review was blocked for schema mismatch.
- The v0.1.7 recovery fixture still tests a controlled interruption, not a real game. No release is approved.

## What v0.1.8 introduced

1. `auto_route.py --qa-list` lists only approved tests.
2. `auto_route.py --qa-run router-regressions-v017` executes the exact SHA-256-pinned v0.1.7 ZIP in a **real** isolated Python subprocess and requires all 88 tests to pass.
3. `auto_route.py --qa-run exact-session-recovery-v017` invokes the exact SHA-256-pinned known-good recovery fixture in a separate supervised process, verifies the result.json evidence, and preserves the original ZIP. The original v0.1.7 ZIP is expected in `~/Downloads` for this fixture.
4. `auto_route.py --qa-run all` executes the two approved checks, stopping on a failure or unsafe condition. The controller **never accepts arbitrary commands or paths from a language model**. Execution occurs outside the OpenCode task lock, avoiding nested-lock deadlocks.
5. `--qa-ai-review` optionally asks **local Qwen3-Coder:30b** to review the evidence through a supervised non-shell Ollama subprocess. It can provide only advisory text; gaming/VR detection is checked during the request and stops the owned client process. If requested AI review fails, the overall cycle stays BLOCKED even when the individual tests passed. It cannot edit sources, approve a release or alter the test verdicts.
6. Results and bounded logs are written to uniquely named private directories under `/mnt/devnet-ai/qa/router-qa-<24 hex ID>/`. Report and log files carry SHA-256 digests and `release_approved: false`, `trusted_evidence: false`, `user_acceptance_ready: false`. `--qa-status <run-id>` inspects the private report without executing tests.
7. The optional **project-local** `.opencode/tools/devnet_router_regressions_v021.ts` exposes only the fixed v0.1.7 regression job to the model. `opencode.json` denies other tool actions in this QA project. A model can still fail to call its tool; the controller's deterministic `--qa-run` path is the reliable fallback, independent of model-generated shell markup. Live session recovery is not exposed as a nested OpenCode tool because the outer router may already hold the concurrency lock.

## Execution (host, after GitHub and VM first)

Only from the extracted exact v0.2.1 ZIP, while not gaming:

```
python3 auto_route.py --qa-run all --qa-ai-review
```

The Ollama review is optional; omit `--qa-ai-review` for purely deterministic checks. The fixed v0.1.7 input ZIP is inside the v0.2.1 package for the regression job; the original `~/Downloads/devnet-opencode-auto-router-v0.1.7-QA-BLOCKED.zip` is independently verified by the approved recovery runner.

`python3 auto_route.py --qa-list` or `python3 auto_route.py --qa-status <run-id>` are read-only.

## Limits and fail-closed policy

- A **local** test result is preliminary, even if all checks pass. No local AI can sign release approval; no new build bypasses GitHub-first → existing VM → host/hardware → user acceptance.
- Running a Python subprocess or a custom OpenCode tool on the host does not by itself sandbox it. Only bundled, SHA-256-pinned fixed QA scripts and fixed arguments are allowed; run candidates only in the intended isolated QA setup.
- The optional OpenCode TypeScript tool has **not yet been verified live** on the user's particular OpenCode build; its execution cannot be claimed solely from static tests. Never trust text that looks like a tool call without independent evidence.
- The regression job checks the **known-good v0.1.7 baseline**. each candidate's own complete suite is tested separately by GitHub and the QA VM for each revision.
- The recovery job is a controlled *simulated gaming interruption* of real inference, not a real game launch. It requires an otherwise idle computer. If a game is detected, operations stop, and any model request may take time to release GPU residency at Ollama level.
- The QA dispatcher can **only** collect and inspect preliminary evidence, not install upgrades, invoke unrestricted shells, test arbitrary applications, publish releases, or approve releases.

**Master QA release gate: BLOCKED.**
