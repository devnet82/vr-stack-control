"""v0.2.1 router custom tool must never route to existing Master QA."""
import json
from pathlib import Path
import re
import unittest
from unittest import mock
import qa_dispatch as q

ROOT=Path(__file__).resolve().parent
NAME='devnet_router_regressions_v021'

class ToolCollisionTests(unittest.TestCase):
    def get_tool(self):
        return (ROOT/'.opencode/tools'/f'{NAME}.ts').read_text()

    def test_unique_project_tool_file_not_existing_master_qa(self):
        files=list((ROOT/'.opencode/tools').glob('*.ts'))
        self.assertEqual([f.name for f in files],[f'{NAME}.ts'])
        self.assertFalse((ROOT/'.opencode/tools/devnet_qa.ts').exists())

    def test_open_code_filename_is_the_requested_tool_name(self):
        code=self.get_tool()
        self.assertIn('export default tool({',code)
        self.assertIn(f'tool: "{NAME}"',code)

    def test_rule_denies_existing_master_qa_collision(self):
        cfg=json.loads((ROOT/'opencode.json').read_text())
        self.assertNotIn('permissions', cfg)
        self.assertEqual(cfg['permission'], {
            '*': 'deny',
            'devnet_qa': 'deny',
            NAME: 'allow',
        })

    def test_tool_runs_only_fixed_router_regressions(self):
        code=self.get_tool()
        self.assertIn('"/usr/bin/python3", dispatcher, "--run", "router-regressions-v017"',code)
        self.assertNotIn('"exact-session-recovery-v017"',code)
        self.assertNotIn('shell: true',code)
        self.assertNotIn('eval(',code)
        self.assertNotIn('exec(',code)
        self.assertNotIn('devnet-qa/bin',code)
        self.assertNotIn('MASTER_QA_v0.1.7',code)

    def test_dispatcher_has_no_route_to_master_qa_runner(self):
        src=(ROOT/'qa_dispatch.py').read_text()
        self.assertNotIn('devnet_qa',src)
        self.assertNotIn('master-qa-v0.1.7',src)
        self.assertEqual(q.JOBS[0],'router-regressions-v017')

    def test_tool_refuses_process_failed(self):
        code=self.get_tool()
        self.assertIn('exitCode !== 0',code)
        self.assertIn('DEVNET_ROUTER_TOOL_EXECUTION_BLOCKED',code)

    def test_tool_refuses_missing_or_ambiguous_evidence(self):
        code=self.get_tool()
        self.assertIn('reports.length !== 1 || paths.length !== 1',code)
        self.assertIn('DEVNET_ROUTER_TOOL_EVIDENCE_MISSING',code)

    def test_tool_refuses_forged_approval(self):
        code=self.get_tool()
        self.assertIn('report?.release_approved !== false',code)
        self.assertIn('report?.trusted_evidence !== false',code)
        self.assertIn('report?.user_acceptance_ready !== false',code)

    def test_tool_requires_actual_88_test_result_and_run_id(self):
        code=self.get_tool()
        self.assertIn('job?.executed_tests !== 88',code)
        self.assertIn('job?.status !== "PASS"',code)
        self.assertIn('/^[0-9a-f]{24}$/',code)
        self.assertIn('job?.exit_code !== 0',code)

    def test_tool_requires_exact_private_evidence_location(self):
        code=self.get_tool()
        self.assertIn('`/mnt/devnet-ai/qa/router-qa-${id}/result.json`',code)
        self.assertIn('paths[0].slice("QA_EVIDENCE: ".length).trim() !== expectedEvidence',code)

    def test_tool_does_not_pass_untrusted_stdout_through(self):
        code=self.get_tool()
        self.assertNotIn('output: stdout',code)
        self.assertIn('stdout.length > 100000',code)
        self.assertIn('return JSON.stringify({',code)

    def test_tool_verifies_candidate_hash_as_well_as_job_result(self):
        code=self.get_tool()
        self.assertIn('report?.candidate_sha256 !== "8a72d480d403c1ecab29a4348a500b9c713a93808f97be94facba270c75d41db"',code)

    def test_tool_verifies_real_evidence_file_not_stdout_alone(self):
        code=self.get_tool()
        self.assertIn('await readFile(expectedEvidence, "utf8")',code)
        self.assertIn('isDeepStrictEqual(diskRecord, report)',code)
        self.assertIn('DEVNET_ROUTER_TOOL_EVIDENCE_MISMATCH',code)

    def test_tool_verifies_real_log_hash(self):
        code=self.get_tool()
        self.assertIn('await readFile(logPath)',code)
        self.assertIn('createHash("sha256")',code)
        self.assertIn('logDigest !== job.log_sha256',code)

    def test_tool_denies_public_or_symlink_evidence(self):
        code=self.get_tool()
        self.assertIn('await lstat(expectedEvidence)',code)
        self.assertIn('await lstat(logPath)',code)
        self.assertIn('s.isFile() && !s.isSymbolicLink()',code)
        self.assertIn('(s.mode & 0o022) === 0',code)
        self.assertIn('DEVNET_ROUTER_TOOL_PRIVATE_EVIDENCE_REQUIRED',code)

    def test_existing_router_cli_remains_unmodified(self):
        from pathlib import Path
        self.assertIn('--qa-run', (ROOT/'auto_route.py').read_text())
        self.assertEqual(q.JOBS,('router-regressions-v017','exact-session-recovery-v017'))

if __name__=='__main__':unittest.main()
