"""Security, real execution, evidence and fail-closed checks for approved QA dispatcher."""
import contextlib
import hashlib
import io
import json
import os
from pathlib import Path
import stat
import sys
import tempfile
import unittest
from unittest import mock
import urllib.error

import auto_route as router
import qa_dispatch as q

V017 = Path(__file__).resolve().parent/'baseline_v017.zip'
# In the extracted v0.1.8 candidate, the earlier v0.1.7 ZIP is not necessarily present.
# For standalone CI, exercise the real subprocess runner with a synthetic pinned archive.

class DispatchTests(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory()
        self.addCleanup(self.tmp.cleanup)
        self.base=Path(self.tmp.name)
        self.qa=self.base/'qa';self.qa.mkdir(mode=0o700)
        self.candidate=self.base/q.V017_ZIP
        self.bundle=Path(__file__).resolve().parent

    def create_valid_archive(self):
        import zipfile
        files={'README.md':'intro', 'auto_route.py':'def noop(): pass\n',
               'test_auto_route.py':'import unittest\n',
               'test_auto_handover.py':'import unittest\n',
               'test_session_recovery.py':'import unittest\n'}
        with zipfile.ZipFile(self.candidate,'w') as z:
            for n,text in files.items():z.writestr(q.V017_DIR+'/'+n,text)
        return hashlib.sha256(self.candidate.read_bytes()).hexdigest()

    def test_unknown_jobs_not_allowed(self):
        with self.assertRaisesRegex(RuntimeError,'UNKNOWN_JOB'):
            q.run_pipeline('../../../bin/sh',evidence_root=self.qa,game_check=lambda:False)

    def test_list_only_approved_jobs(self):
        out=io.StringIO()
        with contextlib.redirect_stdout(out):rc=q.main(['--list'])
        self.assertEqual(rc,0)
        self.assertIn('router-regressions-v017',out.getvalue())
        self.assertNotIn('shell',out.getvalue())

    def test_unapproved_cli_job_rejected(self):
        with contextlib.redirect_stderr(io.StringIO()):
            with self.assertRaises(SystemExit) as ctx:q.main(['--run','/bin/bash'])
        self.assertEqual(ctx.exception.code,2)

    def test_no_arbitrary_shell_source(self):
        data=(self.bundle/'qa_dispatch.py').read_text()
        self.assertNotIn('shell=True',data)
        self.assertNotIn('os.system(',data)
        self.assertNotIn('subprocess.run(args.',data)
        self.assertIn('["/usr/bin/python3"',(self.bundle/'.opencode/tools/devnet_router_regressions_v021.ts').read_text())

    def test_real_executable_mock_archive_crc_and_path(self):
        import zipfile
        self.create_valid_archive()
        with mock.patch.object(q,'V017_SHA',hashlib.sha256(self.candidate.read_bytes()).hexdigest()):
            dest=self.base/'extract'
            output=q.safe_extract(self.candidate,dest)
        self.assertEqual({f.name for f in output.glob('*.py')},{'auto_route.py','test_auto_route.py','test_auto_handover.py','test_session_recovery.py'})

    def test_archive_traversal_rejected(self):
        import zipfile
        with zipfile.ZipFile(self.candidate,'w') as z:
            z.writestr('../../escape','no')
        with self.assertRaises(RuntimeError):q.safe_extract(self.candidate,self.base/'source')

    def test_archive_symlink_rejected(self):
        import zipfile
        i=zipfile.ZipInfo(q.V017_DIR+'/auto_route.py'); i.create_system=3;i.external_attr=0o120777<<16
        with zipfile.ZipFile(self.candidate,'w') as z:z.writestr(i,'bad')
        with self.assertRaises(RuntimeError):q.safe_extract(self.candidate,self.base/'source')

    def test_pinned_hash_mismatch_blocks(self):
        self.candidate.write_bytes(b'fake')
        with self.assertRaisesRegex(RuntimeError,'QA_PINNED_HASH_MISMATCH'):
            q.require_exact_file(self.candidate,q.V017_SHA)

    def test_file_symlink_rejected(self):
        target=self.base/'target';target.write_text('hey')
        self.candidate.symlink_to(target)
        with self.assertRaisesRegex(RuntimeError,'UNSAFE_QA_FILE'):
            q.require_exact_file(self.candidate,q.V017_SHA)

    def test_gaming_prevents_pipeline_before_creation(self):
        with self.assertRaisesRegex(RuntimeError,'GAMING_OR_VR_ACTIVE'):
            q.run_pipeline('all',evidence_root=self.qa,game_check=lambda:True)
        self.assertEqual(list(self.qa.iterdir()),[])

    def test_independent_evidence_checkpoint_and_restart(self):
        def fake(job,root,**kwargs):
            return {'status':'PASS','exit_code':0,'log_sha256':'0'*64}
        with mock.patch.object(q,'run_one',side_effect=fake):
            out=io.StringIO()
            with contextlib.redirect_stdout(out):
                rc=q.run_pipeline('all',evidence_root=self.qa,game_check=lambda:False)
        self.assertEqual(rc,0)
        files=list(self.qa.glob('router-qa-*/result.json'))
        self.assertEqual(len(files),1)
        rec=json.loads(files[0].read_text())
        self.assertEqual(q.read_status(rec['run_id'],self.qa),rec)
        self.assertEqual(rec['decision'],'PASS_LIMITED')
        self.assertFalse(rec['trusted_evidence'])
        self.assertFalse(rec['release_approved'])
        self.assertEqual(stat.S_IMODE(files[0].stat().st_mode),0o600)
        self.assertEqual(stat.S_IMODE(files[0].parent.stat().st_mode),0o700)

    def test_requested_ai_review_unavailable_blocks_complete_claim(self):
        with mock.patch.object(q,'run_one',return_value={'status':'PASS','exit_code':0}):
            with mock.patch.object(q,'ai_review',return_value={'status':'BLOCKED'}):
                with contextlib.redirect_stdout(io.StringIO()):
                    rc=q.run_pipeline(q.JOBS[0],evidence_root=self.qa,
                                      game_check=lambda:False,review=True)
        self.assertEqual(rc,2)
        rec=json.loads(next(self.qa.glob('router-qa-*/result.json')).read_text())
        self.assertEqual(rec['results'][q.JOBS[0]]['status'],'PASS')
        self.assertEqual(rec['decision'],'BLOCKED')
        self.assertFalse(rec['release_approved'])

    def test_requested_ai_review_success_still_untrusted(self):
        with mock.patch.object(q,'run_one',return_value={'status':'PASS','exit_code':0}):
            with mock.patch.object(q,'ai_review',return_value={'status':'ADVISORY_ONLY'}):
                with contextlib.redirect_stdout(io.StringIO()):
                    rc=q.run_pipeline(q.JOBS[0],evidence_root=self.qa,
                                      game_check=lambda:False,review=True)
        self.assertEqual(rc,0)
        rec=json.loads(next(self.qa.glob('router-qa-*/result.json')).read_text())
        self.assertEqual(rec['decision'],'PASS_LIMITED')
        self.assertFalse(rec['trusted_evidence'])
        self.assertFalse(rec['release_approved'])

    def test_blocked_runner_halts_following_checks(self):
        calls=[]
        def fake(job,root,**kwargs):
            calls.append(job)
            raise RuntimeError('DENIED')
        with mock.patch.object(q,'run_one',side_effect=fake):
            self.assertEqual(q.run_pipeline('all',evidence_root=self.qa,game_check=lambda:False),2)
        self.assertEqual(calls,[q.JOBS[0]])
        rec=json.loads(next(self.qa.glob('router-qa-*/result.json')).read_text())
        self.assertEqual(rec['decision'],'BLOCKED')
        self.assertFalse(rec['release_approved'])

    def test_status_traversal_rejected(self):
        for bad in ['../ab','A'*24,'/etc/passwd','1'*25]:
            with self.subTest(bad=bad),self.assertRaises(RuntimeError):
                q.read_status(bad,self.qa)

    def test_status_rejects_forged_release(self):
        run='1'*24
        directory=self.qa/('router-qa-'+run);directory.mkdir(mode=0o700)
        file=directory/'result.json'
        file.write_text(json.dumps({'run_id':run,'release_approved':True,'trusted_evidence':False}))
        file.chmod(0o600)
        with self.assertRaisesRegex(RuntimeError,'UNTRUSTED_EVIDENCE_SCHEMA'):
            q.read_status(run,self.qa)

    def test_status_rejects_symlink_report(self):
        run='1'*24
        directory=self.qa/('router-qa-'+run);directory.mkdir(mode=0o700)
        target=self.base/'external';target.write_text('{}')
        (directory/'result.json').symlink_to(target)
        with self.assertRaises(OSError):q.read_status(run,self.qa)

    def test_private_dir_public_writable_blocked(self):
        self.qa.chmod(0o777)
        with self.assertRaisesRegex(RuntimeError,'UNSAFE_QA_DIRECTORY'):
            q.run_pipeline('all',evidence_root=self.qa,game_check=lambda:False)

    def test_recovery_requires_real_pinned_script(self):
        with mock.patch.object(q,'RECOVERY_SHA','0'*64):
            with self.assertRaisesRegex(RuntimeError,'QA_PINNED_HASH_MISMATCH'):
                q.run_one(q.JOBS[1],self.qa,bundle=self.bundle,candidate=self.candidate,
                          game_check=lambda:False)

    def test_ai_advice_failure_cannot_change_evidence(self):
        record={'results':{},'decision':'PASS_LIMITED','release_approved':False}
        with mock.patch.object(q,'execute',side_effect=RuntimeError('LOCAL_AI_BLOCKED')):
            advice=q.ai_review(record,game_check=lambda:False)
        self.assertEqual(advice['status'],'BLOCKED')
        self.assertFalse(record['release_approved'])
        self.assertEqual(record['decision'],'PASS_LIMITED')

    def test_ai_advice_json_is_advisory_only(self):
        def fake_exec(argv,cwd,log,**kw):
            self.assertIn('qa_review_worker.py',str(argv[1]))
            Path(log).write_text(json.dumps({'summary':'Tests run','remaining_risks':'More testing','next_checks':'VM'}))
            return 0
        with mock.patch.object(q,'execute',side_effect=fake_exec):
            advice=q.ai_review({'results':{},'decision':'PASS_LIMITED'},game_check=lambda:False)
        self.assertEqual(advice['status'],'ADVISORY_ONLY')
        self.assertFalse(advice['release_approved'])

    def test_ai_advice_malformed_blocks(self):
        def fake_exec(argv,cwd,log,**kw):
            Path(log).write_text('{"release_approved":true}')
            return 0
        with mock.patch.object(q,'execute',side_effect=fake_exec):
            result=q.ai_review({'results':{},'decision':'PASS_LIMITED'},game_check=lambda:False)
        self.assertEqual(result['status'],'BLOCKED')

    def test_ai_review_mid_request_gaming_stops_worker(self):
        def fake_exec(argv,cwd,log,**kw):
            self.assertIs(kw['game_check'], watch)
            raise RuntimeError('GAMING_OR_VR_STARTED')
        def watch():return False
        with mock.patch.object(q,'execute',side_effect=fake_exec):
            result=q.ai_review({'results':{},'decision':'BLOCKED'},game_check=watch)
        self.assertEqual(result['status'],'BLOCKED')
        self.assertEqual(result['reason'],'GAMING_OR_VR_STARTED')

    def test_project_opencode_permissions_allow_only_qa_tool(self):
        config=json.loads((self.bundle/'opencode.json').read_text())
        self.assertNotIn('permissions',config)
        self.assertEqual(config['permission'], {
            '*':'deny',
            'devnet_qa':'deny',
            'devnet_router_regressions_v021':'allow'
        })

    def test_tool_cannot_trigger_nested_router_recovery(self):
        src=(self.bundle/'.opencode/tools/devnet_router_regressions_v021.ts').read_text()
        self.assertIn('router-regressions-v017',src)
        self.assertNotIn('"exact-session-recovery-v017"',src)
        self.assertNotIn('shell: true',src)

    def test_router_qa_cli_does_not_call_opencode(self):
        out=io.StringIO()
        with mock.patch.object(router.subprocess,'Popen',side_effect=AssertionError('OpenCode started')):
            with contextlib.redirect_stdout(out):
                self.assertEqual(router.main(['--qa-list']),0)
        self.assertIn('APPROVED_QA_JOBS',out.getvalue())

    def test_router_qa_conflicts_rejected(self):
        with contextlib.redirect_stderr(io.StringIO()),self.assertRaises(SystemExit):
            router.main(['--qa-run','all','hello'])

    def test_actual_subprocess_exit_recorded(self):
        log=self.qa/'test.log'
        rc=q.execute([sys.executable,'-c','print("CHECK_EXECUTED")'],self.qa,log,
                     timeout=10,game_check=lambda:False)
        self.assertEqual(rc,0)
        self.assertIn('CHECK_EXECUTED',log.read_text())
        self.assertEqual(stat.S_IMODE(log.stat().st_mode),0o600)

    def test_safe_negative_nonzero_exit(self):
        log=self.qa/'bad.log'
        rc=q.execute([sys.executable,'-c','raise ValueError("FAILED")'],self.qa,log,
                     timeout=10,game_check=lambda:False)
        self.assertNotEqual(rc,0)
        self.assertIn('ValueError',log.read_text())

    def test_actual_game_during_subprocess_kills_owned_group(self):
        log=self.qa/'long.log'
        start=__import__('time').monotonic()
        def after():return __import__('time').monotonic()-start > 0.3
        with self.assertRaisesRegex(RuntimeError,'GAMING_OR_VR_STARTED'):
            q.execute([sys.executable,'-c','import time; time.sleep(15)'],self.qa,log,
                      timeout=8,game_check=after)

    def test_real_regressions_v017_in_candidate(self):
        result=q.run_pipeline(q.JOBS[0],evidence_root=self.qa,
                              candidate=V017,game_check=lambda:False)
        self.assertEqual(result,0)
        rec=json.loads(next(self.qa.glob('router-qa-*/result.json')).read_text())
        self.assertEqual(rec['results'][q.JOBS[0]]['executed_tests'],88)

if __name__=='__main__':unittest.main()
