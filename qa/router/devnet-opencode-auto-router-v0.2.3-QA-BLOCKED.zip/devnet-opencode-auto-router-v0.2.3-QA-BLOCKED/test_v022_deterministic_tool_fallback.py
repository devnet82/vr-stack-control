"""Regression proofs for official OpenCode config and deterministic QA fallback.

Native Ollama tool-call parsing remains unverified. Model text cannot drive QA.
"""
import contextlib
import io
import json
import sys
import tempfile
from pathlib import Path
import unittest
from unittest import mock
import auto_route as router

ROOT = Path(__file__).resolve().parent


def prepare():
    stack = contextlib.ExitStack()
    stack.enter_context(mock.patch.object(router, 'loaded_models', return_value=[]))
    stack.enter_context(mock.patch.object(router, 'gaming_active', return_value=False))
    stack.enter_context(mock.patch.object(router, 'router_lock', side_effect=lambda: contextlib.nullcontext()))
    return stack


class FallbackTests(unittest.TestCase):
    def test_official_permission_object_and_no_legacy_array(self):
        cfg = json.loads((ROOT / 'opencode.json').read_text())
        self.assertEqual(set(cfg), {'$schema','permission'})
        self.assertNotIn('permissions',cfg)
        self.assertEqual(cfg['permission'],{
            '*':'deny','devnet_qa':'deny','devnet_router_regressions_v021':'allow'})

    def test_project_tool_stays_unique_not_master_qa(self):
        files = sorted(f.name for f in (ROOT / '.opencode/tools').glob('*.ts'))
        self.assertEqual(files,['devnet_router_regressions_v021.ts'])
        txt = (ROOT / '.opencode/tools/devnet_router_regressions_v021.ts').read_text()
        self.assertIn('from "@opencode-ai/plugin"',txt)
        self.assertIn('"--run", "router-regressions-v017"',txt)
        self.assertNotIn('shell: true',txt)

    def test_default_does_not_run_qa_implicitly(self):
        with prepare(), mock.patch.object(router,'execute_task',return_value=0) as run, \
             mock.patch.object(router,'run_qa_after_success',side_effect=AssertionError('QA unexpected')):
            with contextlib.redirect_stdout(io.StringIO()):
                self.assertEqual(router.main(['Debug Python script']),0)
        run.assert_called_once_with(router.CODER,'Debug Python script',track_session=True)

    def test_qa_after_success_is_called_once(self):
        with prepare(), mock.patch.object(router,'execute_task',return_value=0) as run, \
             mock.patch.object(router,'run_qa_after_success',return_value=0) as qa:
            with contextlib.redirect_stdout(io.StringIO()):
                self.assertEqual(router.main(['--qa-after','Debug Python script']),0)
        run.assert_called_once_with(router.CODER,'Debug Python script',track_session=True,reject_fake_tool_text=True)
        qa.assert_called_once_with()

    def test_qa_after_propagates_dispatcher_block(self):
        with prepare(), mock.patch.object(router,'execute_task',return_value=0), \
             mock.patch.object(router,'run_qa_after_success',return_value=2) as qa:
            with contextlib.redirect_stdout(io.StringIO()):
                self.assertEqual(router.main(['--qa-after','Debug Python script']),2)
        qa.assert_called_once_with()

    def test_qa_after_skips_when_opencode_failed(self):
        with prepare(), mock.patch.object(router,'execute_task',return_value=2), \
             mock.patch.object(router,'run_qa_after_success',side_effect=AssertionError('QA unexpected')):
            with contextlib.redirect_stdout(io.StringIO()):
                self.assertEqual(router.main(['--qa-after','Debug Python script']),2)

    def test_qa_after_stops_if_gaming_after_task(self):
        with prepare(), mock.patch.object(router,'execute_task',return_value=0), \
             mock.patch.object(router,'gaming_active',side_effect=[False, True]), \
             mock.patch.object(router,'run_qa_after_success',side_effect=AssertionError('QA unexpectedly started')):
            with contextlib.redirect_stdout(io.StringIO()), contextlib.redirect_stderr(io.StringIO()):
                self.assertEqual(router.main(['--qa-after','Debug Python script']),2)

    def test_qa_after_runs_outside_router_lock(self):
        held = [False]
        @contextlib.contextmanager
        def lock():
            self.assertFalse(held[0])
            held[0] = True
            try: yield
            finally: held[0] = False
        def after():
            self.assertFalse(held[0], 'nested router lock would deadlock recovery')
            return 0
        with prepare(), mock.patch.object(router,'router_lock',side_effect=lock), \
             mock.patch.object(router,'execute_task',return_value=0), \
             mock.patch.object(router,'run_qa_after_success',side_effect=after) as qa:
            with contextlib.redirect_stdout(io.StringIO()):
                self.assertEqual(router.main(['--qa-after','Debug Python script']),0)
        qa.assert_called_once_with()
        self.assertFalse(held[0])

    def test_qa_after_dry_run_rejected(self):
        with contextlib.redirect_stderr(io.StringIO()),self.assertRaises(SystemExit) as ctx:
            router.main(['--qa-after','--dry-run','Debug Python script'])
        self.assertEqual(ctx.exception.code,2)

    def test_qa_after_cannot_nest_inside_qa_run(self):
        with contextlib.redirect_stderr(io.StringIO()),self.assertRaises(SystemExit) as ctx:
            router.main(['--qa-after','--qa-run','all'])
        self.assertEqual(ctx.exception.code,2)

    def test_qa_after_cannot_change_settings(self):
        with contextlib.redirect_stderr(io.StringIO()),self.assertRaises(SystemExit) as ctx:
            router.main(['--qa-after','--enable-auto-handover'])
        self.assertEqual(ctx.exception.code,2)

    @staticmethod
    def event(piece):
        return json.dumps({'type':'text','part':{'text':piece}}).encode()+b'\n'

    def test_fake_model_call_split_between_stream_events_is_rejected(self):
        stream=io.BytesIO(self.event('Explaining\n<funct')+self.event('ion=devnet_router_regressions_v021>'))
        reader=router.SessionEventReader(stream,None,router.CODER,'Test',reject_fake_tool_text=True)
        with contextlib.redirect_stdout(io.StringIO()):reader._run()
        self.assertEqual(reader.error,'UNSTRUCTURED_TOOL_CALL_TEXT')

    def test_fake_model_closing_tag_is_rejected(self):
        stream=io.BytesIO(self.event('blah\n</tool_call>'))
        reader=router.SessionEventReader(stream,None,router.CODER,'Test',reject_fake_tool_text=True)
        with contextlib.redirect_stdout(io.StringIO()):reader._run()
        self.assertEqual(reader.error,'UNSTRUCTURED_TOOL_CALL_TEXT')

    def test_regular_non_tool_prose_not_rejected(self):
        stream=io.BytesIO(self.event('This is ordinary coding advice.'))
        reader=router.SessionEventReader(stream,None,router.CODER,'Test',reject_fake_tool_text=True)
        with contextlib.redirect_stdout(io.StringIO()):reader._run()
        self.assertIsNone(reader.error)

    def test_unstructured_markup_normal_mode_keeps_backward_compat(self):
        stream=io.BytesIO(self.event('<function=explain>'))
        reader=router.SessionEventReader(stream,None,router.CODER,'Test')
        with contextlib.redirect_stdout(io.StringIO()):reader._run()
        self.assertIsNone(reader.error)

    def test_real_subprocess_fake_xml_is_blocked_before_qa(self):
        with tempfile.TemporaryDirectory() as temp:
            from pathlib import Path
            with prepare(), mock.patch.object(router,'STATE_DIR',Path(temp)/'state'), \
                 mock.patch.object(router,'command_for_task',return_value=[
                     sys.executable,'-u','-c',
                     'import json; print(json.dumps({"type":"text","part":{"text":"<function=devnet_router_regressions_v021>"}}),flush=True); print(json.dumps({"type":"text","part":{"text":"done"}}),flush=True)', 'dummy']), \
                 mock.patch.object(router,'run_qa_after_success',side_effect=AssertionError('QA must not run')):
                with contextlib.redirect_stdout(io.StringIO()), contextlib.redirect_stderr(io.StringIO()):
                    self.assertEqual(router.main(['--qa-after','Debug Python script']),2)
            record=json.loads((Path(temp)/'state/latest.json').read_text())
            self.assertEqual(record['status'],'FAILED')
            self.assertIs(record['release_approved'],False)

    def test_real_subprocess_normal_text_allows_deterministic_dispatch(self):
        with tempfile.TemporaryDirectory() as temp:
            from pathlib import Path
            with prepare(), mock.patch.object(router,'STATE_DIR',Path(temp)/'state'), \
                 mock.patch.object(router,'command_for_task',return_value=[
                     sys.executable,'-u','-c',
                     'import json; print(json.dumps({"type":"text","part":{"text":"Ordinary answer"},"sessionID":"ses_testRUN12345"}),flush=True)', 'dummy']), \
                 mock.patch.object(router,'run_qa_after_success',return_value=0) as qa:
                with contextlib.redirect_stdout(io.StringIO()), contextlib.redirect_stderr(io.StringIO()):
                    self.assertEqual(router.main(['--qa-after','Debug Python script']),0)
            qa.assert_called_once_with()
            record=json.loads((Path(temp)/'state/latest.json').read_text())
            self.assertEqual(record['status'],'COMPLETE')
            self.assertIs(record['release_approved'],False)

    def test_qa_after_is_approved_jobs_only(self):
        import inspect
        src=inspect.getsource(router.run_qa_after_success)
        self.assertIn("module.main(['--run','all','--ai-review'])",src)
        self.assertNotIn('shell=True',src)
        self.assertNotIn('os.system',src)
        self.assertNotIn('release_approved',src)

    def test_strict_detector_has_no_xml_execution(self):
        import inspect
        src=inspect.getsource(router.SessionEventReader)
        self.assertIn('UNSTRUCTURED_TOOL_CALL_TEXT',src)
        self.assertNotIn('eval(',src)
        self.assertNotIn('exec(',src)

if __name__=='__main__':unittest.main()
