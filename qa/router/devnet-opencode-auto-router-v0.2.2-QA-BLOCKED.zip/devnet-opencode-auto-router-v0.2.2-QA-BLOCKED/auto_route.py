#!/usr/bin/env python3
"""Conservative OpenCode model router with exact-session recovery and approved QA dispatcher."""
import argparse
import hashlib
import tempfile
import contextlib
import fcntl
from pathlib import Path
import json
import os
import re
import subprocess
import sys
import time
import signal
import stat
import importlib.util
import threading
import urllib.request
import urllib.error

DEFAULT = 'ollama/qwen3.5:9b'
CODER = 'ollama/qwen3-coder:30b'
CODE_TERMS = re.compile(r'\b(code|coding|program|programming|python|javascript|typescript|rust|c\+\+|bash|fish\s+shell|script|function|class|debug|bug|fix\s+(?:the\s+)?(?:code|script|app|program)|refactor|compile|build\s+(?:an?\s+)?(?:app|program|plugin)|repository|repo|unit\s+tests?|integration\s+tests?|pull\s+request|git\s+commit|api\s+endpoint|implement|failing\s+tests?|application\s+crash|app\s+crash|stack\s*trace|review\s+(?:this\s+)?diff|diff|shell\s+commands?|c#|csharp|sql\s+quer(?:y|ies)|fix\s+(?:this\s+)?failing\s+test|investigate\s+(?:my\s+)?application\s+crash)\b', re.I)

def select_model(task):
    return CODER if (CODE_TERMS.search(task) or re.search(r'\bc#(?=\s|$)', task, re.I)) else DEFAULT

def loaded_models():
    req = urllib.request.Request('http://127.0.0.1:11434/api/ps')
    with urllib.request.urlopen(req, timeout=5) as response:
        data = json.load(response)
    if not isinstance(data, dict) or not isinstance(data.get('models', []), list):
        raise RuntimeError('Unexpected Ollama response')
    return [m['name'] for m in data['models'] if isinstance(m, dict) and isinstance(m.get('name'), str)]

# Advisory lock coordinates router invocations, not independent Ollama clients.
LOCKFILE = Path('/tmp/devnet-opencode-auto-router-' + str(os.getuid()) + '.lock')
STATE_DIR = Path.home() / '.local/state/devnet-model-router'
SETTINGS_DIR = Path.home() / '.config/devnet-model-router'
SETTINGS_FILE = SETTINGS_DIR / 'settings.json'
SETTINGS_SCHEMA = 'devnet-router-settings-v1'
SESSION_RE = re.compile(r'ses_[A-Za-z0-9_-]{4,128}\Z')



# The existing QA detector is the policy source for Steam/Proton/VRChat/WiVRn.
# Missing/unreadable detector, procfs errors, or malformed status => BLOCK.
AGENT_FILE = Path.home() / '.local/lib/devnet-qa-automation/agent.py'
PAUSE = Path.home() / '.config/devnet-qa-automation/gaming-on'
STOP = Path.home() / '.config/devnet-qa-automation/stop-all'

def gaming_active():
    if PAUSE.exists() or STOP.exists():
        return True
    try:
        if not AGENT_FILE.is_file() or AGENT_FILE.is_symlink():
            return True
        spec = importlib.util.spec_from_file_location('devnet_existing_game_detector', AGENT_FILE)
        if spec is None or spec.loader is None:
            return True
        agent = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(agent)
        result = agent.gaming_now()
        if type(result) is not bool:
            return True
        if result:
            return True
        # Supplement the shared detector with WayVR, which it does not name.
        # SlimeVR may idle in the background; do not call it an active VR session.
        proc = Path('/proc')
        if not proc.is_dir():
            return True
        for entry in proc.iterdir():
            if not entry.name.isdigit():
                continue
            try:
                name = (entry / 'comm').read_text(errors='replace').strip().lower()
            except (PermissionError, FileNotFoundError, ProcessLookupError):
                continue
            if name in {'wayvr', 'wayvr-bin'}:
                return True
        return False
    except Exception:
        return True

def stop_owned_process(proc):
    # A fresh session isolates the spawned OpenCode process group; no global pkill.
    if proc.poll() is not None:
        return
    try:
        os.killpg(proc.pid, signal.SIGTERM)
        proc.wait(timeout=5)
    except subprocess.TimeoutExpired:
        os.killpg(proc.pid, signal.SIGKILL)
        proc.wait(timeout=5)
    except ProcessLookupError:
        pass

def command_for_task(model, task, *, session_id=None, continue_session=False):
    """Explicit OpenCode session handover; never invent a session id."""
    if session_id and continue_session:
        raise ValueError('Choose --session-id or --continue-session, not both')
    cmd = ['/usr/bin/opencode', 'run', '--model', model]
    if session_id:
        if not SESSION_RE.fullmatch(session_id):
            raise ValueError('Invalid OpenCode session id')
        cmd += ['--session', session_id]
    elif continue_session:
        cmd += ['--continue']
    return cmd + [task]


def record_task_state(status, model, task, *, exit_code=None, session_id=None):
    """Durable, private metadata only; no prompt or secret content."""
    STATE_DIR.mkdir(mode=0o700, parents=True, exist_ok=True)
    if STATE_DIR.is_symlink() or STATE_DIR.stat().st_mode & 0o077:
        raise RuntimeError('Unsafe router state directory permissions')
    state_file = STATE_DIR / 'latest.json'
    if state_file.is_symlink():
        raise RuntimeError('Refusing symlinked state file')
    payload = {'schema':'devnet-router-checkpoint-v1','status':status,'model':model,
               'task_sha256':hashlib.sha256(task.encode('utf8')).hexdigest(),
               'session_id':session_id, 'exit_code':exit_code, 'release_approved':False}
    fd, temp_name = tempfile.mkstemp(prefix='.checkpoint-', dir=STATE_DIR)
    try:
        with os.fdopen(fd, 'w', encoding='utf8') as f:
            os.fchmod(f.fileno(),0o600)
            json.dump(payload, f, sort_keys=True)
            f.flush()
            os.fsync(f.fileno())
        os.replace(temp_name,state_file)
        dirfd=os.open(STATE_DIR, os.O_RDONLY | os.O_DIRECTORY)
        try: os.fsync(dirfd)
        finally: os.close(dirfd)
    finally:
        if os.path.exists(temp_name): os.unlink(temp_name)



def read_interrupted_session():
    """Only resume an exact, privately stored session from a verified pause."""
    directory = STATE_DIR
    info = directory.lstat()
    if not stat.S_ISDIR(info.st_mode) or info.st_uid != os.getuid() or info.st_mode & 0o077:
        raise RuntimeError('Unsafe checkpoint directory')
    fd = os.open(directory / 'latest.json', os.O_RDONLY | os.O_NOFOLLOW)
    try:
        st = os.fstat(fd)
        if (not stat.S_ISREG(st.st_mode) or st.st_uid != os.getuid()
            or st.st_mode & 0o077 or st.st_size > 4096):
            raise RuntimeError('Unsafe interruption checkpoint')
        with os.fdopen(fd, 'r', encoding='utf8') as stream:
            fd = -1
            record = json.load(stream)
    finally:
        if fd >= 0:
            os.close(fd)
    if (type(record) is not dict or set(record) != {'schema','status','model',
             'task_sha256','session_id','exit_code','release_approved'}
        or record['schema'] != 'devnet-router-checkpoint-v1'
        or record['status'] != 'PAUSED_INTERRUPTED'
        or record['model'] not in (DEFAULT,CODER)
        or type(record['task_sha256']) is not str or not re.fullmatch(r'[0-9a-f]{64}',record['task_sha256'])
        or not isinstance(record['session_id'],str) or not SESSION_RE.fullmatch(record['session_id'])
        or record['exit_code'] != 2 or record['release_approved'] is not False):
        raise RuntimeError('No verified exact-session pause checkpoint')
    return record['session_id']


class SessionEventReader:
    """Forward model text, retain session ID only, never persist tool or prompt content."""
    def __init__(self, stream, expected_id, model, task, *, reject_fake_tool_text=False):
        self.stream = stream
        self.session_id = expected_id
        self.expected_id = expected_id
        self.model = model
        self.task = task
        self.error = None
        self.reject_fake_tool_text = reject_fake_tool_text
        self._tool_text_tail = ''
        self._thread = threading.Thread(target=self._run, name='devnet-opencode-events', daemon=True)

    def start(self):
        self._thread.start()

    def join(self):
        self._thread.join(timeout=5)
        if self._thread.is_alive():
            self.error = self.error or 'EVENT_STREAM_DID_NOT_FINISH'

    def _run(self):
        try:
            while True:
                line = self.stream.readline(262145)
                if not line:
                    return
                if len(line) > 262144 or not line.endswith(b'\n'):
                    self.error = 'OVERSIZE_OR_INCOMPLETE_EVENT'
                    return
                event = json.loads(line)
                if type(event) is not dict or type(event.get('type')) is not str:
                    self.error = 'INVALID_EVENT_SCHEMA'
                    return
                event_id = event.get('sessionID')
                if event_id is not None:
                    if (type(event_id) is not str or not SESSION_RE.fullmatch(event_id)
                        or (self.session_id is not None and self.session_id != event_id)):
                        self.error = 'SESSION_ID_MISMATCH'
                        return
                    if self.session_id is None:
                        self.session_id = event_id
                        # Save an exact ID during execution; supports restart after an abrupt stop.
                        record_task_state('RUNNING', self.model, self.task, session_id=event_id)
                if event['type'] == 'text':
                    part = event.get('part')
                    if type(part) is not dict or type(part.get('text')) is not str or len(part['text']) > 200000:
                        self.error = 'INVALID_TEXT_EVENT'
                        return
                    if self.reject_fake_tool_text:
                        combined = self._tool_text_tail + part['text']
                        # Raw function/XML markup is not an executed OpenCode tool call.
                        # Fail closed for the strict QA-after workflow; never parse or run it.
                        if re.search(r'<\s*(?:function\s*=|/?tool_call\s*>)', combined, re.I):
                            self.error = 'UNSTRUCTURED_TOOL_CALL_TEXT'
                            return
                        self._tool_text_tail = combined[-32:]
                    print(part['text'], end='' if part['text'].endswith('\n') else '\n', flush=True)
        except (OSError, UnicodeError, json.JSONDecodeError, ValueError, RuntimeError) as exc:
            self.error = 'EVENT_STREAM_ERROR_' + type(exc).__name__
        finally:
            try:
                self.stream.close()
            except OSError:
                pass


def _private_settings_dir(*, create=False):
    """Reject shared, foreign and symlinked config directories, including existing files."""
    directory = SETTINGS_DIR
    if create:
        directory.mkdir(mode=0o700, parents=True, exist_ok=True)
    elif not directory.exists() and not directory.is_symlink():
        return None
    info = directory.lstat()
    if not stat.S_ISDIR(info.st_mode) or info.st_uid != os.getuid() or (info.st_mode & 0o077):
        raise RuntimeError('Unsafe router settings directory')
    return directory


def managed_default_enabled():
    """No opt-in means strict resident-model blocking; unreadable config fails closed."""
    directory = _private_settings_dir()
    if directory is None:
        return False
    filename = directory / 'settings.json'
    try:
        fd = os.open(filename, os.O_RDONLY | os.O_NOFOLLOW)
    except FileNotFoundError:
        return False
    try:
        info = os.fstat(fd)
        if not stat.S_ISREG(info.st_mode) or info.st_uid != os.getuid() or (info.st_mode & 0o077) or info.st_size > 2048:
            raise RuntimeError('Unsafe router settings file')
        with os.fdopen(fd, 'r', encoding='utf8') as handle:
            fd = -1
            cfg = json.load(handle)
    finally:
        if fd >= 0:
            os.close(fd)
    if (type(cfg) is not dict or set(cfg) != {'schema', 'native_auto_handover', 'owner_user_id'}
        or cfg['schema'] != SETTINGS_SCHEMA or type(cfg['native_auto_handover']) is not bool
        or type(cfg['owner_user_id']) is not int or cfg['owner_user_id'] != os.getuid()):
        raise RuntimeError('Invalid router settings')
    return cfg['native_auto_handover']


def save_managed_default(enabled):
    """Atomic, private, user-authorised opt-in/out. Never edit Ollama server settings."""
    if type(enabled) is not bool:
        raise ValueError('Expected explicit boolean')
    directory = _private_settings_dir(create=True)
    # Check existing config first; a malicious symlink or malformed file cannot be overwritten.
    managed_default_enabled()
    payload = {'schema':SETTINGS_SCHEMA, 'native_auto_handover': enabled, 'owner_user_id':os.getuid()}
    fd, temp_name = tempfile.mkstemp(prefix='.settings-', dir=directory)
    try:
        with os.fdopen(fd, 'w', encoding='utf8') as handle:
            os.fchmod(handle.fileno(),0o600)
            json.dump(payload,handle,sort_keys=True)
            handle.flush()
            os.fsync(handle.fileno())
        os.replace(temp_name,directory/'settings.json')
        dirfd = os.open(directory, os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW)
        try: os.fsync(dirfd)
        finally: os.close(dirfd)
    finally:
        if os.path.exists(temp_name): os.unlink(temp_name)


def execute_task(model, task, *, session_id=None, continue_session=False, track_session=False, reject_fake_tool_text=False):
    if gaming_active():
        print('BLOCKED: Gaming, VR, manual pause or unverified detection', file=sys.stderr)
        return 2
    cmd = command_for_task(model, task, session_id=session_id, continue_session=continue_session)
    if track_session:
        cmd = cmd[:-1] + ['--format', 'json', cmd[-1]]
    record_task_state('STARTING', model, task, session_id=session_id)
    try:
        popen_kwargs = {'start_new_session':True}
        if track_session:
            popen_kwargs['stdout'] = subprocess.PIPE
        proc = subprocess.Popen(cmd, **popen_kwargs)
    except OSError:
        record_task_state('LAUNCH_FAILED', model, task, exit_code=2, session_id=session_id)
        raise
    reader = None
    if track_session:
        if proc.stdout is None:
            stop_owned_process(proc)
            record_task_state('FAILED', model, task, exit_code=2, session_id=session_id)
            return 2
        reader = SessionEventReader(proc.stdout, session_id, model, task, reject_fake_tool_text=reject_fake_tool_text)
        reader.start()
    def end_session():
        if reader:
            reader.join()
        return reader.session_id if reader else session_id
    try:
        while True:
            if reader and reader.error:
                stop_owned_process(proc)
                exact = end_session()
                record_task_state('FAILED', model, task, exit_code=2, session_id=exact)
                print('BLOCKED: OpenCode session event stream invalid: '+reader.error, file=sys.stderr)
                return 2
            rc = proc.poll()
            if rc is not None:
                exact = end_session()
                if reader and (reader.error or exact is None):
                    record_task_state('FAILED', model, task, exit_code=2, session_id=exact)
                    print('BLOCKED: Exact OpenCode session could not be verified', file=sys.stderr)
                    return 2
                record_task_state('COMPLETE' if rc == 0 else 'FAILED', model, task, exit_code=rc, session_id=exact)
                return rc
            if gaming_active():
                print('BLOCKED: Gaming/VR started; stopping router-owned OpenCode process group', file=sys.stderr)
                stop_owned_process(proc)
                exact = end_session()
                record_task_state('PAUSED_INTERRUPTED', model, task, exit_code=2, session_id=exact)
                return 2
            time.sleep(1)
    except BaseException:
        stop_owned_process(proc)
        exact = end_session()
        record_task_state('INTERRUPTED', model, task, exit_code=2, session_id=exact)
        raise

@contextlib.contextmanager
def router_lock():
    fd = os.open(LOCKFILE, os.O_CREAT | os.O_RDWR | os.O_NOFOLLOW, 0o600)
    try:
        info = os.fstat(fd)
        if info.st_uid != os.getuid() or (info.st_mode & 0o077):
            raise RuntimeError('Unsafe or foreign router lock file')
        try:
            fcntl.flock(fd, fcntl.LOCK_EX | fcntl.LOCK_NB)
        except BlockingIOError as exc:
            raise RuntimeError('Another router task is running') from exc
        yield
    finally:
        os.close(fd)

def run_qa_after_success():
    """Always run approved QA directly, after the router lock has been released.

    Ollama's model text is NEVER an execution channel. This is a limited
    router-specific QA check, not an independent Master QA release gate.
    """
    path = Path(__file__).resolve().parent / 'qa_dispatch.py'
    if path.is_symlink() or not path.is_file():
        print('QA_AFTER_BLOCKED: DISPATCHER_UNAVAILABLE', file=sys.stderr)
        return 2
    try:
        spec = importlib.util.spec_from_file_location('devnet_qa_after_dispatch',path)
        if spec is None or spec.loader is None:
            raise RuntimeError('No dispatcher')
        module = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(module)
        # These are the ONLY two QA jobs, via the allowlisted dispatcher.
        return module.main(['--run','all','--ai-review'])
    except (OSError,RuntimeError,ValueError) as exc:
        print('QA_AFTER_BLOCKED: '+type(exc).__name__,file=sys.stderr)
        return 2


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('task', nargs='?', help='Task to give OpenCode')
    parser.add_argument('--dry-run', action='store_true', help='Show choice without running OpenCode')
    sessions = parser.add_mutually_exclusive_group()
    sessions.add_argument('--session-id', help='Continue this existing OpenCode session ID')
    sessions.add_argument('--continue-session', action='store_true', help='Continue most recent OpenCode session')
    sessions.add_argument('--resume-interrupted', action='store_true', help='Use exact session ID saved by a prior gaming interruption; never replay its prompt')
    parser.add_argument('--allow-loaded-other', action='store_true', help='Explicitly permit Ollama native scheduling; may affect other Ollama clients')
    parser.add_argument('--managed-native', action='store_true', help='Opt in to Ollama native eviction and sequential router locking; no forced unload')
    settings = parser.add_mutually_exclusive_group()
    settings.add_argument('--enable-auto-handover', action='store_true',
                          help='One-time opt-in: allow Ollama native scheduling as the default for future router tasks')
    settings.add_argument('--disable-auto-handover', action='store_true',
                          help='Revoke the automatic handover opt-in; use strict blocking')
    settings.add_argument('--handover-status', action='store_true',
                          help='Read-only view of the current opt-in state')
    qa = parser.add_mutually_exclusive_group()
    qa.add_argument('--qa-run', choices=('router-regressions-v017',
                    'exact-session-recovery-v017', 'all'),
                    help='Run a fixed allowlisted QA job outside OpenCode; no model tool call required')
    qa.add_argument('--qa-status', help='Read a fixed-run-ID private QA report')
    qa.add_argument('--qa-list', action='store_true', help='List fixed approved QA jobs')
    parser.add_argument('--qa-after', action='store_true',
                        help='After successful OpenCode task, run the two approved router QA jobs and local advisory deterministically; never use model tool calls')
    parser.add_argument('--qa-ai-review', action='store_true',
                        help='Ask local Qwen3-Coder for advisory-only QA analysis after execution')
    args = parser.parse_args(argv)
    if args.qa_run or args.qa_status or args.qa_list:
        if (args.task or args.dry_run or args.session_id or args.continue_session
            or args.resume_interrupted or args.allow_loaded_other or args.managed_native
            or args.enable_auto_handover or args.disable_auto_handover
            or args.handover_status or args.qa_after):
            parser.error('QA operations cannot be combined with AI execution or settings')
        try:
            import importlib.util
            path = Path(__file__).resolve().parent / 'qa_dispatch.py'
            if path.is_symlink() or not path.is_file():
                raise RuntimeError('QA dispatcher missing or unsafe')
            spec = importlib.util.spec_from_file_location('devnet_approved_qa_dispatch', path)
            if spec is None or spec.loader is None:
                raise RuntimeError('QA dispatcher import failed')
            module = importlib.util.module_from_spec(spec)
            spec.loader.exec_module(module)
            cmd = ['--run', args.qa_run] if args.qa_run else (['--status', args.qa_status] if args.qa_status else ['--list'])
            if args.qa_ai_review:
                cmd += ['--ai-review']
            return module.main(cmd)
        except (OSError,RuntimeError) as exc:
            print('QA_BLOCKED:',str(exc)[:200],file=sys.stderr)
            return 2
    if args.qa_ai_review:
        parser.error('--qa-ai-review requires --qa-run')
    if args.qa_after and args.dry_run:
        parser.error('--qa-after requires actual execution, not --dry-run')
    if args.enable_auto_handover or args.disable_auto_handover or args.handover_status:
        if args.task:
            parser.error('Configuration actions cannot be combined with a task')
        if args.managed_native or args.allow_loaded_other or args.dry_run or args.session_id or args.continue_session or args.resume_interrupted or args.qa_after:
            parser.error('Configuration actions cannot be combined with execution options')
        try:
            with router_lock():
                if args.enable_auto_handover:
                    save_managed_default(True)
                elif args.disable_auto_handover:
                    save_managed_default(False)
                enabled = managed_default_enabled()
            print('AUTO_HANDOVER:', 'ENABLED' if enabled else 'DISABLED', flush=True)
            if args.enable_auto_handover and enabled:
                print('NOTICE: Ollama may evict idle models; independent Ollama clients are not coordinated.', flush=True)
            return 0
        except (RuntimeError, OSError, ValueError, json.JSONDecodeError) as exc:
            print('BLOCKED: Cannot safely update or read router settings: '+type(exc).__name__,file=sys.stderr)
            return 2
    if not args.task or not args.task.strip():
        parser.error('Empty task')
    try:
        command_for_task(select_model(args.task), args.task, session_id=args.session_id, continue_session=args.continue_session)
    except ValueError as exc:
        parser.error(str(exc))
    model = select_model(args.task)
    print('Selected:', model, flush=True)
    if args.dry_run:
        return 0
    # Acquire the router lock BEFORE checking residency. Otherwise another
    # router invocation could change Ollama state between check and launch.
    try:
        with router_lock():
            if gaming_active():
                print('BLOCKED: Gaming, VR, manual pause or unverified detection', file=sys.stderr)
                return 2
            try:
                active = loaded_models()
            except (urllib.error.URLError, TimeoutError, ValueError, RuntimeError, KeyError, OSError) as exc:
                print(f'BLOCKED: Cannot verify Ollama model residency: {type(exc).__name__}', file=sys.stderr)
                return 2
            # One-time user opt-in is consulted only after acquiring the lock and
            # checking gaming protection; never modify model residency directly.
            native_default = False
            if not (args.allow_loaded_other or args.managed_native):
                try:
                    native_default = managed_default_enabled()
                except (RuntimeError, OSError, ValueError, json.JSONDecodeError) as exc:
                    print('BLOCKED: Router handover settings invalid: '+type(exc).__name__,file=sys.stderr)
                    return 2
            other = [name for name in active if 'ollama/' + name != model]
            if other and not (args.allow_loaded_other or args.managed_native or native_default):
                print('BLOCKED: Other model resident (' + ', '.join(other) + '). No automatic unloading; avoid interrupting other work.', file=sys.stderr)
                return 2
            # Native scheduler handles eviction, never force-unload foreign models.
            # Lock only coordinates router-launched subprocesses, NOT outside clients.
            strict = {'reject_fake_tool_text':True} if args.qa_after else {}
            if args.resume_interrupted:
                try:
                    exact_session = read_interrupted_session()
                except (RuntimeError, OSError, ValueError, json.JSONDecodeError) as exc:
                    print('BLOCKED: No safe exact-session recovery: '+type(exc).__name__, file=sys.stderr)
                    return 2
                rc = execute_task(model, args.task, session_id=exact_session,
                                  track_session=True, **strict)
            elif args.session_id or args.continue_session:
                rc = execute_task(model, args.task, session_id=args.session_id,
                                  continue_session=args.continue_session, track_session=True,
                                  **strict)
            else:
                rc = execute_task(model, args.task, track_session=True, **strict)
        # Intentional: never run the QA recovery job while holding router_lock.
        # Its own interrupted-session fixture takes the same exclusive lock.
        if rc != 0 or not args.qa_after:
            return rc
        if gaming_active():
            print('QA_AFTER_BLOCKED: GAMING_OR_VR_ACTIVE',file=sys.stderr)
            return 2
        return run_qa_after_success()
    except (OSError, RuntimeError) as exc:
        print(f'BLOCKED: Cannot launch OpenCode safely: {type(exc).__name__}: {exc}', file=sys.stderr)
        return 2

if __name__ == '__main__':
    sys.exit(main())
