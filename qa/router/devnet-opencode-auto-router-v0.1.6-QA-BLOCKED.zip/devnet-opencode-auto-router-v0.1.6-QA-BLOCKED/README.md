# Devnet OpenCode Auto-Router v0.1.6 — QA BLOCKED

Continues v0.1.5 source and all its 41 tests. It does not replace the user's separately installed v0.4.1 model-router, OpenCode, Ollama, or Master QA controller.

## Live evidence inherited from v0.1.5

- GitHub-first Python regression suite: 41/41 PASS.
- CachyOS isolated VM Python regression suite: 41/41 PASS.
- Real Ollama/OpenCode model inference: `qwen3.5:9b` and `qwen3-coder:30b` both PASS.
- One OpenCode conversation was resumed while switching Coder -> General -> Coder, with prior function name carried across models.
- User measurements: 30b Ollama residency 15 GB, 99% GPU; 23 GiB system memory available, 2.7 GiB swap used. This is not proof of safe concurrent residency or all workloads.

## New in v0.1.6: one-time explicit handover opt-in

- `python3 auto_route.py --handover-status`: read-only, shows current preference. Defaults to `DISABLED`.
- `python3 auto_route.py --enable-auto-handover`: explicit one-time authorisation of Ollama native model management for future router tasks. This affects only the router's permission to start OpenCode; **Ollama may evict idle models**, including from other applications. Do not enable if sharing Ollama with tasks that need resident models.
- `python3 auto_route.py --disable-auto-handover`: revoke the preference, restore conservative default.
- With the opt-in, normal tasks and OpenCode continuation can switch models without `--managed-native` on every invocation. Both original explicit flags remain available.
- Private config file: `~/.config/devnet-model-router/settings.json`; strictly validated, owner/permissions checked, no symlinks, atomic write. File includes preference, schema and user ID only, not prompts, tokens or responses.
- In all modes, gaming/VR pause, exclusive router-owned task lock and Ollama availability checks still apply; the router never forces `ollama stop` or globally kills processes.

## Limitations / release requirements

- The router lock **does not coordinate other Ollama clients**. Ollama's native scheduler controls memory, but may evict an idle model that another client wants. GPU/RAM exhaustion and swap contention still possible; no guaranteed simultaneous residency for the 15 GB coding model.
- `--continue-session` continues the latest OpenCode session. Use `--session-id` if you must pin a particular session. The router itself does not migrate context; OpenCode manages sessions.
- Gaming detection depends on the installed QA agent and fails closed if it is missing or malformed.
- The router does not implement trusted full Master QA attestation, install/upgrade/rollback, live model-loading benchmarks, monitoring independent clients, or production release approval.
- Required next: exact GitHub-first test 62/62; complete CachyOS VM test 62/62; live host opt-in/out and two-way automatic handover with memory/gaming evidence; full Master QA checklist. **Release BLOCKED.**

Offline tests: `python3 -m unittest discover -s <extracted directory> -p 'test_*.py' -v`.
