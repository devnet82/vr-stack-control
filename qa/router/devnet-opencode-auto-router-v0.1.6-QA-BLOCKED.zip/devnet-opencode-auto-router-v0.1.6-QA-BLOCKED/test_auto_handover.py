"""Full positive and negative controls for the opt-in native handover preference."""
import json
import os
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch
import contextlib
import auto_route as router


class AutoHandoverTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory(prefix='router-auto-test-')
        self.addCleanup(self.temp.cleanup)
        self.dir = Path(self.temp.name)/'config'
        self.patchdir = patch.object(router,'SETTINGS_DIR',self.dir)
        self.patchdir.start()
        self.addCleanup(self.patchdir.stop)
        self.lockpatch = patch.object(router,'LOCKFILE', Path(self.temp.name)/'lock')
        self.lockpatch.start()
        self.addCleanup(self.lockpatch.stop)

    def test_default_no_config_is_strict(self):
        self.assertFalse(router.managed_default_enabled())
        with patch.object(router,'gaming_active',return_value=False),patch.object(router,'loaded_models',return_value=['qwen3.5:9b']),patch.object(router,'execute_task') as run:
            self.assertEqual(router.main(['Write Python code']),2)
            run.assert_not_called()

    def test_opt_in_is_explicit_and_durable(self):
        self.assertEqual(router.main(['--enable-auto-handover']),0)
        self.assertTrue(router.managed_default_enabled())
        self.assertEqual(self.dir.stat().st_mode & 0o777,0o700)
        self.assertEqual((self.dir/'settings.json').stat().st_mode & 0o777,0o600)
        data=json.loads((self.dir/'settings.json').read_text())
        self.assertEqual(data['schema'],router.SETTINGS_SCHEMA)
        self.assertEqual(data['owner_user_id'],os.getuid())
        self.assertIs(data['native_auto_handover'],True)

    def test_enabled_switches_models_without_per_task_flag(self):
        router.save_managed_default(True)
        with patch.object(router,'gaming_active',return_value=False),patch.object(router,'loaded_models',return_value=['qwen3.5:9b']),patch.object(router,'execute_task',return_value=0) as run:
            self.assertEqual(router.main(['Write Python code']),0)
            run.assert_called_once_with(router.CODER,'Write Python code')

    def test_enabled_switches_both_directions_with_session(self):
        router.save_managed_default(True)
        with patch.object(router,'gaming_active',return_value=False),patch.object(router,'loaded_models',return_value=['qwen3-coder:30b']),patch.object(router,'execute_task',return_value=0) as run:
            self.assertEqual(router.main(['--continue-session','Summarise our earlier answer']),0)
            run.assert_called_once_with(router.DEFAULT,'Summarise our earlier answer',session_id=None,continue_session=True)

    def test_disable_returns_to_strict_mode(self):
        router.save_managed_default(True)
        self.assertEqual(router.main(['--disable-auto-handover']),0)
        self.assertFalse(router.managed_default_enabled())
        with patch.object(router,'gaming_active',return_value=False),patch.object(router,'loaded_models',return_value=['qwen3.5:9b']),patch.object(router,'execute_task') as run:
            self.assertEqual(router.main(['Write Python code']),2)
            run.assert_not_called()

    def test_status_and_configuration_do_not_call_ollama(self):
        with patch.object(router,'loaded_models') as ollama,patch.object(router,'execute_task') as execute:
            self.assertEqual(router.main(['--handover-status']),0)
            self.assertEqual(router.main(['--enable-auto-handover']),0)
            self.assertEqual(router.main(['--handover-status']),0)
            ollama.assert_not_called()
            execute.assert_not_called()

    def test_gaming_preempts_opt_in(self):
        router.save_managed_default(True)
        with patch.object(router,'gaming_active',return_value=True),patch.object(router,'loaded_models') as loaded,patch.object(router,'execute_task') as run:
            self.assertEqual(router.main(['Write Python code']),2)
            loaded.assert_not_called()
            run.assert_not_called()

    def test_busy_lock_refuses_setting_change(self):
        with router.router_lock(),patch.object(router,'save_managed_default') as save:
            self.assertEqual(router.main(['--enable-auto-handover']),2)
            save.assert_not_called()

    def test_malformed_settings_fail_closed(self):
        self.dir.mkdir(mode=0o700)
        (self.dir/'settings.json').write_text('{ invalid')
        (self.dir/'settings.json').chmod(0o600)
        with patch.object(router,'gaming_active',return_value=False),patch.object(router,'loaded_models',return_value=['qwen3.5:9b']),patch.object(router,'execute_task') as run:
            self.assertEqual(router.main(['Write Python code']),2)
            run.assert_not_called()
        self.assertEqual(router.main(['--enable-auto-handover']),2)

    def test_symlink_settings_directory_refused(self):
        real=Path(self.temp.name)/'real'; real.mkdir(mode=0o700)
        self.dir.symlink_to(real, target_is_directory=True)
        self.assertEqual(router.main(['--enable-auto-handover']),2)
        self.assertFalse((real/'settings.json').exists())

    def test_symlink_settings_file_refused(self):
        self.dir.mkdir(mode=0o700)
        protected=Path(self.temp.name)/'protected'; protected.write_text('unchanged')
        (self.dir/'settings.json').symlink_to(protected)
        self.assertEqual(router.main(['--enable-auto-handover']),2)
        self.assertEqual(protected.read_text(),'unchanged')

    def test_public_settings_directory_refused(self):
        self.dir.mkdir(mode=0o755); self.dir.chmod(0o755)
        self.assertEqual(router.main(['--enable-auto-handover']),2)
        self.assertFalse((self.dir/'settings.json').exists())

    def test_public_settings_file_refused(self):
        self.dir.mkdir(mode=0o700)
        (self.dir/'settings.json').write_text('{}'); (self.dir/'settings.json').chmod(0o644)
        self.assertEqual(router.main(['--enable-auto-handover']),2)

    def test_foreign_owner_field_refused(self):
        self.dir.mkdir(mode=0o700)
        (self.dir/'settings.json').write_text(json.dumps({'schema':router.SETTINGS_SCHEMA,'native_auto_handover':True,'owner_user_id':os.getuid()+1}))
        self.assertEqual(router.main(['--handover-status']),2)

    def test_unexpected_config_field_refused(self):
        self.dir.mkdir(mode=0o700)
        (self.dir/'settings.json').write_text(json.dumps({'schema':router.SETTINGS_SCHEMA,'native_auto_handover':True,'owner_user_id':os.getuid(),'fake_approval':True}))
        self.assertEqual(router.main(['--handover-status']),2)

    def test_non_boolean_config_refused(self):
        self.dir.mkdir(mode=0o700)
        (self.dir/'settings.json').write_text(json.dumps({'schema':router.SETTINGS_SCHEMA,'native_auto_handover':'yes','owner_user_id':os.getuid()}))
        self.assertEqual(router.main(['--handover-status']),2)

    def test_conflicting_config_arguments_rejected(self):
        for args in [['--enable-auto-handover','Write Python code'], ['--disable-auto-handover','--managed-native'], ['--handover-status','--continue-session']]:
            with self.subTest(args=args),self.assertRaises(SystemExit):
                router.main(args)

    def test_config_has_no_model_force_unload(self):
        router.save_managed_default(True)
        with patch.object(router,'gaming_active',return_value=False),patch.object(router,'loaded_models',return_value=['qwen3.5:9b']),patch.object(router,'execute_task',return_value=0),patch.object(router.urllib.request,'urlopen') as http:
            self.assertEqual(router.main(['Write Python code']),0)
            http.assert_not_called()

    def test_loaded_models_query_failure_still_blocks_opt_in(self):
        router.save_managed_default(True)
        with patch.object(router,'gaming_active',return_value=False),patch.object(router,'loaded_models',side_effect=TimeoutError),patch.object(router,'execute_task') as run:
            self.assertEqual(router.main(['Write Python code']),2)
            run.assert_not_called()

    def test_oversize_settings_refused(self):
        self.dir.mkdir(mode=0o700)
        (self.dir/'settings.json').write_text(' '*2049)
        self.assertEqual(router.main(['--handover-status']),2)

    def test_no_implicit_session_continuation_even_auto(self):
        router.save_managed_default(True)
        with patch.object(router,'gaming_active',return_value=False),patch.object(router,'loaded_models',return_value=['qwen3.5:9b']),patch.object(router,'execute_task',return_value=0) as run:
            self.assertEqual(router.main(['Write Python code']),0)
            run.assert_called_once_with(router.CODER,'Write Python code')


if __name__ == '__main__': unittest.main()
