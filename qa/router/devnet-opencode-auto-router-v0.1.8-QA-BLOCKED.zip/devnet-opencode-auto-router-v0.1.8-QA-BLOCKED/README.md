# Devnet OpenCode Auto-Router v0.1.8 — QA BLOCKED

**Status: experimental QA candidate; no installation, production attestation or release approval.** This continues the verified v0.1.7 router without replacing the separate installed model router or Master QA controller.

## Previous verified evidence

- v0.1.7: GitHub 88/88 and CachyOS VM 88/88 PASS.
- On the host: real OpenCode session-ID capture, automatic Qwen3.5:9b ↔ Qwen3-Coder:30b model switching and conversation retention PASS; isolated manual game flag, a WayVR-named `/proc` stand-in and a controlled live inference interruption/recovery using the exact session ID PASS_LIMITED.
- True game/VR launch, independent trusted production attestation, installation/upgrade/rollback and full GUI/tray QA remain **NOT TESTED**.
- The model previously printed fake `shell` tool-call markup instead of invoking the approved QA program. That is **not** successful tool execution.

## What v0.1.8 adds

1. `auto_route.py --qa-list` lists only approved tests.
2. `auto_route.py --qa-run router-regressions-v017` executes the exact SHA-256-pinned v0.1.7 ZIP in a **real** isolated Python subprocess and requires all 88 tests to pass.
3. `auto_route.py --qa-run exact-session-recovery-v017` invokes the exact SHA-256-pinned known-good recovery fixture in a separate supervised process, verifies the result.json evidence, and preserves the original ZIP. The original v0.1.7 ZIP is expected in `~/Downloads` for this fixture.
4. `auto_route.py --qa-run all` executes the two approved checks, stopping on a failure or unsafe condition. The controller **never accepts arbitrary commands or paths from a language model**. Execution occurs outside the OpenCode task lock, avoiding nested-lock deadlocks.
5. `--qa-ai-review` optionally asks **local Qwen3-Coder:30b** to review the evidence through a supervised non-shell Ollama subprocess. It can provide only advisory text; gaming/VR detection is checked during the request and stops the owned client process. If requested AI review fails, the overall cycle stays BLOCKED even when the individual tests passed. It cannot edit sources, approve a release or alter the test verdicts.
6. Results and bounded logs are written to uniquely named private directories under `/mnt/devnet-ai/qa/router-qa-<24 hex ID>/`. Report and log files carry SHA-256 digests and `release_approved: false`, `trusted_evidence: false`, `user_acceptance_ready: false`. `--qa-status <run-id>` inspects the private report without executing tests.
7. The optional **project-local** `.opencode/tools/devnet_qa.ts` exposes only the fixed v0.1.7 regression job to the model. `opencode.json` denies other tool actions in this QA project. A model can still fail to call its tool; the controller's deterministic `--qa-run` path is the reliable fallback, independent of model-generated shell markup. Live session recovery is not exposed as a nested OpenCode tool because the outer router may already hold the concurrency lock.

## Execution (host, after GitHub and VM first)

Only from the extracted exact v0.1.8 ZIP, while not gaming:

```
python3 auto_route.py --qa-run all --qa-ai-review
```

The Ollama review is optional; omit `--qa-ai-review` for purely deterministic checks. The fixed v0.1.7 input ZIP is inside the v0.1.8 package for the regression job; the original `~/Downloads/devnet-opencode-auto-router-v0.1.7-QA-BLOCKED.zip` is independently verified by the approved recovery runner.

`python3 auto_route.py --qa-list` or `python3 auto_route.py --qa-status <run-id>` are read-only.

## Limits and fail-closed policy

- A **local** test result is preliminary, even if all checks pass. No local AI can sign release approval; no new build bypasses GitHub-first → existing VM → host/hardware → user acceptance.
- Running a Python subprocess or a custom OpenCode tool on the host does not by itself sandbox it. Only bundled, SHA-256-pinned fixed QA scripts and fixed arguments are allowed; run candidates only in the intended isolated QA setup.
- The optional OpenCode TypeScript tool has **not yet been verified live** on the user's particular OpenCode build; its execution cannot be claimed solely from static tests. Never trust text that looks like a tool call without independent evidence.
- The regression job checks the **known-good v0.1.7 baseline**. v0.1.8's own complete suite is tested separately by GitHub and the QA VM for each revision.
- The recovery job is a controlled *simulated gaming interruption* of real inference, not a real game launch. It requires an otherwise idle computer. If a game is detected, operations stop, and any model request may take time to release GPU residency at Ollama level.
- The QA dispatcher can **only** collect and inspect preliminary evidence, not install upgrades, invoke unrestricted shells, test arbitrary applications, publish releases, or approve releases.

**Master QA release gate: BLOCKED.**
