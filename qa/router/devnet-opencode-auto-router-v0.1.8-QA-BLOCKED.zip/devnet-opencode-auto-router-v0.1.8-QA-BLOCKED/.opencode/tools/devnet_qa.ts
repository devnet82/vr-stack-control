import { tool } from "@opencode-ai/plugin"
import { fileURLToPath } from "node:url"

// Optional project-local OpenCode tool. No shell or arbitrary commands.
// A model may request only the pinned regression check. Full live recovery
// must run from the top-level deterministic dispatcher to avoid nested locks.
export default tool({
  description: "Run the approved Devnet v0.1.7 router regression test (88 tests). Returns recorded evidence; cannot approve a release. For live interrupted-session checks use the separate top-level QA dispatcher.",
  args: {},
  async execute() {
    const dispatcher = fileURLToPath(new URL("../../qa_dispatch.py", import.meta.url))
    const proc = Bun.spawn(["/usr/bin/python3", dispatcher, "--run", "router-regressions-v017"], {
      stdout: "pipe", stderr: "pipe"
    })
    const [out, err, exitCode] = await Promise.all([
      new Response(proc.stdout).text(), new Response(proc.stderr).text(), proc.exited
    ])
    return JSON.stringify({exitCode, output: out.slice(-16000), error: err.slice(-2000)})
  }
})
