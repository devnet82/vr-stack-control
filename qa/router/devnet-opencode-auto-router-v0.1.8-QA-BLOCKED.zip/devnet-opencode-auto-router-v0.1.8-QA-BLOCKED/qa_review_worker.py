#!/usr/bin/env python3
"""Private bounded Ollama advisory process. Parent kills this process group if gaming starts."""
import json
import sys
import urllib.request

def main(argv):
    if len(argv) != 2:
        return 2
    from pathlib import Path
    file = Path(argv[1])
    if file.is_symlink() or file.stat().st_size > 12000:
        return 2
    prompt = file.read_text()
    request = urllib.request.Request('http://127.0.0.1:11434/api/generate',
        data=json.dumps({'model':'qwen3-coder:30b','prompt':prompt,'stream':False,
                         'think':False,'format':'json',
                         'options':{'temperature':0,'num_predict':384}}).encode(),
        headers={'Content-Type':'application/json'},method='POST')
    with urllib.request.urlopen(request,timeout=85) as response:
        if response.status != 200:
            return 2
        raw=response.read(65537)
    if len(raw)>65536:
        return 2
    result=json.loads(raw)
    if result.get('done') is not True or type(result.get('response')) is not str:
        return 2
    advice=json.loads(result['response'])
    if type(advice) is not dict or any(type(advice.get(k)) is not str for k in ('summary','remaining_risks','next_checks')):
        return 2
    print(json.dumps({k: advice[k][:800] for k in ('summary','remaining_risks','next_checks')},sort_keys=True),flush=True)
    return 0

if __name__=='__main__':
    try:sys.exit(main(sys.argv))
    except (OSError,RuntimeError,ValueError,TimeoutError,UnicodeDecodeError):sys.exit(2)
