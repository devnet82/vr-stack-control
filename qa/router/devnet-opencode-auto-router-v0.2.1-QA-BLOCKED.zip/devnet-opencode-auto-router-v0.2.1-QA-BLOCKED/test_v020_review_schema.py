"""v0.2.0 strict Ollama structured-output and advisory-only live contract."""
import contextlib
import io
import json
from pathlib import Path
import tempfile
import unittest
from unittest import mock
import qa_review_worker as w
import qa_dispatch as q

class OllamaReviewContractTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.addCleanup(self.tmp.cleanup)
        self.prompt=Path(self.tmp.name)/'input.txt'
        self.prompt.write_text('Read-only approved QA statuses; no commands or approvals.')

    def response(self, advice=None, *, done=True):
        value=json.dumps(advice if advice is not None else {
            'summary':'88 tests and session recovery passed',
            'remaining_risks':'Actual game not tested',
            'next_checks':'Verify AI advisory and tool integration'})
        body=json.dumps({'done':done,'response':value}).encode()
        class Reply:
            status=200
            def __enter__(self):return self
            def __exit__(self,*args):return None
            def read(self,n):return body
        return Reply()

    def run_with(self, advice=None, done=True):
        output=io.StringIO()
        with mock.patch.object(w.urllib.request,'urlopen',return_value=self.response(advice,done=done)) as call:
            with contextlib.redirect_stdout(output):rc=w.main(['worker',str(self.prompt)])
        return json.loads(output.getvalue()), call.call_args, rc

    def test_schema_is_strict_three_strings(self):
        data, call, rc=self.run_with()
        self.assertEqual(rc,0)
        req=call.args[0]
        body=json.loads(req.data)
        self.assertEqual(body['model'],'qwen3-coder:30b')
        self.assertEqual(body['format']['type'],'object')
        self.assertEqual(set(body['format']['required']),set(w.FIELDS))
        self.assertFalse(body['format']['additionalProperties'])
        for key in w.FIELDS:self.assertEqual(body['format']['properties'][key],{'type':'string'})
        self.assertFalse(body['stream'])
        self.assertFalse(body['think'])
        self.assertEqual(set(data),set(w.FIELDS))

    def test_string_fields_accepted(self):
        data,_,rc=self.run_with()
        self.assertEqual(rc,0)
        self.assertIn('not tested',data['remaining_risks'])

    def test_lists_of_strings_normalized_to_bounded_text(self):
        advice={'summary':'Core PASS_LIMITED','remaining_risks':['Real gaming untested','Installer untested'],
                'next_checks':['Verify review worker','Test rollback']}
        data,_,rc=self.run_with(advice)
        self.assertEqual(rc,0)
        self.assertIn('Real gaming untested',data['remaining_risks'])
        self.assertIn('Test rollback',data['next_checks'])
        self.assertIs(type(data['next_checks']),str)

    def test_empty_lists_remain_advisory_not_qA_verdicts(self):
        data,_,rc=self.run_with({'summary':'Limited checks','remaining_risks':[], 'next_checks':[]})
        self.assertEqual(rc,0)
        self.assertEqual(data['remaining_risks'],'Not specified')
        self.assertEqual(data['next_checks'],'Not specified')

    def test_nested_dict_rejected(self):
        with self.assertRaisesRegex(w.ReviewFailure,'AI_REVIEW_SCHEMA_INVALID'):
            self.run_with({'summary':'s','remaining_risks':{'x':'y'},'next_checks':'n'})

    def test_mixed_nested_array_rejected(self):
        with self.assertRaisesRegex(w.ReviewFailure,'AI_REVIEW_SCHEMA_INVALID'):
            self.run_with({'summary':'s','remaining_risks':['ok',{'x':'y'}],'next_checks':'n'})

    def test_malformed_summary_rejected(self):
        with self.assertRaisesRegex(w.ReviewFailure,'AI_REVIEW_SCHEMA_INVALID'):
            self.run_with({'summary':['not string'],'remaining_risks':'r','next_checks':'n'})

    def test_extra_release_approval_key_rejected(self):
        with self.assertRaisesRegex(w.ReviewFailure,'AI_REVIEW_SCHEMA_INVALID'):
            self.run_with({'summary':'s','remaining_risks':'r','next_checks':'n','release_approved':True})

    def test_missing_field_rejected(self):
        with self.assertRaisesRegex(w.ReviewFailure,'AI_REVIEW_SCHEMA_INVALID'):
            self.run_with({'summary':'s','remaining_risks':'r'})

    def test_more_than_eight_list_items_rejected(self):
        with self.assertRaisesRegex(w.ReviewFailure,'AI_REVIEW_SCHEMA_INVALID'):
            self.run_with({'summary':'s','remaining_risks':['x']*9,'next_checks':'n'})

    def test_huge_list_item_rejected(self):
        with self.assertRaisesRegex(w.ReviewFailure,'AI_REVIEW_SCHEMA_INVALID'):
            self.run_with({'summary':'s','remaining_risks':['x'*401],'next_checks':'n'})

    def test_incomplete_http_answer_rejected(self):
        with self.assertRaisesRegex(w.ReviewFailure,'AI_REVIEW_INCOMPLETE'):
            self.run_with(done=False)

    def test_untrusted_model_text_stays_bounded_and_advisory(self):
        advice={'summary':'x'*1600,'remaining_risks':'risk','next_checks':'check'}
        data,_,rc=self.run_with(advice)
        self.assertEqual(rc,0)
        self.assertEqual(len(data['summary']),800)
        self.assertNotIn('release_approved',data)

    def test_untrusted_worker_cannot_mutate_pass_evidence(self):
        original={'decision':'PASS_LIMITED','release_approved':False,
                  'results':{q.JOBS[0]:{'status':'PASS'}}}
        def fake_execute(argv,cwd,log,**kwargs):
            Path(log).write_text(json.dumps({'summary':'x','remaining_risks':'r','next_checks':'n'}))
            return 0
        with mock.patch.object(q,'execute',side_effect=fake_execute):
            result=q.ai_review(original,game_check=lambda:False)
        self.assertEqual(result['status'],'ADVISORY_ONLY')
        self.assertEqual(result['release_approved'],False)
        self.assertEqual(original['decision'],'PASS_LIMITED')
        self.assertEqual(original['results'][q.JOBS[0]]['status'],'PASS')

if __name__=='__main__':unittest.main()
