#!/usr/bin/env python3
"""Fixed allowlisted Devnet QA dispatcher: no arbitrary commands, files, or approvals.

This is candidate QA infrastructure, not an independent trusted release signer.
"""
import argparse
import hashlib
import json
import os
from pathlib import Path
import re
import shutil
import signal
import stat
import subprocess
import sys
import tempfile
import time
import urllib.request
import urllib.error
import zipfile

V017_ZIP = 'devnet-opencode-auto-router-v0.1.7-QA-BLOCKED.zip'
V017_DIR = 'devnet-opencode-auto-router-v0.1.7-QA-BLOCKED'
V017_SHA = '8a72d480d403c1ecab29a4348a500b9c713a93808f97be94facba270c75d41db'
RECOVERY_SHA = 'd020f62b9a86d0a3547f82dcdbc3a77d7182300ce3aaf838136acfdf0783b1ee'
QA_ROOT = Path('/mnt/devnet-ai/qa')
RUN_RE = re.compile(r'[0-9a-f]{24}\Z')
JOBS = ('router-regressions-v017', 'exact-session-recovery-v017')
MAX_LOG = 3 * 1024 * 1024


def digest(path):
    h = hashlib.sha256()
    with path.open('rb') as handle:
        for chunk in iter(lambda: handle.read(65536), b''):
            h.update(chunk)
    return h.hexdigest()


def require_private_dir(directory):
    st = directory.lstat()
    if (not stat.S_ISDIR(st.st_mode) or st.st_uid != os.getuid()
        or st.st_mode & 0o022):
        raise RuntimeError('UNSAFE_QA_DIRECTORY')
    return directory


def require_exact_file(file, sha):
    st = file.lstat()
    if not stat.S_ISREG(st.st_mode) or file.is_symlink() or st.st_size > 2 * 1024 * 1024:
        raise RuntimeError('UNSAFE_QA_FILE')
    if digest(file) != sha:
        raise RuntimeError('QA_PINNED_HASH_MISMATCH')
    return file


def safe_extract(archive, target):
    with zipfile.ZipFile(archive) as z:
        if z.testzip() is not None:
            raise RuntimeError('QA_ARCHIVE_CRC_ERROR')
        members = [m for m in z.infolist() if not m.is_dir()]
        expected = {
            V017_DIR + '/README.md', V017_DIR + '/auto_route.py',
            V017_DIR + '/test_auto_route.py', V017_DIR + '/test_auto_handover.py',
            V017_DIR + '/test_session_recovery.py'
        }
        if {m.filename for m in members} != expected:
            raise RuntimeError('QA_ARCHIVE_MEMBER_MISMATCH')
        for info in z.infolist():
            if (info.filename.startswith('/') or info.file_size > 1024 * 1024
                or (info.external_attr >> 16) & 0o170000 == 0o120000):
                raise RuntimeError('QA_ARCHIVE_UNSAFE_ENTRY')
            dest = (target / info.filename).resolve()
            if not dest.is_relative_to(target.resolve()):
                raise RuntimeError('QA_ARCHIVE_TRAVERSAL')
            if info.is_dir():
                dest.mkdir(parents=True, mode=0o700, exist_ok=True)
            else:
                dest.parent.mkdir(parents=True, mode=0o700, exist_ok=True)
                with dest.open('wb') as stream:
                    stream.write(z.read(info))
                dest.chmod(0o600)
    return target / V017_DIR


def write_atomic(path, payload):
    require_private_dir(path.parent)
    if path.is_symlink():
        raise RuntimeError('SYMLINK_EVIDENCE_REFUSED')
    fd, tmp = tempfile.mkstemp(prefix='.qa-', dir=path.parent)
    try:
        with os.fdopen(fd, 'w', encoding='utf8') as stream:
            os.fchmod(stream.fileno(), 0o600)
            json.dump(payload, stream, sort_keys=True, indent=2)
            stream.write('\n')
            stream.flush()
            os.fsync(stream.fileno())
        os.replace(tmp, path)
    finally:
        if os.path.exists(tmp):
            os.unlink(tmp)


def gaming_now():
    # Use exactly the existing router's real policy, fail closed if unavailable.
    try:
        import auto_route
        return auto_route.gaming_active() is not False
    except Exception:
        return True


def stop_group(proc):
    if proc.poll() is not None:
        return
    try:
        os.killpg(proc.pid, signal.SIGTERM)
        proc.wait(timeout=4)
    except subprocess.TimeoutExpired:
        os.killpg(proc.pid, signal.SIGKILL)
        proc.wait(timeout=4)
    except ProcessLookupError:
        pass


def execute(argv, cwd, logfile, *, timeout=150, environ=None, game_check=gaming_now):
    """Fixed exec argv, bounded log and time; no shell or arbitrary arguments from model."""
    if game_check():
        raise RuntimeError('GAMING_OR_VR_ACTIVE')
    fd = os.open(logfile, os.O_CREAT | os.O_EXCL | os.O_WRONLY | os.O_NOFOLLOW, 0o600)
    try:
        proc = subprocess.Popen(argv, cwd=cwd, env=environ, stdout=fd,
                                stderr=subprocess.STDOUT, start_new_session=True)
    except BaseException:
        os.close(fd)
        raise
    os.close(fd)
    start = time.monotonic()
    try:
        while proc.poll() is None:
            if game_check():
                raise RuntimeError('GAMING_OR_VR_STARTED')
            if time.monotonic() - start > timeout:
                raise RuntimeError('QA_EXECUTION_TIMEOUT')
            if logfile.stat().st_size > MAX_LOG:
                raise RuntimeError('QA_LOG_LIMIT_EXCEEDED')
            time.sleep(.15)
        if logfile.stat().st_size > MAX_LOG:
            raise RuntimeError('QA_LOG_LIMIT_EXCEEDED')
        return proc.returncode
    except BaseException:
        stop_group(proc)
        raise


def verify_recovery_evidence(qa_root, run_id):
    matches = list(qa_root.glob('v017-exact-session-' + run_id + '-*/result.json'))
    if len(matches) != 1:
        raise RuntimeError('RECOVERY_EVIDENCE_MISSING_OR_AMBIGUOUS')
    path = matches[0]
    if path.is_symlink() or path.stat().st_size > 12000:
        raise RuntimeError('RECOVERY_EVIDENCE_UNSAFE')
    require_private_dir(path.parent)
    record = json.loads(path.read_text())
    expected = {'schema':'devnet-router-live-recovery-qa-v1', 'candidate_sha256':V017_SHA,
                'run_id':run_id, 'acceptance':'PASS_LIMITED',
                'live_interrupted_same_session':'PASS', 'exact_session_id_preserved':True,
                'expected_reply_observed':True, 'interrupted_checkpoint_status':'PAUSED_INTERRUPTED',
                'recovery_checkpoint_status':'COMPLETE','source_untouched':True,
                'release_approved':False, 'interrupt_exit':2,'resume_exit':0,
                'session_id_captured':True,'simulation_triggered':True,
                'simulated_game_flag_only':True}
    if not isinstance(record, dict) or any(record.get(k) != v for k, v in expected.items()):
        raise RuntimeError('RECOVERY_EVIDENCE_DID_NOT_PASS')
    return {'status':'PASS','acceptance':'PASS_LIMITED',
            'evidence_sha256':digest(path),'evidence_path':str(path)}


def run_one(job, root, *, bundle, candidate, game_check=gaming_now):
    log = root / (job + '.log')
    if job == JOBS[0]:
        source = safe_extract(require_exact_file(candidate, V017_SHA), root / 'source')
        cmd = [sys.executable,'-m','unittest','discover','-s',str(source),'-p','test_*.py','-v']
        # The v0.1.7 negative tests explicitly assume strict *default* model
        # blocking. The host may have opted into managed handover. Never read,
        # alter or disable the user's real configuration to make tests pass.
        # Isolate the subprocess's HOME/XDG state; the parent and execute()
        # still use the actual host gaming detector throughout the test.
        isolated_home = root / 'regressions-home'
        isolated_home.mkdir(mode=0o700)
        env = os.environ.copy()
        env.update(HOME=str(isolated_home),
                   XDG_CONFIG_HOME=str(isolated_home / '.config'),
                   XDG_STATE_HOME=str(isolated_home / '.local/state'),
                   XDG_CACHE_HOME=str(isolated_home / '.cache'))
        env.pop('PYTHONPATH', None)
        env.pop('PYTHONHOME', None)
        rc = execute(cmd,source,log,timeout=100,environ=env,game_check=game_check)
        tail = log.read_bytes()[-5000:].decode('utf8','replace')
        count = re.search(r'Ran (\d+) tests? in', tail)
        passed = bool(rc == 0 and count and int(count.group(1)) == 88 and
                      re.search(r'(?m)^OK\s*$',tail))
        return {'status':'PASS' if passed else 'FAIL','exit_code':rc,
                'executed_tests':int(count.group(1)) if count else 0,
                'log_sha256':digest(log),'log_path':str(log)}
    if job == JOBS[1]:
        script = require_exact_file(bundle/'qa_live_recovery_v017.py',RECOVERY_SHA)
        require_exact_file(candidate,V017_SHA)
        run_id = root.name.removeprefix('router-qa-')
        env = os.environ.copy()
        env['DEVNET_ROUTER_QA_RUN_ID'] = run_id
        rc = execute([sys.executable,'-u',str(script)],root,log,timeout=120,
                     environ=env,game_check=game_check)
        if rc != 0:
            raise RuntimeError('RECOVERY_PROCESS_FAILED')
        evidence = verify_recovery_evidence(root.parent,run_id)
        evidence.update({'exit_code':rc,'log_sha256':digest(log),'log_path':str(log)})
        return evidence
    raise RuntimeError('UNKNOWN_JOB')


def ai_review(record, *, game_check=gaming_now):
    """Bounded supervised Ollama advisory. Only fixed subprocess, no tools."""
    if game_check():
        return {'status':'BLOCKED','reason':'GAMING_OR_VR_ACTIVE'}
    sanitized = {'results': record['results'], 'decision':record['decision'],
                 'release_approved':False}
    prompt = ('You are a QA diagnostics assistant. Analyse the following verified local test '
              'statuses. Never claim tests passed unless their result is PASS. Suggest only '
              'next checks, not shell commands or release approval. Return JSON object '
              'with keys summary, remaining_risks, next_checks.\n' +
              json.dumps(sanitized,ensure_ascii=True)[:7000])
    try:
        with tempfile.TemporaryDirectory(prefix='devnet-qa-review-') as temp:
            root = Path(temp)
            # tempfile is private and no shell can supply arbitrary argv.
            file = root / 'input.txt'
            file.write_text(prompt)
            file.chmod(0o600)
            log = root / 'review.log'
            worker = Path(__file__).resolve().parent / 'qa_review_worker.py'
            if worker.is_symlink() or not worker.is_file():
                raise RuntimeError('LOCAL_AI_WORKER_UNSAFE')
            rc = execute([sys.executable,str(worker),str(file)],root,log,
                         timeout=90,game_check=game_check)
            if rc != 0 or log.stat().st_size>10000:
                # Worker errors are fixed codes only, not untrusted model text.
                detail = log.read_text(errors='replace').strip()[:200]
                reason = (detail if re.fullmatch(r'AI_REVIEW_[A-Z0-9_]{1,80}', detail)
                          else 'LOCAL_AI_WORKER_FAILED')
                raise RuntimeError(reason)
            advice = json.loads(log.read_text())
            if (type(advice) is not dict or any(type(advice.get(k)) is not str
                 for k in ('summary','remaining_risks','next_checks'))):
                raise RuntimeError('LOCAL_AI_ADVICE_INVALID')
            return {'status':'ADVISORY_ONLY','model':'qwen3-coder:30b',
                    'summary':advice['summary'][:800],
                    'remaining_risks':advice['remaining_risks'][:800],
                    'next_checks':advice['next_checks'][:800],
                    'release_approved':False}
    except (OSError,ValueError,RuntimeError,TimeoutError) as exc:
        return {'status':'BLOCKED','reason':str(exc)[:160]}


def run_pipeline(selection, *, evidence_root=QA_ROOT, bundle=None, candidate=None,
                 game_check=gaming_now, review=False):
    if selection not in JOBS + ('all',):
        raise RuntimeError('UNKNOWN_JOB')
    if game_check():
        raise RuntimeError('GAMING_OR_VR_ACTIVE')
    base = require_private_dir(evidence_root)
    bundle = bundle or Path(__file__).resolve().parent
    candidate = candidate or (Path(__file__).resolve().parent/'baseline_v017.zip')
    run_id = os.urandom(12).hex()
    root = Path(tempfile.mkdtemp(prefix='router-qa-'+run_id+'-notused-',dir=base))
    # Rename so recovery driver's evidence prefix maps to the SAME run ID.
    fixed = base / ('router-qa-'+run_id)
    root.rename(fixed)
    root = fixed
    root.chmod(0o700)
    report = {'schema':'devnet-qa-dispatch-v1','run_id':run_id,
              'requested':selection,'candidate_sha256':V017_SHA,'results':{},
              'decision':'BLOCKED','trusted_evidence':False,
              'user_acceptance_ready':False,'release_approved':False}
    targets = JOBS if selection == 'all' else (selection,)
    try:
        for job in targets:
            try:
                result = run_one(job,root,bundle=bundle,candidate=candidate,game_check=game_check)
                report['results'][job] = result
            except Exception as exc:
                report['results'][job] = {'status':'BLOCKED','reason':str(exc)[:160],
                                          'error_type':type(exc).__name__}
                break
            if result['status'] != 'PASS':
                break
        if all(report['results'].get(j,{}).get('status')=='PASS' for j in targets):
            report['decision']='PASS_LIMITED'
        if review:
            report['ai_review'] = ai_review(report,game_check=game_check)
            if report['ai_review'].get('status') != 'ADVISORY_ONLY':
                # Evidence still records the exact test outcomes, but cannot claim
                # complete AI-assisted QA when the requested local AI never ran.
                report['decision'] = 'BLOCKED'
        write_atomic(root/'result.json',report)
        print('QA_RESULT:',json.dumps(report,sort_keys=True),flush=True)
        print('QA_EVIDENCE:',root/'result.json',flush=True)
        return 0 if report['decision']=='PASS_LIMITED' else 2
    except BaseException:
        write_atomic(root/'result.json',report)
        raise


def read_status(run_id, root=QA_ROOT):
    if not RUN_RE.fullmatch(run_id):
        raise RuntimeError('INVALID_RUN_ID')
    require_private_dir(root)
    directory=require_private_dir(root/('router-qa-'+run_id))
    path=directory/'result.json'
    fd=os.open(path,os.O_RDONLY|os.O_NOFOLLOW)
    try:
        st=os.fstat(fd)
        if (not stat.S_ISREG(st.st_mode) or st.st_uid!=os.getuid()
            or st.st_mode & 0o077 or st.st_size>100000):
            raise RuntimeError('UNSAFE_EVIDENCE')
        with os.fdopen(fd) as stream:
            fd=-1
            report=json.load(stream)
    finally:
        if fd>=0:os.close(fd)
    if (type(report) is not dict or report.get('run_id')!=run_id or
        report.get('release_approved') is not False or
        report.get('trusted_evidence') is not False):
        raise RuntimeError('UNTRUSTED_EVIDENCE_SCHEMA')
    return report


def main(argv=None):
    p=argparse.ArgumentParser(description=__doc__)
    actions=p.add_mutually_exclusive_group(required=True)
    actions.add_argument('--run', choices=JOBS+('all',))
    actions.add_argument('--status')
    actions.add_argument('--list',action='store_true')
    p.add_argument('--ai-review',action='store_true',help='Optional local Qwen3-Coder advisory; never executes commands')
    a=p.parse_args(argv)
    if a.ai_review and not a.run:p.error('--ai-review requires --run')
    try:
        if a.list:
            print('APPROVED_QA_JOBS:',', '.join(JOBS))
            return 0
        if a.status:
            print('QA_STATUS:',json.dumps(read_status(a.status),sort_keys=True))
            return 0
        return run_pipeline(a.run,review=a.ai_review)
    except (RuntimeError,OSError,ValueError,zipfile.BadZipFile) as exc:
        print('QA_BLOCKED:',str(exc)[:200],file=sys.stderr)
        return 2

if __name__=='__main__':
    sys.exit(main())
