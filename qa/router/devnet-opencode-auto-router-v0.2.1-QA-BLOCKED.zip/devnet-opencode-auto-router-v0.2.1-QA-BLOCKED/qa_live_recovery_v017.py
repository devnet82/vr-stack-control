#!/usr/bin/env python3
"""Bounded actual OpenCode session interruption/recovery check for Devnet router 0.1.7.

This driver is deliberately a fixed QA program, not an arbitrary command executor.
It is designed to be invoked by an OpenCode agent with permission for exactly
`python3 qa-live.py` in an isolated directory. A new OpenCode session is used,
not an existing chat. No gaming detector override, installed-file edits,
forced model unloads, or automatic replay of the interrupted task.
"""
import hashlib
import contextlib
import io
import importlib.util
import json
import os
from pathlib import Path
import re
import stat
import sys
import tempfile
import threading
import time
import zipfile

EXPECTED_ZIP = '8a72d480d403c1ecab29a4348a500b9c713a93808f97be94facba270c75d41db'
ZIP_NAME = 'devnet-opencode-auto-router-v0.1.7-QA-BLOCKED.zip'
BUNDLE = 'devnet-opencode-auto-router-v0.1.7-QA-BLOCKED'
MARKER = 'DEVNET_EXACT_SESSION_RESUME_PASS_017'


def report(path, data):
    staged = path.with_suffix('.tmp')
    staged.write_text(json.dumps(data, sort_keys=True, indent=2) + '\n')
    staged.chmod(0o600)
    os.replace(staged, path)
    print('QA_RESULT:', json.dumps(data, sort_keys=True), flush=True)


def load_record(path):
    try:
        value = json.loads(path.read_text())
        if type(value) is dict:
            return value
    except (OSError, ValueError):
        pass
    return {}


def main():
    # 1. Validate the immutable QA candidate before importing or executing it.
    z = Path.home() / 'Downloads' / ZIP_NAME
    if not z.is_file() or hashlib.sha256(z.read_bytes()).hexdigest() != EXPECTED_ZIP:
        print('QA_BLOCKED: EXACT_V017_ZIP_SHA256_MISMATCH', flush=True)
        return 2
    # Never infer that a present gaming detector means no gaming is active.
    qa_root = Path('/mnt/devnet-ai/qa')
    if not qa_root.is_dir() or qa_root.is_symlink():
        print('QA_BLOCKED: EXPECTED_PRIVATE_QA_DRIVE_UNAVAILABLE', flush=True)
        return 2
    run_id = os.getenv('DEVNET_ROUTER_QA_RUN_ID', '')
    if not re.fullmatch(r'[0-9a-f]{24}', run_id):
        print('QA_BLOCKED: MISSING_OR_INVALID_RUN_ID', flush=True)
        return 2
    root = Path(tempfile.mkdtemp(prefix='v017-exact-session-' + run_id + '-', dir=qa_root))
    root.chmod(0o700)
    result_file = root / 'result.json'
    data = {'schema': 'devnet-router-live-recovery-qa-v1',
            'candidate_sha256': EXPECTED_ZIP,
            'run_id': run_id,
            'source_untouched': True,
            'release_approved': False,
            'acceptance': 'BLOCKED',
            'live_interrupted_same_session': 'NOT_TESTED',
            'simulated_game_flag_only': True}
    try:
        with zipfile.ZipFile(z) as archive:
            if archive.testzip() is not None:
                raise RuntimeError('ARCHIVE_CRC_ERROR')
            names = archive.namelist()
            expected = BUNDLE + '/auto_route.py'
            if expected not in names or len(names) > 50:
                raise RuntimeError('UNEXPECTED_ARCHIVE_LAYOUT')
            for member in archive.infolist():
                dest = (root / member.filename).resolve()
                if not dest.is_relative_to(root.resolve()) or member.filename.startswith('/'):
                    raise RuntimeError('ARCHIVE_PATH_ESCAPE')
                if member.is_dir():
                    dest.mkdir(mode=0o700, parents=True, exist_ok=True)
                else:
                    dest.parent.mkdir(mode=0o700, parents=True, exist_ok=True)
                    dest.write_bytes(archive.read(member))
        module_path = root / BUNDLE / 'auto_route.py'
        spec = importlib.util.spec_from_file_location('qa_v017_router', module_path)
        if spec is None or spec.loader is None:
            raise RuntimeError('CANNOT_IMPORT_CANDIDATE')
        router = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(router)
        # Keep the *real* gaming and VR detector intact, including its real pause flags.
        actual_gaming_check = router.gaming_active
        if actual_gaming_check():
            raise RuntimeError('REAL_GAMING_OR_VR_ACTIVE_OR_DETECTION_UNAVAILABLE')
        # Only the router metadata for this QA run is diverted to the private workspace.
        router.STATE_DIR = root / 'private-checkpoint'
        qa_game_flag = root / 'simulated-gaming-transition.flag'
        router.gaming_active = lambda: qa_game_flag.exists() or actual_gaming_check()
        # Preserve the original /tmp lock: prevents overlap with production router work.
        original_lock = router.LOCKFILE
        data['router_lock'] = str(original_lock)
        # Use a *new project* with no shell permissions for the inner OpenCode process.
        project = root / 'empty-project'
        project.mkdir(mode=0o700)
        (project / 'opencode.json').write_text(json.dumps({'permissions': [
            {'action':'*','resource':'*','effect':'deny'}]}))
        (project / 'opencode.json').chmod(0o600)
        os.chdir(project)
        # Ask for substantial text so the event stream establishes a real session ID
        # before the router next polls for a gaming transition. No tools may run.
        long_prompt = ('Without using tools, explain in a detailed and lengthy response ' 
                       'how Python unit tests protect pure functions. Include at least ' 
                       '35 distinct numbered examples. This is a disposable QA conversation.')
        fired = threading.Event()
        stop_watch = threading.Event()
        initial_state = router.STATE_DIR / 'latest.json'
        def trigger_simulated_game():
            deadline = time.monotonic() + 45
            while not stop_watch.is_set() and time.monotonic() < deadline:
                checkpoint = load_record(initial_state)
                sid = checkpoint.get('session_id')
                if checkpoint.get('status') == 'RUNNING' and isinstance(sid,str) and router.SESSION_RE.fullmatch(sid):
                    qa_game_flag.touch()
                    fired.set()
                    return
                time.sleep(0.1)
            # If the model never establishes a session, trigger a bounded stop
            # rather than keeping the GPU task running indefinitely.
            if not stop_watch.is_set():
                qa_game_flag.touch()
                fired.set()
        watcher = threading.Thread(target=trigger_simulated_game, daemon=True)
        watcher.start()
        try:
            first_rc = router.main(['--managed-native', long_prompt])
        finally:
            stop_watch.set()
            watcher.join(timeout=2)
        first = load_record(initial_state)
        data['interrupt_exit'] = first_rc
        data['interrupted_checkpoint_status'] = first.get('status')
        data['session_id_captured'] = bool(isinstance(first.get('session_id'), str)
                                           and router.SESSION_RE.fullmatch(first.get('session_id')))
        data['simulation_triggered'] = fired.is_set()
        # Never proceed to a resume unless a real session was recorded and the
        # router really marked the first task as interrupted.
        if (first_rc != 2 or first.get('status') != 'PAUSED_INTERRUPTED'
            or not data['session_id_captured'] or not fired.is_set()):
            raise RuntimeError('SESSION_INTERRUPTION_NOT_VERIFIED')
        qa_game_flag.unlink(missing_ok=True)
        if actual_gaming_check():
            raise RuntimeError('REAL_GAMING_OR_VR_ACTIVE_AT_RECOVERY')
        exact_id = first['session_id']
        print('QA_INTERRUPTED_SESSION_ID:', exact_id, flush=True)
        # A NEW instruction, not a replay of long_prompt.
        resume_prompt = ('Do not use tools. We are resuming a conversation that was ' 
                         'interrupted for a safety test. Reply with exactly ' + MARKER + ' and nothing else.')
        # Existing router prevents guessing a different session ID on --resume-interrupted.
        captured_output = io.StringIO()
        with contextlib.redirect_stdout(captured_output):
            second_rc = router.main(['--managed-native', '--resume-interrupted', resume_prompt])
        reply_text = captured_output.getvalue()
        data['expected_reply_observed'] = MARKER in reply_text
        print('QA_RESUMED_MODEL_REPLY:', MARKER if data['expected_reply_observed'] else 'EXPECTED_MARKER_MISSING', flush=True)
        second = load_record(initial_state)
        data['resume_exit'] = second_rc
        data['recovery_checkpoint_status'] = second.get('status')
        data['exact_session_id_preserved'] = (second.get('session_id') == exact_id)
        data['source_untouched'] = (hashlib.sha256(z.read_bytes()).hexdigest() == EXPECTED_ZIP)
        if (second_rc != 0 or second.get('status') != 'COMPLETE'
            or not data['exact_session_id_preserved'] or not data['source_untouched']
            or not data['expected_reply_observed']):
            raise RuntimeError('EXACT_SESSION_RECOVERY_NOT_VERIFIED')
        data['live_interrupted_same_session'] = 'PASS'
        data['acceptance'] = 'PASS_LIMITED'
        report(result_file, data)
        print('QA_EVIDENCE_DIR:', root, flush=True)
        return 0
    except Exception as exc:
        data['error_type'] = type(exc).__name__
        data['error_code'] = str(exc)[:200]
        report(result_file, data)
        print('QA_EVIDENCE_DIR:', root, flush=True)
        return 2
    finally:
        # Ensure a leftover simulated pause never persists beyond this process.
        # It is scoped to a uniquely created QA directory, not the real pause flags.
        (root / 'simulated-gaming-transition.flag').unlink(missing_ok=True)

if __name__ == '__main__':
    sys.exit(main())
