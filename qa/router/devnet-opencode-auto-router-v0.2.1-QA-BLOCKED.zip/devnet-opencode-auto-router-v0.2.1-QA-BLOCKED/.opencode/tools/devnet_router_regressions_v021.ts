import { tool } from "@opencode-ai/plugin"
import { fileURLToPath } from "node:url"
import { readFile, lstat } from "node:fs/promises"
import { dirname } from "node:path"
import { createHash } from "node:crypto"
import { isDeepStrictEqual } from "node:util"

// Distinct from the user's pre-existing devnet_qa Master QA integration.
// This tool can only invoke the fixed 88-test router regression dispatcher.
// All unapproved commands and live session recovery remain unavailable here.
export default tool({
  description: "DEVNET ROUTER ONLY: run the pinned 88-test v0.1.7 router regression, save private evidence and return its verified run ID. Not Master QA, not a release approval.",
  args: {},
  async execute() {
    const dispatcher = fileURLToPath(new URL("../../qa_dispatch.py", import.meta.url))
    const proc = Bun.spawn(["/usr/bin/python3", dispatcher, "--run", "router-regressions-v017"], {
      stdout: "pipe", stderr: "pipe"
    })
    const [stdout, stderr, exitCode] = await Promise.all([
      new Response(proc.stdout).text(), new Response(proc.stderr).text(), proc.exited
    ])
    // Do not trust either an LLM's statement or just a subprocess exit status.
    // Require the exact dispatcher result and its independent evidence path.
    if (exitCode !== 0 || stderr.length > 4000 || stdout.length > 100000) {
      throw new Error("DEVNET_ROUTER_TOOL_EXECUTION_BLOCKED")
    }
    const reports = stdout.split("\n").filter(line => line.startsWith("QA_RESULT: "))
    const paths = stdout.split("\n").filter(line => line.startsWith("QA_EVIDENCE: "))
    if (reports.length !== 1 || paths.length !== 1) {
      throw new Error("DEVNET_ROUTER_TOOL_EVIDENCE_MISSING")
    }
    let report
    try { report = JSON.parse(reports[0].slice("QA_RESULT: ".length)) }
    catch { throw new Error("DEVNET_ROUTER_TOOL_EVIDENCE_INVALID") }
    const id = report?.run_id
    const job = report?.results?.["router-regressions-v017"]
    const expectedEvidence = `/mnt/devnet-ai/qa/router-qa-${id}/result.json`
    if (typeof id !== "string" || !/^[0-9a-f]{24}$/.test(id) ||
        report?.schema !== "devnet-qa-dispatch-v1" ||
        report?.candidate_sha256 !== "8a72d480d403c1ecab29a4348a500b9c713a93808f97be94facba270c75d41db" ||
        report?.requested !== "router-regressions-v017" ||
        report?.decision !== "PASS_LIMITED" ||
        report?.release_approved !== false ||
        report?.trusted_evidence !== false ||
        report?.user_acceptance_ready !== false ||
        job?.status !== "PASS" || job?.exit_code !== 0 ||
        job?.executed_tests !== 88 ||
        paths[0].slice("QA_EVIDENCE: ".length).trim() !== expectedEvidence) {
      throw new Error("DEVNET_ROUTER_TOOL_RESULT_NOT_VERIFIED")
    }
    // Validate evidence on disk, separately from what the dispatcher printed.
    // No success on forged stdout, missing files, symlinks, altered log content,
    // or evidence readable/writable by other users.
    const logPath = `/mnt/devnet-ai/qa/router-qa-${id}/router-regressions-v017.log`
    if (job?.log_path !== logPath || !/^[0-9a-f]{64}$/.test(job?.log_sha256 ?? "")) {
      throw new Error("DEVNET_ROUTER_TOOL_LOG_NOT_VERIFIED")
    }
    try {
      const dirInfo = await lstat(dirname(expectedEvidence))
      const evidenceInfo = await lstat(expectedEvidence)
      const logInfo = await lstat(logPath)
      const privateFile = s => s.isFile() && !s.isSymbolicLink() &&
        s.uid === process.getuid() && (s.mode & 0o022) === 0
      if (!dirInfo.isDirectory() || dirInfo.isSymbolicLink() ||
          dirInfo.uid !== process.getuid() || (dirInfo.mode & 0o022) !== 0 ||
          !privateFile(evidenceInfo) || !privateFile(logInfo) ||
          evidenceInfo.size > 16384 || logInfo.size > 3145728) {
        throw new Error("DEVNET_ROUTER_TOOL_PRIVATE_EVIDENCE_REQUIRED")
      }
      const diskRecord = JSON.parse(await readFile(expectedEvidence, "utf8"))
      if (!isDeepStrictEqual(diskRecord, report)) {
        throw new Error("DEVNET_ROUTER_TOOL_EVIDENCE_MISMATCH")
      }
      const logDigest = createHash("sha256").update(await readFile(logPath)).digest("hex")
      if (logDigest !== job.log_sha256) {
        throw new Error("DEVNET_ROUTER_TOOL_LOG_HASH_MISMATCH")
      }
    } catch (error) {
      throw new Error("DEVNET_ROUTER_TOOL_EVIDENCE_NOT_VERIFIED")
    }
    return JSON.stringify({
      tool: "devnet_router_regressions_v021",
      status: "PASS_LIMITED", executed_tests: 88,
      run_id: id, evidence_path: expectedEvidence,
      release_approved: false
    })
  }
})
