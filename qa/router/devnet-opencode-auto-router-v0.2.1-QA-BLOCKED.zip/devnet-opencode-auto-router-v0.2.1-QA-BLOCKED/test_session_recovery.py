"""Cross-process session recovery, malformed event and fail-closed tests."""
import io
import json
import os
from pathlib import Path
import stat
import subprocess
import sys
import tempfile
import time
import unittest
from unittest.mock import patch
import auto_route as r

SID = 'ses_devnetSAFE1234567'
OTHER = 'ses_otherSESSION98765'


def event(session=SID, message='ok'):
    return json.dumps({'type':'text','sessionID':session,'part':{'type':'text','text':message}}).encode()+b'\n'


class FakeEventProcess:
    def __init__(self, blob):
        self.stdout = io.BytesIO(blob)
        self.pid = os.getpid() + 100000
        self.waited = False
    def poll(self): return 0
    def wait(self, timeout=None): self.waited = True; return 0


class SessionRecoveryTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory(prefix='router-session-test-')
        self.addCleanup(self.tmp.cleanup)
        self.home = Path(self.tmp.name)
        patcher = patch.object(r, 'STATE_DIR',self.home/'state')
        patcher.start()
        self.addCleanup(patcher.stop)

    def state(self):
        return json.loads((r.STATE_DIR/'latest.json').read_text())

    def write_pause(self, session=SID):
        r.record_task_state('PAUSED_INTERRUPTED',r.CODER,'Previous task',exit_code=2,session_id=session)

    def test_json_event_captures_exact_id_in_checkpoint(self):
        fake = FakeEventProcess(event())
        with patch.object(r,'gaming_active',return_value=False),patch.object(r.subprocess,'Popen',return_value=fake) as launch:
            self.assertEqual(r.execute_task(r.CODER,'Review Python',track_session=True),0)
        self.assertEqual(self.state()['session_id'],SID)
        self.assertEqual(self.state()['status'],'COMPLETE')
        self.assertIn('--format',launch.call_args.args[0]);self.assertEqual(launch.call_args.kwargs['stdout'],subprocess.PIPE)
        self.assertTrue(launch.call_args.kwargs['start_new_session'])

    def test_previous_explicit_id_matches_stream(self):
        fake = FakeEventProcess(event())
        with patch.object(r,'gaming_active',return_value=False),patch.object(r.subprocess,'Popen',return_value=fake):
            self.assertEqual(r.execute_task(r.CODER,'Review Python',session_id=SID,track_session=True),0)
        self.assertEqual(self.state()['session_id'],SID)

    def test_mismatched_event_session_fails_closed(self):
        fake = FakeEventProcess(event(OTHER))
        with patch.object(r,'gaming_active',return_value=False),patch.object(r.subprocess,'Popen',return_value=fake):
            self.assertEqual(r.execute_task(r.CODER,'Review Python',session_id=SID,track_session=True),2)
        self.assertEqual(self.state()['status'],'FAILED')
        self.assertFalse(self.state()['release_approved'])

    def test_mid_stream_session_change_rejected(self):
        fake = FakeEventProcess(event(SID) + event(OTHER))
        with patch.object(r,'gaming_active',return_value=False),patch.object(r.subprocess,'Popen',return_value=fake):
            self.assertEqual(r.execute_task(r.CODER,'Review Python',track_session=True),2)
        self.assertEqual(self.state()['status'],'FAILED')

    def test_missing_session_blocks_success_claim(self):
        fake = FakeEventProcess(json.dumps({'type':'text','part':{'text':'ok'}}).encode()+b'\n')
        with patch.object(r,'gaming_active',return_value=False),patch.object(r.subprocess,'Popen',return_value=fake):
            self.assertEqual(r.execute_task(r.CODER,'Review Python',track_session=True),2)
        self.assertEqual(self.state()['status'],'FAILED')

    def test_malformed_json_blocks(self):
        fake = FakeEventProcess(b'{garbage}\n')
        with patch.object(r,'gaming_active',return_value=False),patch.object(r.subprocess,'Popen',return_value=fake):
            self.assertEqual(r.execute_task(r.CODER,'Review Python',track_session=True),2)
        self.assertEqual(self.state()['status'],'FAILED')

    def test_no_final_newline_blocks(self):
        fake = FakeEventProcess(event()[:-1])
        with patch.object(r,'gaming_active',return_value=False),patch.object(r.subprocess,'Popen',return_value=fake):
            self.assertEqual(r.execute_task(r.CODER,'Review Python',track_session=True),2)

    def test_oversize_stream_blocks(self):
        fake = FakeEventProcess(b'a'*262145)
        with patch.object(r,'gaming_active',return_value=False),patch.object(r.subprocess,'Popen',return_value=fake):
            self.assertEqual(r.execute_task(r.CODER,'Review Python',track_session=True),2)

    def test_invalid_session_id_blocks(self):
        fake = FakeEventProcess(event('--hax'))
        with patch.object(r,'gaming_active',return_value=False),patch.object(r.subprocess,'Popen',return_value=fake):
            self.assertEqual(r.execute_task(r.CODER,'Review Python',track_session=True),2)

    def test_text_event_prints_only_text_not_full_json(self):
        fake = FakeEventProcess(event())
        out = io.StringIO()
        with patch.object(r,'gaming_active',return_value=False),patch.object(r.subprocess,'Popen',return_value=fake),patch('sys.stdout',out):
            self.assertEqual(r.execute_task(r.CODER,'Review Python',track_session=True),0)
        self.assertEqual(out.getvalue(),'ok\n')

    def test_resume_checkpoint_validates_exact_id(self):
        self.write_pause()
        self.assertEqual(r.read_interrupted_session(),SID)
        self.assertEqual(self.state()['status'],'PAUSED_INTERRUPTED')

    def test_resume_no_checkpoint_blocked(self):
        with self.assertRaises(OSError): r.read_interrupted_session()

    def test_resume_complete_checkpoint_blocked(self):
        r.record_task_state('COMPLETE',r.CODER,'Done',exit_code=0,session_id=SID)
        with self.assertRaises(RuntimeError): r.read_interrupted_session()

    def test_resume_does_not_guess_when_id_missing(self):
        self.write_pause(session=None)
        with self.assertRaises(RuntimeError): r.read_interrupted_session()

    def test_resume_rejects_forged_release_approval(self):
        self.write_pause()
        p=r.STATE_DIR/'latest.json'; data=self.state();data['release_approved']=True;p.write_text(json.dumps(data))
        with self.assertRaises(RuntimeError): r.read_interrupted_session()

    def test_resume_rejects_bad_schema_and_extra_keys(self):
        for extra in (['surprise'],[]):
            with self.subTest(extra=extra):
                self.write_pause(); p=r.STATE_DIR/'latest.json'; data=self.state()
                if extra:data['surprise']='unsafe'
                else:data['schema']='broken'
                p.write_text(json.dumps(data))
                with self.assertRaises(RuntimeError): r.read_interrupted_session()

    def test_resume_rejects_public_checkpoint_file(self):
        self.write_pause()
        p=r.STATE_DIR/'latest.json';p.chmod(0o644)
        with self.assertRaises(RuntimeError): r.read_interrupted_session()

    def test_resume_rejects_symlink_checkpoint_file(self):
        self.write_pause(); p=r.STATE_DIR/'latest.json';target=self.home/'target';target.write_bytes(p.read_bytes());p.unlink();p.symlink_to(target)
        with self.assertRaises(OSError): r.read_interrupted_session()
        self.assertTrue(target.is_file())

    def test_resume_rejects_public_or_symlink_state_dir(self):
        self.write_pause(); r.STATE_DIR.chmod(0o755)
        with self.assertRaises(RuntimeError):r.read_interrupted_session()
        r.STATE_DIR.chmod(0o700); alias=self.home/'link';alias.symlink_to(r.STATE_DIR,target_is_directory=True)
        with patch.object(r,'STATE_DIR',alias),self.assertRaises(RuntimeError):r.read_interrupted_session()

    def test_resume_rejects_oversize_checkpoint(self):
        self.write_pause();p=r.STATE_DIR/'latest.json';p.write_text('x'*4097)
        with self.assertRaises(RuntimeError):r.read_interrupted_session()

    def test_explicit_resume_requires_new_prompt(self):
        with self.assertRaises(SystemExit):r.main(['--resume-interrupted'])

    def test_resume_does_not_retry_when_gaming(self):
        self.write_pause()
        with patch.object(r,'gaming_active',return_value=True),patch.object(r,'loaded_models') as loaded,patch.object(r,'execute_task') as execute:
            self.assertEqual(r.main(['--resume-interrupted','Summarise progress']),2)
        loaded.assert_not_called();execute.assert_not_called()

    def test_explicit_resume_passes_exact_id_to_executor(self):
        self.write_pause()
        with patch.object(r,'gaming_active',return_value=False),patch.object(r,'loaded_models',return_value=[]),patch.object(r,'execute_task',return_value=0) as execute:
            self.assertEqual(r.main(['--resume-interrupted','Summarise progress']),0)
        execute.assert_called_once_with(r.DEFAULT,'Summarise progress',session_id=SID,track_session=True)

    def test_corrupt_resume_refuses_to_launch(self):
        self.write_pause(session=None)
        with patch.object(r,'gaming_active',return_value=False),patch.object(r,'loaded_models',return_value=[]),patch.object(r,'execute_task') as execute:
            self.assertEqual(r.main(['--resume-interrupted','Summarise progress']),2)
        execute.assert_not_called()

    def test_old_command_builder_unchanged_without_track(self):
        self.assertEqual(r.command_for_task(r.CODER,'Debug Python'),['/usr/bin/opencode','run','--model',r.CODER,'Debug Python'])

    def test_real_process_event_and_interrupt_resume_exact_id(self):
        script = ("import sys,json,time;"
                  "print(json.dumps({'type':'step_start','sessionID':sys.argv[1]}),flush=True);"
                  "time.sleep(float(sys.argv[-1]));"
                  "print(json.dumps({'type':'text','sessionID':sys.argv[1],"
                  "'part':{'type':'text','text':'recovered'}}),flush=True)")
        calls=[]
        def stub(model,task,*,session_id=None,continue_session=False):
            calls.append((model,task,session_id))
            return [sys.executable,'-u','-c',script,session_id or SID,'30' if task=='initial' else '0']
        count=[0]
        def game_transition():
            count[0]+=1
            return count[0]>=3
        with patch.object(r,'command_for_task',side_effect=stub),patch.object(r,'gaming_active',side_effect=game_transition):
            rc=r.execute_task(r.CODER,'initial',track_session=True)
        self.assertEqual(rc,2)
        self.assertEqual(self.state()['status'],'PAUSED_INTERRUPTED')
        self.assertEqual(self.state()['session_id'],SID)
        with patch.object(r,'command_for_task',side_effect=stub),patch.object(r,'gaming_active',return_value=False),patch.object(r,'loaded_models',return_value=[]):
            self.assertEqual(r.main(['--resume-interrupted','Summarise recovery']),0)
        self.assertEqual(calls[-1],(r.DEFAULT,'Summarise recovery',SID))
        self.assertEqual(self.state()['status'],'COMPLETE')
        self.assertEqual(self.state()['session_id'],SID)
        self.assertFalse(self.state()['release_approved'])

if __name__=='__main__':unittest.main()
