"""Host-specific regressions: user auto-handover setting must not leak into QA."""
import contextlib
import hashlib
import io
import json
import os
from pathlib import Path
import stat
import tempfile
import unittest
from unittest import mock

import qa_dispatch as q
import qa_review_worker as w


class HostIsolationTests(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory()
        self.addCleanup(self.tmp.cleanup)
        self.base=Path(self.tmp.name)
        self.qa=self.base/'qa'
        self.qa.mkdir(mode=0o700)
        self.bundle=Path(__file__).resolve().parent

    def test_real_88_regressions_pass_even_when_user_opted_in(self):
        host=self.base/'user-home'
        settings=host/'.config/devnet-model-router'
        settings.mkdir(parents=True,mode=0o700)
        conf=settings/'settings.json'
        conf.write_text(json.dumps({'schema':'devnet-router-settings-v1',
                                    'native_auto_handover':True,
                                    'owner_user_id':os.getuid()}))
        conf.chmod(0o600)
        digest=hashlib.sha256(conf.read_bytes()).hexdigest()
        with mock.patch.dict(os.environ, {'HOME':str(host)}):
            with contextlib.redirect_stdout(io.StringIO()):
                rc=q.run_pipeline(q.JOBS[0],evidence_root=self.qa,
                       candidate=self.bundle/'baseline_v017.zip',game_check=lambda:False)
        self.assertEqual(rc,0)
        record=json.loads(next(self.qa.glob('router-qa-*/result.json')).read_text())
        self.assertEqual(record['results'][q.JOBS[0]]['executed_tests'],88)
        self.assertEqual(record['results'][q.JOBS[0]]['status'],'PASS')
        self.assertEqual(hashlib.sha256(conf.read_bytes()).hexdigest(),digest)
        self.assertFalse(record['release_approved'])

    def test_subprocess_home_isolated_but_real_gaming_policy_kept(self):
        original=os.environ.get('HOME')
        observed={}
        def fake_execute(argv,cwd,log,**kwargs):
            env=kwargs['environ']
            observed.update(env)
            self.assertEqual(env['HOME'],str(log.parent/'regressions-home'))
            self.assertNotEqual(env['HOME'],original)
            self.assertNotIn('PYTHONPATH',env)
            self.assertNotIn('PYTHONHOME',env)
            self.assertIs(kwargs['game_check'],check)
            Path(log).write_text('Ran 88 tests in 2.0s\n\nOK\n')
            return 0
        def check():return False
        with mock.patch.dict(os.environ,{'PYTHONPATH':'/unsafe','PYTHONHOME':'/unsafe'}):
            with mock.patch.object(q,'execute',side_effect=fake_execute):
                result=q.run_one(q.JOBS[0],self.qa,bundle=self.bundle,
                                 candidate=self.bundle/'baseline_v017.zip',
                                 game_check=check)
        self.assertEqual(result['status'],'PASS')
        self.assertEqual(stat.S_IMODE((self.qa/'regressions-home').stat().st_mode),0o700)

    def test_worker_http_diagnostic_is_fixed_code(self):
        from urllib.error import HTTPError
        source=self.base/'prompt';source.write_text('safe')
        with mock.patch.object(w.urllib.request,'urlopen',side_effect=HTTPError('http://127.0.0.1',400,'bad',{},None)):
            with self.assertRaisesRegex(w.ReviewFailure,'AI_REVIEW_HTTP_400'):
                w.main(['worker',str(source)])

    def test_worker_rejects_malformed_advice(self):
        prompt=self.base/'prompt';prompt.write_text('safe')
        class Reply:
            status=200
            def __enter__(self):return self
            def __exit__(self,*args):return None
            def read(self,n):return json.dumps({'done':True,'response':'{"summary":"ok","remaining_risks":{"unsafe":"nested"},"next_checks":"x"}'}).encode()
        with mock.patch.object(w.urllib.request,'urlopen',return_value=Reply()):
            with self.assertRaisesRegex(w.ReviewFailure,'AI_REVIEW_SCHEMA_INVALID'):
                w.main(['worker',str(prompt)])

    def test_worker_error_code_is_reported_without_leaking_text(self):
        def error(argv,cwd,log,**kwargs):
            Path(log).write_text('AI_REVIEW_HTTP_400\n')
            return 2
        with mock.patch.object(q,'execute',side_effect=error):
            result=q.ai_review({'results':{},'decision':'BLOCKED'},game_check=lambda:False)
        self.assertEqual(result,{'status':'BLOCKED','reason':'AI_REVIEW_HTTP_400'})

    def test_untrusted_diagnostics_are_not_echoed(self):
        def error(argv,cwd,log,**kwargs):
            Path(log).write_text('AI_REVIEW_HTTP_400\nunsafe extra context')
            return 2
        with mock.patch.object(q,'execute',side_effect=error):
            result=q.ai_review({'results':{},'decision':'BLOCKED'},game_check=lambda:False)
        self.assertEqual(result,{'status':'BLOCKED','reason':'LOCAL_AI_WORKER_FAILED'})


if __name__=='__main__': unittest.main()
