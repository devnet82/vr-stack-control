"""Regression for real isolated host SESSION_ID_MISMATCH: maintain strict checks."""
import contextlib
import io
import json
import os
from pathlib import Path
import subprocess
import tempfile
import unittest
from unittest import mock
import auto_route as router

SID='ses_privateHostValidated001'
OTHER='ses_foreignServerSession002'

def event(session, text='DEVNET_READY'):
    return (json.dumps({'type':'text','sessionID':session,'part':{'type':'text','text':text}})+'\n').encode()

class EventProcess:
    def __init__(self, payload):
        self.stdout=io.BytesIO(payload)
        self.pid=100001
    def poll(self): return 0
    def wait(self,timeout=None): return 0

class PrivateOpenCodeSessionTests(unittest.TestCase):
    def setUp(self):
        tmp=tempfile.TemporaryDirectory(prefix='router-v024-')
        self.addCleanup(tmp.cleanup)
        self.temp=Path(tmp.name)
        patch=mock.patch.object(router,'STATE_DIR',self.temp/'router-state')
        patch.start();self.addCleanup(patch.stop)

    def run_private(self, payload, *, fake=False):
        proc=EventProcess(payload)
        with mock.patch.object(router,'gaming_active',return_value=False), \
             mock.patch.object(router.subprocess,'Popen',return_value=proc) as launch, \
             contextlib.redirect_stdout(io.StringIO()):
            rc=router.execute_task(router.DEFAULT,'Reply exactly DEVNET_READY.',track_session=True,
                                   private_server=True,reject_fake_tool_text=fake,cwd=self.temp)
        return rc,launch

    def test_master_launch_uses_documented_standalone_cli(self):
        cmd=router.command_for_task(router.DEFAULT,'Say ready',private_server=True)
        self.assertEqual(cmd[:5],['/usr/bin/opencode','run','--standalone','--model',router.DEFAULT])
        self.assertEqual(cmd[-1],'Say ready')

    def test_standalone_mode_requires_fresh_session(self):
        with self.assertRaises(ValueError):
            router.command_for_task(router.DEFAULT,'Hi',session_id=SID,private_server=True)
        with self.assertRaises(ValueError):
            router.command_for_task(router.DEFAULT,'Hi',continue_session=True,private_server=True)

    def test_normal_router_command_is_byte_equivalent(self):
        cmd=router.command_for_task(router.DEFAULT,'Hi')
        self.assertEqual(cmd,['/usr/bin/opencode','run','--model',router.DEFAULT,'Hi'])

    def test_old_qa_after_does_not_use_private_server(self):
        cmd=router.command_for_task(router.CODER,'Check code')
        self.assertNotIn('--standalone',cmd)
        self.assertEqual(cmd[2],'--model')

    def test_private_db_is_set_in_child_only(self):
        with mock.patch.dict(os.environ,{'OPENCODE_DB':'real-user-database.sqlite'}):
            rc,launch=self.run_private(event(SID))
            self.assertEqual(rc,0)
            kwargs=launch.call_args.kwargs
            self.assertEqual(kwargs['env']['OPENCODE_DB'],':memory:')
            self.assertEqual(os.environ['OPENCODE_DB'],'real-user-database.sqlite')
            self.assertTrue(kwargs['start_new_session'])
            self.assertEqual(kwargs['cwd'],str(self.temp))
            self.assertEqual(kwargs['stdout'],subprocess.PIPE)
            self.assertEqual(launch.call_args.args[0][-3:-1],['--format','json'])

    def test_normal_open_code_leaves_database_environment_untouched(self):
        rc,launch=self.run_normal(event(SID))
        self.assertEqual(rc,0)
        self.assertNotIn('env',launch.call_args.kwargs)
        self.assertNotIn('--standalone',launch.call_args.args[0])

    def run_normal(self,payload):
        proc=EventProcess(payload)
        with mock.patch.object(router,'gaming_active',return_value=False), \
             mock.patch.object(router.subprocess,'Popen',return_value=proc) as launch, \
             contextlib.redirect_stdout(io.StringIO()):
            rc=router.execute_task(router.DEFAULT,'Say ready',track_session=True)
        return rc,launch

    def test_private_session_valid_single_id_passes(self):
        rc,launch=self.run_private(event(SID))
        self.assertEqual(rc,0)
        report=json.loads((router.STATE_DIR/'latest.json').read_text())
        self.assertEqual(report['session_id'],SID)
        self.assertEqual(report['status'],'COMPLETE')
        self.assertIs(report['release_approved'],False)
        self.assertIn('--standalone',launch.call_args.args[0])

    def test_private_session_multiple_ids_remain_blocked(self):
        rc,_=self.run_private(event(SID)+event(OTHER))
        self.assertEqual(rc,2)
        report=json.loads((router.STATE_DIR/'latest.json').read_text())
        self.assertEqual(report['status'],'FAILED')
        self.assertIs(report['release_approved'],False)

    def test_private_session_unstructured_call_still_blocked(self):
        rc,_=self.run_private(event(SID,'<function=devnet_qa>'),fake=True)
        self.assertEqual(rc,2)
        report=json.loads((router.STATE_DIR/'latest.json').read_text())
        self.assertEqual(report['status'],'FAILED')

    def test_private_session_missing_id_cannot_claim_pass(self):
        payload=(json.dumps({'type':'text','part':{'text':'DEVNET_READY'}})+'\n').encode()
        rc,_=self.run_private(payload)
        self.assertEqual(rc,2)

    def test_master_after_rejects_continue_session(self):
        with contextlib.redirect_stderr(io.StringIO()),self.assertRaises(SystemExit):
            router.main(['--master-qa-after','--master-qa-zip','/tmp/pinned.zip','--continue-session','Hi'])

    def test_master_after_rejects_resume_interrupted(self):
        with contextlib.redirect_stderr(io.StringIO()),self.assertRaises(SystemExit):
            router.main(['--master-qa-after','--master-qa-zip','/tmp/pinned.zip','--resume-interrupted','Hi'])

    def test_master_after_rejects_explicit_session(self):
        with contextlib.redirect_stderr(io.StringIO()),self.assertRaises(SystemExit):
            router.main(['--master-qa-after','--master-qa-zip','/tmp/pinned.zip','--session-id',SID,'Hi'])

    def test_no_approval_for_private_session(self):
        rc,_=self.run_private(event(SID))
        self.assertEqual(rc,0)
        result=json.loads((router.STATE_DIR/'latest.json').read_text())
        self.assertIs(result['release_approved'],False)
