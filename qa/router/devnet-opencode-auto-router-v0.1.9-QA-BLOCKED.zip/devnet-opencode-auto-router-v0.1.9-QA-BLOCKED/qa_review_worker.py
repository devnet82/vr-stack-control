#!/usr/bin/env python3
"""Private bounded Ollama advisory. Emit fixed diagnostics, never model text on error.

Parent monitors the worker process group for gaming/VR transitions.
"""
import json
import sys
import urllib.error
import urllib.request
from pathlib import Path


class ReviewFailure(Exception):
    pass


def main(argv):
    if len(argv) != 2:
        raise ReviewFailure('AI_REVIEW_ARGUMENTS')
    file = Path(argv[1])
    if file.is_symlink() or not file.is_file() or file.stat().st_size > 12000:
        raise ReviewFailure('AI_REVIEW_INPUT_UNSAFE')
    prompt = file.read_text()
    request = urllib.request.Request('http://127.0.0.1:11434/api/generate',
        data=json.dumps({'model':'qwen3-coder:30b','prompt':prompt,'stream':False,
                         'think':False,'format':'json',
                         'options':{'temperature':0,'num_predict':384}}).encode(),
        headers={'Content-Type':'application/json'},method='POST')
    try:
        with urllib.request.urlopen(request, timeout=85) as response:
            if response.status != 200:
                raise ReviewFailure('AI_REVIEW_HTTP_STATUS')
            raw = response.read(65537)
    except urllib.error.HTTPError as exc:
        # Never include the remote error body, which may contain model text.
        raise ReviewFailure('AI_REVIEW_HTTP_'+str(exc.code)) from None
    except (urllib.error.URLError, ConnectionError):
        raise ReviewFailure('AI_REVIEW_CONNECTION') from None
    except TimeoutError:
        raise ReviewFailure('AI_REVIEW_TIMEOUT') from None
    if len(raw) > 65536:
        raise ReviewFailure('AI_REVIEW_RESPONSE_OVERSIZE')
    try:
        result = json.loads(raw)
        if type(result) is not dict or result.get('done') is not True or type(result.get('response')) is not str:
            raise ReviewFailure('AI_REVIEW_INCOMPLETE')
        advice = json.loads(result['response'])
    except (json.JSONDecodeError, UnicodeDecodeError, TypeError):
        raise ReviewFailure('AI_REVIEW_JSON_INVALID') from None
    if (type(advice) is not dict or any(type(advice.get(k)) is not str
         for k in ('summary','remaining_risks','next_checks'))):
        raise ReviewFailure('AI_REVIEW_SCHEMA_INVALID')
    print(json.dumps({k: advice[k][:800] for k in
                      ('summary','remaining_risks','next_checks')},sort_keys=True),flush=True)
    return 0


if __name__ == '__main__':
    try:
        sys.exit(main(sys.argv))
    except ReviewFailure as exc:
        print(str(exc),file=sys.stderr,flush=True)
        sys.exit(2)
    except (OSError,RuntimeError,ValueError,UnicodeDecodeError):
        print('AI_REVIEW_RUNTIME_FAILURE',file=sys.stderr,flush=True)
        sys.exit(2)
