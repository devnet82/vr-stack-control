#!/usr/bin/env python3
"""Local, policy-bound QA controller v0.4.3.

Only categorical test results go to localhost Qwen (optional); no filesystem
paths, commands, prompts from other projects, SSH output, or secrets. The LLM
cannot acquire additional permissions or define test operations. Full release
approval is explicitly outside this controller's authority.
"""
from __future__ import annotations
import datetime as dt
import fcntl
import http.client
import json
import os
from pathlib import Path
import re
import subprocess
import sys
import tempfile

VERSION = '0.4.4'
TARGET = 'devnet@192.168.122.71'
KEY = Path.home()/'.ssh/devnet-app-qa-ed25519'
STATE = Path.home()/'.local/state/devnet-qa-controller'
STOP = Path.home()/'.config/devnet-qa-automation/stop-all'
PAUSE = Path.home()/'.config/devnet-qa-automation/gaming-on'
CHECKS = ('package_integrity','source_integrity','script_syntax','tray_lock',
          'package_python_tests','package_shell_tests','gui_process_smoke',
          'tray_process_smoke','gui_tab_navigation','gui_clean_close','tray_menu_wiring','gui_sidebar_activation','gui_pointer_navigation')
PREREQS = ('sandbox','display','original_package','original_tray','pinned_baseline','pointer_xvfb','pointer_xtest','pointer_gtk3')
STATUS = {'PASS','FAIL','NOT_TESTED','BLOCKED'}
HEALTH = {'READY','MISSING','MISMATCH'}
# No runtime paths, URLs, or commands are accepted from an AI model.
SSH = ('/usr/bin/ssh', '-F','/dev/null','-i',str(KEY),'-o','IdentitiesOnly=yes',
       '-o','BatchMode=yes','-o','ForwardAgent=no',
       '-o','ClearAllForwardings=yes','-o','StrictHostKeyChecking=yes',
       '-o','ConnectTimeout=5','-o','ServerAliveInterval=5',
       '-o','ServerAliveCountMax=2','-T',TARGET)

# DEVNET_DETERMINISTIC_EVIDENCE_V1
import importlib.util as _devnet_importlib
# Use the validator packaged alongside this exact candidate when testing in isolation.
# Keep the established installed path for the original host layout.
_devnet_bundled_validator = Path(__file__).resolve().parent.parent / 'devnet-qa-verified.py'
_devnet_installed_validator = Path('/mnt/devnet-ai/memory/bin/devnet-qa-verified.py')
_devnet_validator_path = (_devnet_bundled_validator if _devnet_bundled_validator.is_file()
                          else _devnet_installed_validator)
_devnet_spec = _devnet_importlib.spec_from_file_location('devnet_qa_verified_validator', _devnet_validator_path)
if _devnet_spec is None or _devnet_spec.loader is None:
    raise RuntimeError('verified QA validator unavailable')
_devnet_module = _devnet_importlib.module_from_spec(_devnet_spec)
_devnet_spec.loader.exec_module(_devnet_module)
_devnet_validate = _devnet_module.validate

# DEVNET_DETERMINISTIC_EVIDENCE_V1
def verified_vm_run_response(raw):
    """Validate the SAME VM response; no additional SSH execution."""
    if not isinstance(raw, dict):
        raise RuntimeError('VM evidence is not a dictionary')
    try:
        evidence = _devnet_validate(json.dumps(raw, sort_keys=True))
    except (ValueError, TypeError, json.JSONDecodeError) as exc:
        raise RuntimeError('deterministic VM evidence validation failed') from exc
    if (evidence.get('evidence') != 'VERIFIED'
            or evidence.get('release_approved') is not False
            or evidence.get('master_qa') != 'NOT_VERIFIED'
            or evidence.get('decision') != 'BLOCKED'
            or evidence.get('source_schema') != 'devnet-app-qa-v1'
            or evidence.get('release') != 'vr-stack-v0.6.132'
            or evidence.get('checks') != raw['checks']
            or evidence.get('total') != len(CHECKS)
            or set(evidence['checks']) != set(CHECKS)
            or sum(evidence['counts'].values()) != len(CHECKS)):
        raise RuntimeError('deterministic VM evidence consistency failure')
    return evidence



def game_active() -> bool:
    # Reuse the known-good, real-process game detection from the existing guard.
    try:
        import agent
        return bool(agent.gaming_now())
    except Exception:
        return True  # fail closed


def assert_key() -> None:
    st=KEY.lstat()
    if KEY.is_symlink() or not KEY.is_file() or (st.st_mode & 0o077):
        raise RuntimeError('unsafe restricted SSH key')


def remote(action: str) -> dict:
    if action not in ('run','probe','repair-xvfb'):
        raise ValueError('action not allowlisted')
    assert_key()
    proc=subprocess.run([*SSH,action],stdin=subprocess.DEVNULL,
                        capture_output=True,text=True,timeout=225 if action=='run' else (115 if action=='repair-xvfb' else 12))
    # Strictly one small JSON line; no raw remote data is persisted or printed.
    if proc.returncode or len(proc.stdout)>4096 or proc.stderr.strip():
        raise RuntimeError('remote response rejected')
    lines=proc.stdout.splitlines()
    if len(lines)!=1:
        raise RuntimeError('not an exact JSON response')
    d=json.loads(lines[0])
    if not isinstance(d,dict):
        raise RuntimeError('response type invalid')
    if action=='run':
        if (set(d)!={'schema','release','decision','checks'}
                or d['schema']!='devnet-app-qa-v1'
                or d['release']!='vr-stack-v0.6.132'
                or d['decision']!='BLOCKED' or not isinstance(d['checks'],dict)
                or set(d['checks'])!=set(CHECKS)
                or any(v not in STATUS for v in d['checks'].values())):
            raise RuntimeError('untrusted test result')
    elif action=='repair-xvfb':
        if (set(d)!={'schema','release','dependency','status'}
                or d['schema']!='devnet-app-repair-v1'
                or d['release']!='vr-stack-v0.6.132'
                or d['dependency']!='pointer_xvfb'
                or d['status'] not in {'INSTALLED','ALREADY_READY','PREVIOUS_ATTEMPT','FAILED','BLOCKED'}):
            raise RuntimeError('untrusted repair result')
    else:
        if (set(d)!={'schema','release','prerequisites'}
                or d['schema']!='devnet-app-probe-v1'
                or d['release']!='vr-stack-v0.6.132'
                or not isinstance(d['prerequisites'],dict)
                or set(d['prerequisites'])!=set(PREREQS)
                or any(v not in HEALTH for v in d['prerequisites'].values())):
            raise RuntimeError('untrusted VM probe')
    if action == 'run':
        verified_vm_run_response(d)
    return d


def model_suggestion(checks: dict, health: dict) -> str:
    """Local-only Qwen advice; never gives model any permission to execute.

    Only fixed enums enter the prompt. HTTPConnection to a numeric loopback IP
    avoids DNS, proxy settings, GitHub, remote endpoints and accidental uploads.
    If local inference is unavailable/invalid, fail closed (no AI retry).
    """
    snapshot={k:checks[k] for k in CHECKS}
    prerequisites={k:health[k] for k in PREREQS}
    prompt=('You are a local QA triage helper. Select only a safe action. '
            'JSON object ONLY: {"action":"retry_once"} or {"action":"stop"}. '
            'Never decide PASS, approve a release, or issue a command. '
            'If in doubt select stop. No private data is included. '\
            + json.dumps({'statuses':snapshot,'vm_health':prerequisites},
                         sort_keys=True,separators=(',',':')))
    body=json.dumps({'model':'qwen3.5:9b','prompt':prompt,'stream':False,
                     'format':'json','options':{'num_predict':32,'temperature':0}}).encode()
    conn=http.client.HTTPConnection('127.0.0.1',11434,timeout=10)
    try:
        conn.request('POST','/api/generate',body=body,
                     headers={'Content-Type':'application/json'})
        response=conn.getresponse()
        if response.status != 200:
            return 'stop'
        raw=response.read(2049)
        if len(raw)>2048:
            return 'stop'
        d=json.loads(raw.decode())
        if not isinstance(d,dict) or not isinstance(d.get('response'),str):
            return 'stop'
        proposed=json.loads(d['response'])
        if (isinstance(proposed,dict) and set(proposed)=={'action'}
                and proposed['action'] in ('retry_once','stop')):
            return proposed['action']
    except (OSError,TimeoutError,ValueError,json.JSONDecodeError,UnicodeError):
        return 'stop'
    finally:
        conn.close()
    return 'stop'


def classify(checks: dict) -> str:
    values=set(checks.values())
    if 'FAIL' in values or 'BLOCKED' in values:
        return 'BLOCKED'
    if 'NOT_TESTED' in values:
        return 'PARTIAL'
    return 'PASS_LIMITED'


def eligible_retry(checks: dict, health: dict) -> bool:
    """Only incomplete/transient smoke tests; a FAIL never becomes a PASS."""
    if any(v in ('FAIL','BLOCKED') for v in checks.values()):
        return False
    if any(health[k]!='READY' for k in PREREQS):
        return False
    incomplete=[k for k in CHECKS if checks[k]=='NOT_TESTED']
    return bool(incomplete) and all(k in ('gui_process_smoke','tray_process_smoke','gui_tab_navigation','gui_clean_close','tray_menu_wiring') for k in incomplete)


def sanitized_write(report: dict) -> None:
    STATE.mkdir(parents=True,mode=0o700,exist_ok=True)
    os.chmod(STATE,0o700)
    allowed={'schema','utc','qa','release_approved','attempts','triage',
             'checks','prerequisites','release_gate','dependency_repair'}
    data={k:v for k,v in report.items() if k in allowed}
    raw=(json.dumps(data,sort_keys=True,indent=2)+'\n').encode()
    fd,tmp=tempfile.mkstemp(prefix='qa-',dir=STATE)
    try:
        os.fchmod(fd,0o600)
        with os.fdopen(fd,'wb') as f:
            f.write(raw);f.flush();os.fsync(f.fileno())
        os.replace(tmp,STATE/'latest.json')
    finally:
        if os.path.exists(tmp):os.unlink(tmp)


def run_once() -> str:
    result={'schema':'devnet-controller-v1','utc':dt.datetime.now(dt.timezone.utc).isoformat(),
            'qa':'BLOCKED_UNAVAILABLE','release_approved':False,
            'release_gate':'MASTER_QA_BLOCKED', 'attempts':0,
            'triage':'NOT_RUN','dependency_repair':'NOT_REQUIRED','checks':dict.fromkeys(CHECKS,'NOT_TESTED'),
            'prerequisites':dict.fromkeys(PREREQS,'MISSING')}
    try:
        if game_active() or STOP.exists() or PAUSE.exists():
            result['qa']='PAUSED_GAME'; result['triage']='PAUSED'
            return result['qa']
        # Preflight is read-only and signed-package/integrity prerequisites must
        # be READY before even attempting the single allowlisted repair.
        pre=remote('probe')['prerequisites']
        result['prerequisites']=pre
        if any(pre[k]=='MISMATCH' for k in PREREQS):
            result['qa']='BLOCKED';result['triage']='INTEGRITY_BLOCKED'
            return result['qa']
        if pre['pointer_xvfb']=='MISSING':
            other=('sandbox','display','original_package','original_tray','pinned_baseline','pointer_xtest','pointer_gtk3')
            if all(pre[k]=='READY' for k in other):
                if game_active() or STOP.exists() or PAUSE.exists():
                    result['qa']='PAUSED_GAME';result['triage']='PAUSED'
                    return result['qa']
                repair=remote('repair-xvfb')
                result['dependency_repair']=repair['status']
                if repair['status'] in ('INSTALLED','ALREADY_READY'):
                    post=remote('probe')['prerequisites']
                    result['prerequisites']=post
                    if post['pointer_xvfb']!='READY' or any(post[k]!='READY' for k in other):
                        result['qa']='BLOCKED';result['triage']='REPAIR_VERIFICATION_FAILED'
                        return result['qa']
            else:
                result['dependency_repair']='NOT_AUTHORISED'
        if game_active():
            result['qa']='PAUSED_GAME';result['triage']='PAUSED'
            return result['qa']
        checks=remote('run')['checks']
        result['attempts']=1
        result['checks']=checks
        result['qa']=classify(checks)
        if result['qa']=='PASS_LIMITED':
            result['triage']='COMPLETE_WITHIN_SCOPE'
            return result['qa']
        if game_active():
            result['qa']='PAUSED_GAME';result['triage']='PAUSED'
            return result['qa']
        health=remote('probe')['prerequisites']
        result['prerequisites']=health
        if result['dependency_repair'] in ('FAILED','BLOCKED','PREVIOUS_ATTEMPT'):
            result['triage']='DEPENDENCY_REPAIR_BLOCKED'
        elif any(v=='MISMATCH' for v in health.values()):
            result['triage']='INTEGRITY_BLOCKED'
        elif any(v=='MISSING' for v in health.values()):
            result['triage']='PREREQUISITE_MISSING'
        elif not eligible_retry(checks,health):
            result['triage']='NOT_SAFE_TO_RETRY'
        elif game_active():
            result['qa']='PAUSED_GAME';result['triage']='PAUSED'
        elif model_suggestion(checks,health)=='retry_once' and not game_active():
            updated=remote('run')['checks']
            result['attempts']=2
            # Preserve any first-run FAIL; never overwrite negatives.
            result['checks']={k:(checks[k] if checks[k] in ('FAIL','BLOCKED')
                                 else updated[k]) for k in CHECKS}
            result['qa']=classify(result['checks'])
            result['triage']='ONE_POLICY_APPROVED_RETRY'
        else:
            result['triage']='MODEL_STOP_OR_UNAVAILABLE'
        return result['qa']
    except (OSError,subprocess.SubprocessError,RuntimeError,ValueError,KeyError,
            json.JSONDecodeError,TimeoutError):
        result['qa']='BLOCKED_UNAVAILABLE';result['triage']='ERROR_BLOCKED'
        return result['qa']
    finally:
        sanitized_write(result)


# DEVNET_MASTER_JOB_GATE_V0_2_4 — one controller, no additional daemon.
# This audit only checks coverage and trust. The controller cannot invent tests,
# sign its own evidence, or approve a release.
import hashlib as _master_hashlib
import hmac as _master_hmac

MASTER_GATE_SCHEMA = "devnet-master-job-gate-v2"
MASTER_RESULTS = frozenset(("PASS", "FAIL", "BLOCKED", "NOT_TESTED"))
MASTER_TRUSTED_RECEIPT_DIR = Path("/var/lib/devnet-master-qa/receipts")
MASTER_TRUSTED_KEY = Path("/etc/devnet-master-qa/executor-hmac.key")


def _master_digest(data):
    return _master_hashlib.sha256(data).hexdigest()


def master_job_decision(job: dict, receipt: dict, trusted_key: bytes | None):
    """Reject incomplete, stale, unsigned, self-attested or fabricated receipts.

    Security depends on the signer being a separately privileged executor; if
    the AI or this controller can access its key, a signature is NOT trustworthy.
    """
    blocked = {"schema": MASTER_GATE_SCHEMA, "decision": "BLOCKED",
               "release_approved": False, "user_acceptance_ready": False,
               "checks": {}, "reason": "INVALID_OR_INCOMPLETE_EVIDENCE"}
    try:
        if not isinstance(job, dict) or not isinstance(receipt, dict):
            return blocked
        if set(job) != {"schema", "job_id", "revision_sha256", "requirements", "stages"} or job["schema"] != "devnet-master-job-v1":
            return blocked
        job_id, revision, requirements = job["job_id"], job["revision_sha256"], job["requirements"]
        if not isinstance(job_id, str) or not job_id or not isinstance(revision, str) or len(revision)!=64 or any(c not in '0123456789abcdef' for c in revision):
            return blocked
        if not isinstance(requirements, list) or not requirements or any(not isinstance(x,str) or not x for x in requirements) or len(set(requirements))!=len(requirements):
            return blocked
        # An exhaustive job-specific checklist must declare its test environment.
        # GitHub CI is mandatory FIRST; VM and host are later stages, with
        # no silently omitted tests. Stage applicability is set at registration.
        stages = job["stages"]
        order = ("github", "vm", "host")
        if not isinstance(stages,dict) or set(stages)!=set(order):
            return blocked
        if any(not isinstance(stages[k],list) or any(not isinstance(v,str) or not v for v in stages[k]) for k in order):
            return blocked
        if not stages["github"] or len(set(sum((stages[k] for k in order), []))) != len(requirements):
            return blocked
        if set(sum((stages[k] for k in order), [])) != set(requirements):
            return blocked
        required = {"schema", "job_id", "revision_sha256", "requirements_sha256", "executor", "checks", "signature"}
        if set(receipt)!=required or receipt.get("schema")!="devnet-trusted-executor-receipt-v1":
            return blocked
        if receipt["job_id"]!=job_id or receipt["revision_sha256"]!=revision or receipt["executor"]!="devnet-trusted-executor-v1":
            return blocked
        canonical_requirements = json.dumps({"requirements":requirements,"stages":stages},sort_keys=True,separators=(',',':')).encode()
        if receipt["requirements_sha256"] != _master_digest(canonical_requirements):
            return blocked
        checks = receipt["checks"]
        if not isinstance(checks,dict) or set(checks)!=set(requirements):
            return blocked
        for name, evidence in checks.items():
            if (not isinstance(evidence,dict) or set(evidence)!={"status","execution_id","test_revision_sha256","log_sha256","exit_code","stage","sequence"}
                or evidence.get("status") not in MASTER_RESULTS
                or evidence.get("test_revision_sha256")!=revision
                or not isinstance(evidence.get("execution_id"),str) or not evidence["execution_id"]
                or not isinstance(evidence.get("log_sha256"),str) or len(evidence["log_sha256"])!=64
                or any(c not in '0123456789abcdef' for c in evidence["log_sha256"])
                or type(evidence.get("exit_code")) is not int
                or evidence.get("stage") not in order
                or name not in stages[evidence["stage"]]
                or type(evidence.get("sequence")) is not int or evidence["sequence"] < 1):
                return blocked
            if evidence["status"]=="PASS" and evidence["exit_code"]!=0:
                return blocked
        # Stage chronology: all GitHub tests must finish successfully BEFORE
        # any private VM execution; all VM tests before host-specific work.
        # Even a correctly signed receipt is rejected if stages overlap or
        # GitHub never ran. Every check belongs to this exact revision.
        sequences=[checks[n]["sequence"] for n in requirements]
        if len(set(sequences)) != len(sequences):
            return blocked
        for earlier,later in (("github","vm"),("vm","host"),("github","host")):
            if stages[earlier] and stages[later]:
                if max(checks[n]["sequence"] for n in stages[earlier]) >= min(checks[n]["sequence"] for n in stages[later]):
                    return blocked
                if any(checks[n]["status"] != "PASS" for n in stages[earlier]):
                    return blocked
        if not isinstance(trusted_key,bytes) or len(trusted_key)<32 or not isinstance(receipt["signature"],str):
            return blocked
        signed = {k:v for k,v in receipt.items() if k!="signature"}
        payload=json.dumps(signed,sort_keys=True,separators=(',',':'),ensure_ascii=True).encode()
        signature = _master_hmac.new(trusted_key,payload,_master_hashlib.sha256).hexdigest()
        if not _master_hmac.compare_digest(signature,receipt["signature"]):
            return blocked
        results={name:checks[name]["status"] for name in requirements}
        complete=all(x=="PASS" for x in results.values())
        return {"schema":MASTER_GATE_SCHEMA, "decision":"AI_TESTS_VERIFIED" if complete else "BLOCKED",
                "release_approved":False, "user_acceptance_ready":complete,
                "checks":results, "reason":"USER_ACCEPTANCE_PENDING" if complete else "INCOMPLETE_CHECKS"}
    except (KeyError,TypeError,ValueError,UnicodeEncodeError):
        return blocked


def master_job_gate_from_registered_files():
    """Read only fixed registration & separately secured executor receipts."""
    base=Path.home()/'.config/devnet-qa-automation'
    # Never accept an untrusted path or payload from the model as command args.
    try:
        jobfile=base/'master-job.json'
        if jobfile.is_symlink() or not jobfile.is_file():
            raise RuntimeError('job registration missing')
        job=json.loads(jobfile.read_text())
        job_id=job.get('job_id')
        if not isinstance(job_id,str) or not re.fullmatch(r'[a-zA-Z0-9_.-]{1,80}',job_id):
            raise RuntimeError('invalid registered job ID')
        rp=MASTER_TRUSTED_RECEIPT_DIR/(job_id+'.json')
        if rp.is_symlink() or not rp.is_file():
            raise RuntimeError('trusted executor receipt unavailable')
        # The trusted key must be provisioned outside the AI's account.
        if MASTER_TRUSTED_KEY.is_symlink() or not MASTER_TRUSTED_KEY.is_file():
            raise RuntimeError('separate trusted executor key unavailable')
        receipt=json.loads(rp.read_text())
        return master_job_decision(job,receipt,MASTER_TRUSTED_KEY.read_bytes())
    except (OSError,ValueError,TypeError,RuntimeError,PermissionError):
        return {"schema":MASTER_GATE_SCHEMA,"decision":"BLOCKED","release_approved":False,
                "user_acceptance_ready":False,"checks":{},"reason":"TRUSTED_EXECUTOR_NOT_CONFIGURED_OR_UNAVAILABLE"}



# DEVNET_MASTER_PERSISTENT_JOB_ENGINE_V0_2_7
# This is part of the single controller, not an independent QA product.
# The AI may propose corrections but cannot mark tests PASS or run arbitrary
# commands. Real stage evidence must come from a separately protected executor.
MASTER_QUEUE_SCHEMA = 'devnet-master-queue-v1'
MASTER_STATE_SCHEMA = 'devnet-master-progress-v1'
MASTER_STAGES = ('github', 'vm', 'host')


def _master_atomic_json(path, data):
    """Atomic restrictive checkpoint; caller must hold the per-job lock."""
    path = Path(path)
    path.parent.mkdir(mode=0o700, parents=True, exist_ok=True)
    fd, temp = tempfile.mkstemp(prefix='.pending-', dir=path.parent)
    try:
        with os.fdopen(fd, 'w') as stream:
            os.fchmod(stream.fileno(), 0o600)
            json.dump(data, stream, sort_keys=True, separators=(',', ':'))
            stream.flush()
            os.fsync(stream.fileno())
        os.replace(temp, path)
        dirfd = os.open(path.parent, os.O_DIRECTORY)
        try: os.fsync(dirfd)
        finally: os.close(dirfd)
    finally:
        if os.path.exists(temp): os.unlink(temp)


def master_next_step(job, progress, statuses=None, game=False):
    """Pure fail-closed scheduler: no AI-generated PASS claims are accepted.

    statuses must be supplied by a separately verified evidence gate. Pending
    stages are not executable until previous applicable stages are verified.
    """
    blocked = {'decision': 'BLOCKED', 'reason': 'INVALID_JOB_OR_PROGRESS', 'next_stage': None}
    try:
        if not isinstance(job, dict) or set(job) != {'schema','job_id','revision_sha256','requirements','stages'}:
            return blocked
        if job['schema'] != 'devnet-master-job-v1' or not re.fullmatch(r'[A-Za-z0-9_.-]{1,80}',job['job_id']):
            return blocked
        revision = job['revision_sha256']
        if not isinstance(revision,str) or not re.fullmatch(r'[0-9a-f]{64}',revision): return blocked
        stages=job['stages']; req=job['requirements']
        if not isinstance(stages,dict) or set(stages)!=set(MASTER_STAGES): return blocked
        if not isinstance(req,list) or len(req)!=len(set(req)) or not req or any(not isinstance(x,str) or not x for x in req):return blocked
        if any(not isinstance(stages[x],list) for x in MASTER_STAGES): return blocked
        if not stages['github'] or sum((stages[k] for k in MASTER_STAGES),[]) != req: return blocked
        if not isinstance(progress,dict) or progress.get('schema')!=MASTER_STATE_SCHEMA or progress.get('job_id')!=job['job_id']:
            return blocked
        if progress.get('revision_sha256') != revision:
            return {'decision':'BLOCKED','reason':'REVISION_CHANGED_REQUIRE_FULL_RETEST','next_stage':None}
        if progress.get('status') == 'OPERATOR_HOLD':
            return {'decision':'BLOCKED','reason':'OPERATOR_OR_SAFETY_PAUSE','next_stage':None}
        if game:
            return {'decision':'PAUSED','reason':'GAMING_PROTECTION','next_stage':None}
        if statuses is None:
            return {'decision':'BLOCKED','reason':'TRUSTED_EVIDENCE_REQUIRED','next_stage':None}
        if not isinstance(statuses,dict) or set(statuses)!=set(req) or any(x not in MASTER_RESULTS for x in statuses.values()):return blocked
        for stage in MASTER_STAGES:
            names=stages[stage]
            if not names: continue
            values=[statuses[n] for n in names]
            if all(x=='PASS' for x in values): continue
            if any(x in ('FAIL','BLOCKED') for x in values):
                return {'decision':'BLOCKED','reason':'FAILED_OR_BLOCKED_TEST_REQUIRES_SAFE_REPAIR','next_stage':stage}
            # An actual executor must run this stage, then independently verify it.
            return {'decision':'PENDING_EXECUTOR','reason':'ALL_APPLICABLE_STAGE_TESTS_REQUIRED','next_stage':stage}
        return {'decision':'AI_TESTS_VERIFIED','reason':'USER_ACCEPTANCE_PENDING','next_stage':None}
    except (TypeError,ValueError,KeyError):
        return blocked


def master_cycle(job_file, state_file, verified_statuses=None, gaming=False):
    """Persist one safe decision with no arbitrary program execution."""
    path=Path(state_file)
    path.parent.mkdir(mode=0o700, parents=True, exist_ok=True)
    with (path.parent/'master-progress.lock').open('a+b') as lock:
        fcntl.flock(lock, fcntl.LOCK_EX)
        job=json.loads(Path(job_file).read_text())
        if path.exists():
            progress=json.loads(path.read_text())
        else:
            progress={'schema':MASTER_STATE_SCHEMA,'job_id':job['job_id'],
                      'revision_sha256':job['revision_sha256'], 'status':'QUEUED', 'attempts':0}
        result=master_next_step(job,progress,verified_statuses,gaming)
        # Never change persisted revision or claim release approval.
        progress['status']=('PAUSED' if result['decision']=='PAUSED' else
                            'BLOCKED' if result['decision']=='BLOCKED' else
                            'AWAITING_USER' if result['decision']=='AI_TESTS_VERIFIED' else 'QUEUED')
        progress['last_decision']=result
        progress['release_approved']=False
        progress['user_acceptance_ready']=result['decision']=='AI_TESTS_VERIFIED'
        _master_atomic_json(path,progress)
        return result


def master_queue_cycle_from_registered_files():
    """Real CLI is intentionally blocked until trusted evidence is installed."""
    root=Path.home()/'.config/devnet-qa-automation'
    state=Path.home()/'.local/state/devnet-qa-controller/master-progress.json'
    jobfile=root/'master-job.json'
    if not jobfile.is_file() or jobfile.is_symlink():
        return {'decision':'BLOCKED','reason':'JOB_REGISTRATION_MISSING','next_stage':None}
    # Read and validate independently secured receipts; never accept AI status.
    evidence=master_job_gate_from_registered_files()
    statuses=(evidence.get('checks') if evidence.get('reason') in ('USER_ACCEPTANCE_PENDING','INCOMPLETE_CHECKS')
              and evidence.get('checks') else None)
    state.parent.mkdir(mode=0o700,parents=True,exist_ok=True)
    return master_cycle(jobfile,state,statuses,game_active())


# DEVNET_MASTER_RESTRICTED_EXECUTOR_V0_2_8
# Executes allowlisted, job-specific tests. This unprivileged harness cannot
# authenticate GitHub provenance or sign trusted production evidence.
# Root-only provisioning / attestation remains mandatory before deployment.
import time as _master_time
import uuid as _master_uuid

MASTER_EXEC_ALLOWED = frozenset(('python-unittest', 'python-compile'))


def master_execute_tests(plan, stage, project_root, evidence_dir, *, timeout_limit=90):
    """Run concrete tests, capture actual exit/log digests and fail closed.

    Plan must come from a trusted, immutable administrator-controlled source;
    never accept it from the AI's output. No shell, no SSH, no approval action.
    GitHub must run the GitHub stage *on GitHub*; this routine cannot assert
    the environment's identity and cannot replace GitHub workflow evidence.
    """
    if stage not in MASTER_STAGES:
        raise ValueError('INVALID_STAGE')
    if not isinstance(plan, dict) or set(plan) != {'schema','revision_sha256','tests'} or plan['schema'] != 'devnet-test-plan-v1':
        raise ValueError('INVALID_PLAN')
    revision=plan['revision_sha256']
    if not isinstance(revision,str) or not re.fullmatch(r'[0-9a-f]{64}',revision):
        raise ValueError('INVALID_REVISION')
    if type(timeout_limit) is not int or not 1 <= timeout_limit <= 300:
        raise ValueError('INVALID_TIMEOUT')
    root=Path(project_root).resolve(strict=True)
    if not root.is_dir() or Path(project_root).is_symlink():
        raise ValueError('INVALID_PROJECT_ROOT')
    tests=plan['tests']
    if not isinstance(tests,list) or not tests:
        raise ValueError('EMPTY_TEST_PLAN')
    names=set()
    for test in tests:
        if not isinstance(test,dict) or set(test) != {'name','stage','kind','target','timeout'}:
            raise ValueError('INVALID_TEST_SPEC')
        name, tstage, kind, target, limit=(test[k] for k in ('name','stage','kind','target','timeout'))
        if not isinstance(name,str) or not re.fullmatch(r'[A-Za-z0-9_.-]{1,80}',name) or name in names:
            raise ValueError('INVALID_TEST_NAME')
        names.add(name)
        if tstage not in MASTER_STAGES or kind not in MASTER_EXEC_ALLOWED or not isinstance(target,str):
            raise ValueError('INVALID_TEST_KIND')
        if type(limit) is not int or not 1 <= limit <= timeout_limit:
            raise ValueError('INVALID_TEST_TIMEOUT')
        # target must be a path strictly inside the immutable candidate tree.
        if target.startswith('/') or '..' in Path(target).parts or not target or '\x00' in target:
            raise ValueError('UNSAFE_TEST_TARGET')
        target_path=(root/target).resolve(strict=True)
        if not target_path.is_relative_to(root) or not target_path.is_file():
            raise ValueError('UNSAFE_TEST_TARGET')
        if target_path.is_symlink():
            raise ValueError('UNSAFE_TEST_SYMLINK')
        if kind=='python-unittest' and not target.endswith('.py'):
            raise ValueError('INVALID_TEST_MODULE')
    evidence_dir=Path(evidence_dir)
    if evidence_dir.is_symlink():
        raise ValueError('UNSAFE_EVIDENCE_DIR')
    evidence_dir.mkdir(mode=0o700,parents=True,exist_ok=True)
    if evidence_dir.stat().st_mode & 0o077:
        raise ValueError('UNSAFE_EVIDENCE_PERMISSIONS')
    results={}
    for test in tests:
        if test['stage']!=stage:continue
        name=test['name']; target=test['target']
        if test['kind']=='python-unittest':
            argv=[sys.executable,'-m','unittest','discover','-s',str((root/target).parent),'-p',Path(target).name,'-v']
        else:
            argv=[sys.executable,'-m','py_compile',str(root/target)]
        execution_id=_master_uuid.uuid4().hex
        log_path=evidence_dir/(execution_id+'.log')
        start=_master_time.monotonic()
        try:
            p=subprocess.run(argv,cwd=str(root),stdin=subprocess.DEVNULL,stdout=subprocess.PIPE,
                             stderr=subprocess.STDOUT,timeout=test['timeout'],check=False)
            code=p.returncode; data=p.stdout[:1024*1024]
            if len(p.stdout)>len(data):
                code=125; data+=b'\n[OUTPUT_LIMIT_EXCEEDED]\n'
        except subprocess.TimeoutExpired as exc:
            code=124; data=((exc.stdout or b'')[:1024*1024]+b'\n[TIMEOUT]\n')
        except OSError as exc:
            code=126; data=('EXECUTION_ERROR: '+type(exc).__name__).encode()
        with log_path.open('xb') as stream:
            os.fchmod(stream.fileno(),0o600)
            stream.write(data);stream.flush();os.fsync(stream.fileno())
        results[name]={'status':'PASS' if code==0 else 'FAIL',
                       'execution_id':execution_id,'test_revision_sha256':revision,
                       'log_sha256':_master_digest(data),'exit_code':code,'stage':stage,
                       'elapsed_ms':round((_master_time.monotonic()-start)*1000)}
    return results



# DEVNET_MASTER_LIVE_STAGE_CYCLE_V0_2_9
# Restrained, local-only stage execution. Results are *untrusted preliminary*
# until independently verified by the protected executor and GitHub run.
# This routine neither signs results nor makes a release decision.
def master_run_stage_cycle(job, progress, plan, stage, root, logs, checkpoint, *, gaming=False):
    """Execute every applicable stage test and checkpoint actual results.

    A failed test blocks; an authorised external repair creates a NEW revision
    and resets the complete stage chain. No AI-supplied PASS may be ingested.
    It is essential that the stage is invoked *inside* its real environment:
    github only on a GitHub Actions runner, vm inside isolated QA VM, and host
    on the host after independently verified earlier-stage attestations.
    """
    if not isinstance(job, dict) or not isinstance(progress, dict) or not isinstance(plan, dict):
        raise ValueError('INVALID_JOB_PLAN')
    if stage not in MASTER_STAGES:
        raise ValueError('INVALID_STAGE')
    if job.get('revision_sha256') != plan.get('revision_sha256') or progress.get('revision_sha256') != job.get('revision_sha256'):
        raise ValueError('REVISION_MISMATCH_FULL_RETEST_REQUIRED')
    if progress.get('schema') != MASTER_STATE_SCHEMA or progress.get('job_id') != job.get('job_id'):
        raise ValueError('INVALID_PROGRESS')
    if gaming or progress.get('status') == 'OPERATOR_HOLD':
        return {'decision':'PAUSED','reason':'GAMING_OR_SAFETY_HOLD','results':{}}
    if (not isinstance(job.get('stages'),dict) or set(job['stages']) != set(MASTER_STAGES)
            or not isinstance(job.get('requirements'),list) or not job['requirements']
            or any(not isinstance(job['stages'][k],list) for k in MASTER_STAGES)
            or sum((job['stages'][k] for k in MASTER_STAGES),[]) != job['requirements']):
        raise ValueError('INVALID_CHECKLIST')
    if stage == 'github' and os.environ.get('GITHUB_ACTIONS') != 'true':
        raise ValueError('GITHUB_RUNNER_REQUIRED')
    # Prior stages cannot be inferred from AI-generated progress. A separate
    # trusted gate must explicitly supply verified prior-stage evidence.
    if stage != 'github':
        raise ValueError('TRUSTED_PRIOR_STAGE_ATTESTATIONS_REQUIRED')
    tests=plan.get('tests')
    if (not isinstance(tests,list) or set(t.get('name') for t in tests if isinstance(t,dict)) != set(job['requirements'])
            or len(tests)!=len(job['requirements'])):
        raise ValueError('PLAN_DOES_NOT_COVER_ALL_REQUIREMENTS')
    for st in MASTER_STAGES:
        if set(t['name'] for t in tests if t.get('stage')==st) != set(job['stages'][st]):
            raise ValueError('PLAN_STAGE_MISMATCH')
    state_file=Path(checkpoint)
    state_file.parent.mkdir(parents=True,mode=0o700,exist_ok=True)
    with (state_file.parent/'master-stage.lock').open('a+b') as lock:
        fcntl.flock(lock,fcntl.LOCK_EX)
        # Never reuse success from an earlier run: each invocation executes every
        # applicable test afresh, even after a failed run or process restart.
        results=master_execute_tests(plan,stage,root,logs)
        if set(results)!=set(job['stages'][stage]):
            raise RuntimeError('INCOMPLETE_STAGE_EXECUTION')
        decision='PRELIMINARY_PASS_UNTRUSTED' if all(v['status']=='PASS' for v in results.values()) else 'FAILED_REPAIR_REQUIRED'
        record={'schema':'devnet-master-stage-checkpoint-v1','job_id':job['job_id'],
                'revision_sha256':job['revision_sha256'],'stage':stage,'decision':decision,
                'results':results,'release_approved':False,'user_acceptance_ready':False}
        _master_atomic_json(state_file,record)
        return record

def main():
    if sys.argv[1:] == ['master-cycle']:
        print(json.dumps(master_queue_cycle_from_registered_files(),sort_keys=True))
        return 0
    if sys.argv[1:] == ['master-status']:
        print(json.dumps(master_job_gate_from_registered_files(),sort_keys=True))
        return 0
    if sys.argv[1:] not in (['once'],['status']):
        return 64
    os.umask(0o077)
    if sys.argv[1]=='status':
        try:
            d=json.loads((STATE/'latest.json').read_text())
            print('QA:',d['qa'],'TRIAGE:',d['triage'],'ATTEMPTS:',d['attempts'],
                  'APPROVALS:',0)
        except (OSError,KeyError,ValueError):
            print('QA: NOT_TESTED')
        return 0
    STATE.mkdir(mode=0o700,parents=True,exist_ok=True)
    with (STATE/'controller.lock').open('a+b') as lock:
        try:
            fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
        except BlockingIOError:
            print('BLOCKED_UNAVAILABLE')
            return 2
        state=run_once()
    print(state)
    return 0 if state in ('PASS_LIMITED','PARTIAL','PAUSED_GAME') else 2

if __name__=='__main__':
    raise SystemExit(main())
