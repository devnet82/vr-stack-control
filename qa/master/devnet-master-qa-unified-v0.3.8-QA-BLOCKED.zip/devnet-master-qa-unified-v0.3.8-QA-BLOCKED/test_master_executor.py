import ast, hashlib, json, pathlib, tempfile, unittest
from pathlib import Path
SOURCE=Path(__file__).parent/'devnet-qa-automation/controller.py'
tree=ast.parse(SOURCE.read_text())
fn=next(n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name=='master_execute_tests')
ns={'MASTER_STAGES':('github','vm','host'),'MASTER_EXEC_ALLOWED':frozenset(('python-unittest','python-compile')),'Path':Path,'re':__import__('re'),'sys':__import__('sys'),'os':__import__('os'),'subprocess':__import__('subprocess'),'_master_time':__import__('time'),'_master_uuid':__import__('uuid'),'_master_digest':lambda b:hashlib.sha256(b).hexdigest()}
exec(compile(ast.Module(body=[fn],type_ignores=[]),str(SOURCE),'exec'),ns)
run=ns['master_execute_tests']
REV='a'*64
class ExecutorTests(unittest.TestCase):
 def setUp(self):
  self.tmp=tempfile.TemporaryDirectory();self.addCleanup(self.tmp.cleanup)
  self.root=Path(self.tmp.name)/'project';self.root.mkdir();self.out=Path(self.tmp.name)/'logs';self.out.mkdir(mode=0o700)
  (self.root/'check.py').write_text('import unittest\nclass Check(unittest.TestCase):\n def test_real(self): self.assertEqual(2+2,4)\n')
  self.test={'name':'actual','stage':'github','kind':'python-unittest','target':'check.py','timeout':5}
  self.plan={'schema':'devnet-test-plan-v1','revision_sha256':REV,'tests':[self.test]}
 def test_runs_real_python_test(self):
  r=run(self.plan,'github',self.root,self.out);self.assertEqual(r['actual']['status'],'PASS');self.assertEqual(r['actual']['exit_code'],0)
  self.assertEqual(hashlib.sha256(next(self.out.glob('*.log')).read_bytes()).hexdigest(),r['actual']['log_sha256'])
 def test_real_test_failure(self):
  (self.root/'check.py').write_text('import unittest\nclass Check(unittest.TestCase):\n def test_real(self): self.fail("FAIL_FOR_REAL")\n')
  r=run(self.plan,'github',self.root,self.out);self.assertEqual(r['actual']['status'],'FAIL');self.assertNotEqual(r['actual']['exit_code'],0)
  self.assertIn(b'FAIL_FOR_REAL',next(self.out.glob('*.log')).read_bytes())
 def test_real_syntax_failure(self):
  (self.root/'check.py').write_text('this is not valid python(\n')
  self.test['kind']='python-compile';r=run(self.plan,'github',self.root,self.out);self.assertEqual(r['actual']['status'],'FAIL')
 def test_compile_success(self):
  self.test['kind']='python-compile';self.assertEqual(run(self.plan,'github',self.root,self.out)['actual']['status'],'PASS')
 def test_stage_isolation(self):self.assertEqual(run(self.plan,'vm',self.root,self.out),{})
 def test_no_shell_injection(self):
  self.test['target']='check.py;touch HACKED';
  with self.assertRaises((ValueError,FileNotFoundError)):run(self.plan,'github',self.root,self.out)
  self.assertFalse((self.root/'HACKED').exists())
 def test_traversal_rejected(self):
  self.test['target']='../external.py'
  with self.assertRaises(ValueError):run(self.plan,'github',self.root,self.out)
 def test_absolute_rejected(self):
  self.test['target']='/etc/passwd'
  with self.assertRaises(ValueError):run(self.plan,'github',self.root,self.out)
 def test_symlink_escape_rejected(self):
  (self.root/'escape.py').symlink_to('/etc/passwd');self.test['target']='escape.py'
  with self.assertRaises(ValueError):run(self.plan,'github',self.root,self.out)
 def test_duplicate_names_rejected(self):
  self.plan['tests'].append(dict(self.test))
  with self.assertRaises(ValueError):run(self.plan,'github',self.root,self.out)
 def test_malformed_spec_rejected(self):
  del self.test['timeout']
  with self.assertRaises(ValueError):run(self.plan,'github',self.root,self.out)
 def test_timeout(self):
  (self.root/'check.py').write_text('import time\ntime.sleep(3)\n');self.test['timeout']=1
  self.assertEqual(run(self.plan,'github',self.root,self.out)['actual']['exit_code'],124)
 def test_no_evidence_on_missing_target(self):
  self.test['target']='missing.py'
  with self.assertRaises(FileNotFoundError):run(self.plan,'github',self.root,self.out)
  self.assertEqual(list(self.out.iterdir()),[])
 def test_invalid_permissions(self):
  self.out.chmod(0o755)
  with self.assertRaises(ValueError):run(self.plan,'github',self.root,self.out)
 def test_no_production_signature(self):
  self.assertNotIn('signature',run(self.plan,'github',self.root,self.out)['actual'])
if __name__=='__main__':unittest.main()
