import importlib.util, pathlib, tempfile, unittest

p=pathlib.Path(__file__).resolve().parent/'devnet-qa-automation/controller.py'
s=importlib.util.spec_from_file_location('master_repair_under_test',p)
m=importlib.util.module_from_spec(s);s.loader.exec_module(m)

class RepairTests(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory();self.addCleanup(self.tmp.cleanup)
        self.root=pathlib.Path(self.tmp.name);self.src=self.root/'src';self.src.mkdir()
        (self.src/'app.py').write_text('def value():\n    return 3\n')
        (self.src/'test_app.py').write_text('import unittest\nfrom app import value\nclass Check(unittest.TestCase):\n def test_value(self): self.assertEqual(value(),2)\n')
        (self.src/'test_second.py').write_text('import unittest\nclass Check(unittest.TestCase):\n def test_ok(self): self.assertTrue(True)\n')
        self.digest=m.master_source_tree_digest(self.src)
        self.plan={'schema':'devnet-test-plan-v1','revision_sha256':self.digest,'tests':[
            {'name':n,'stage':'host','kind':'python-unittest','target':f,'timeout':15}
            for n,f in [('check_value','test_app.py'),('check_other','test_second.py')]]}
        self.patch={'path':'app.py','old':'return 3','new':'return 2','explanation':'Correct implementation','risk':'low'}
        self.proposal={'schema':'devnet-master-repair-proposal-v1','decision':'PROPOSAL_ONLY','source_mutated':False,'release_approved':False,'revision_sha256':self.digest,'allowed_files':['app.py'],'patch':self.patch}
    def apply(self,**kwargs):
        return m.master_apply_reviewed_repair(self.proposal,self.src,self.root/'staged',self.plan,['app.py'],stage='host',evidence_dir=self.root/'evidence',**kwargs)
    def test_requires_explicit_authorisation(self):
        with self.assertRaisesRegex(PermissionError,'REPAIR_AUTHORISATION_REQUIRED'):self.apply()
        self.assertFalse((self.root/'staged').exists())
    def test_real_full_stage_retest(self):
        rec=self.apply(authorisation=True)
        self.assertEqual(rec['decision'],'PRELIMINARY_PASS_UNTRUSTED')
        self.assertEqual(set(rec['results']),{'check_value','check_other'})
        self.assertTrue(all(v['status']=='PASS' for v in rec['results'].values()))
        self.assertTrue(rec['logs_verified']);self.assertFalse(rec['release_approved'])
        self.assertEqual((self.src/'app.py').read_text(),'def value():\n    return 3\n')
        self.assertEqual((self.root/'staged/app.py').read_text(),'def value():\n    return 2\n')
        self.assertEqual(m.master_source_tree_digest(self.src),self.digest)
    def test_bad_fix_still_fails(self):
        self.patch['new']='return 4'
        rec=self.apply(authorisation=True)
        self.assertEqual(rec['decision'],'FAILED_REPAIR_REQUIRED')
        self.assertEqual(rec['results']['check_value']['status'],'FAIL')
        self.assertEqual(rec['results']['check_other']['status'],'PASS')
    def test_test_file_forbidden(self):
        with self.assertRaisesRegex(ValueError,'INVALID_REPAIR_ALLOWLIST'):m._master_repair_allowlist(['test_app.py'])
    def test_allowlist_mismatch(self):
        self.proposal['allowed_files']=['other.py']
        with self.assertRaisesRegex(ValueError,'ALLOWLIST_MISMATCH'):self.apply(authorisation=True)
    def test_old_text_must_be_unique(self):
        self.patch['old']='return 999'
        with self.assertRaisesRegex(ValueError,'REPAIR_CONTEXT_NOT_UNIQUE'):self.apply(authorisation=True)
    def test_stale_source_refused(self):
        (self.src/'app.py').write_text('def value():\n    return 99\n')
        with self.assertRaisesRegex(ValueError,'STALE_REPAIR_REVISION'):self.apply(authorisation=True)
    def test_staging_must_be_separate(self):
        with self.assertRaisesRegex(ValueError,'STAGING_MUST_BE_NEW_AND_SEPARATE'):
            m.master_apply_reviewed_repair(self.proposal,self.src,self.src/'nested',self.plan,['app.py'],authorisation=True,evidence_dir=self.root/'evidence')
    def test_reject_shell_like_proposal(self):
        self.patch['path']='../app.py'
        with self.assertRaisesRegex(ValueError,'UNAUTHORISED_REPAIR_PATH'):self.apply(authorisation=True)
    def test_original_remains_on_failure(self):
        self.patch['new']='return ???'
        rec=self.apply(authorisation=True)
        self.assertEqual(rec['results']['check_value']['status'],'FAIL')
        self.assertEqual(m.master_source_tree_digest(self.src),self.digest)
    def test_disallow_untrusted_proposal(self):
        self.proposal['decision']='PASS'
        with self.assertRaisesRegex(ValueError,'INVALID_REPAIR_PROPOSAL'):self.apply(authorisation=True)

if __name__=='__main__': unittest.main()
