import importlib.util,json,os,tempfile,unittest
from pathlib import Path
from unittest.mock import patch
SOURCE=Path(__file__).parent/'devnet-qa-automation/controller.py'
sp=importlib.util.spec_from_file_location('devnet_v030',SOURCE)
mod=importlib.util.module_from_spec(sp);sp.loader.exec_module(mod)
class BoundTests(unittest.TestCase):
 def setUp(self):
  self.t=tempfile.TemporaryDirectory();self.addCleanup(self.t.cleanup)
  self.base=Path(self.t.name);self.root=self.base/'project';self.root.mkdir()
  (self.root/'sample.py').write_text('import unittest\nclass T(unittest.TestCase):\n def test_ok(self): self.assertTrue(True)\n')
  self.rev=mod.master_source_tree_digest(self.root)
  self.job={'schema':'devnet-master-job-v1','job_id':'bound','revision_sha256':self.rev,'requirements':['test'], 'stages':{'github':['test'],'vm':[],'host':[]}}
  self.progress={'schema':mod.MASTER_STATE_SCHEMA,'job_id':'bound','revision_sha256':self.rev,'status':'QUEUED'}
  self.plan={'schema':'devnet-test-plan-v1','revision_sha256':self.rev,'tests':[{'name':'test','stage':'github','kind':'python-unittest','target':'sample.py','timeout':5}]}
  self.logs=self.base/'logs';self.logs.mkdir(mode=0o700);self.ck=self.base/'state/checkpoint.json'
 def run_stage(self):
  with patch.dict(os.environ,{'GITHUB_ACTIONS':'true'}):return mod.master_run_bound_stage_cycle(self.job,self.progress,self.plan,'github',self.root,self.logs,self.ck)
 def test_real_pass_bound_to_source_and_logs(self):
  r=self.run_stage();self.assertEqual(r['decision'],'PRELIMINARY_PASS_UNTRUSTED');self.assertTrue(mod.master_verify_stage_logs(r,self.logs));self.assertEqual(r['source_tree_sha256'],self.rev);self.assertFalse(r['user_acceptance_ready'])
 def test_fake_revision_rejected(self):
  self.job['revision_sha256']='b'*64
  with self.assertRaisesRegex(ValueError,'SOURCE_REVISION_MISMATCH'):self.run_stage()
 def test_source_change_requires_fresh_revision(self):
  (self.root/'sample.py').write_text('print(123)\n')
  with self.assertRaisesRegex(ValueError,'SOURCE_REVISION_MISMATCH'):self.run_stage()
 def test_corrupt_log_rejected(self):
  r=self.run_stage();p=next(self.logs.glob('*.log'));p.write_bytes(b'TAMPERED');self.assertFalse(mod.master_verify_stage_logs(r,self.logs))
 def test_removed_log_rejected(self):
  r=self.run_stage();next(self.logs.glob('*.log')).unlink();self.assertFalse(mod.master_verify_stage_logs(r,self.logs))
 def test_fake_success_with_nonzero_exit_rejected(self):
  r=self.run_stage();r['results']['test']['exit_code']=19;self.assertFalse(mod.master_verify_stage_logs(r,self.logs))
 def test_failing_test_still_fails(self):
  (self.root/'sample.py').write_text('import unittest\nclass T(unittest.TestCase):\n def test_no(self): self.fail("X")\n');self.rev=mod.master_source_tree_digest(self.root)
  self.job['revision_sha256']=self.rev;self.progress['revision_sha256']=self.rev;self.plan['revision_sha256']=self.rev
  r=self.run_stage();self.assertEqual(r['decision'],'FAILED_REPAIR_REQUIRED');self.assertEqual(r['results']['test']['exit_code'],1)
 def test_symlink_refused(self):
  (self.root/'evil').symlink_to('/etc/hosts')
  with self.assertRaisesRegex(ValueError,'SOURCE_SYMLINK_REFUSED'):mod.master_source_tree_digest(self.root)
 def test_tree_digest_deterministic(self):self.assertEqual(mod.master_source_tree_digest(self.root),self.rev)
 def test_added_file_changes_digest(self):
  (self.root/'new.txt').write_text('new');self.assertNotEqual(mod.master_source_tree_digest(self.root),self.rev)
 def test_no_trusted_signature(self):
  r=self.run_stage();self.assertNotIn('signature',r);self.assertFalse(r['release_approved'])
 def test_restart_does_not_reuse_old_results(self):
  first=self.run_stage();other=self.run_stage();self.assertNotEqual(first['results']['test']['execution_id'],other['results']['test']['execution_id'])
if __name__=='__main__':unittest.main()
