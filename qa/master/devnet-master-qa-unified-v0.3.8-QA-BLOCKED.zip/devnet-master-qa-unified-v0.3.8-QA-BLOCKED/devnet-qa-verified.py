#!/usr/bin/env python3
"""Run existing VM QA and validate raw JSON without model-generated counts."""
import collections
import json
import subprocess
import sys

COMMAND = ['ssh', '-o', 'BatchMode=yes', '-o', 'ConnectTimeout=15',
           'devnet@192.168.122.71',
           'SSH_ORIGINAL_COMMAND=run python3 /home/devnet/devnet-qa/bin/qa-app-runner-v0.3.0.py']
VALID = {'PASS', 'FAIL', 'BLOCKED', 'NOT_TESTED'}

def validate(raw):
    data = json.loads(raw)
    if not isinstance(data, dict) or not isinstance(data.get('checks'), dict) or not data['checks']:
        raise ValueError('Missing or empty checks object')
    if not isinstance(data.get('release'), str) or not data['release']:
        raise ValueError('Missing release')
    if not isinstance(data.get('schema'), str) or not data['schema']:
        raise ValueError('Missing schema')
    if not isinstance(data.get('decision'), str) or not data['decision']:
        raise ValueError('Missing decision')
    checks = data['checks']
    if any(not isinstance(k, str) or not k or not isinstance(v, str) or v not in VALID for k,v in checks.items()):
        raise ValueError('Invalid check name or status')
    counts = collections.Counter(checks.values())
    total = len(checks)
    if sum(counts.values()) != total:
        raise ValueError('Inconsistent check counts')
    return {'schema':'devnet-qa-verified-v1', 'release':data['release'],
            'source_schema':data['schema'], 'checks':checks, 'total':total,
            'counts':{key:counts[key] for key in ('PASS','FAIL','BLOCKED','NOT_TESTED')},
            'decision':data['decision'], 'evidence':'VERIFIED',
            'master_qa':'NOT_VERIFIED', 'release_approved':False}

def main():
    if sys.argv[1:] == ['--self-test']:
        example={'schema':'devnet-app-qa-v1','release':'fixture', 'decision':'BLOCKED',
                 'checks':{'a':'PASS','b':'PASS','c':'FAIL','d':'NOT_TESTED'}}
        result=validate(json.dumps(example))
        assert result['total']==4 and result['counts']=={'PASS':2,'FAIL':1,'BLOCKED':0,'NOT_TESTED':1}
        for bad in ('{}', '{', '{"checks":{}}', json.dumps({**example,'checks':{'a':'UNKNOWN'}})):
            try: validate(bad)
            except (ValueError, json.JSONDecodeError): pass
            else: raise AssertionError('Invalid evidence accepted')
        print('SELF_TEST=PASS')
        return 0
    if sys.argv[1:]:
        print('DENIED: unsupported arguments', file=sys.stderr)
        return 64
    try:
        p=subprocess.run(COMMAND, capture_output=True, text=True, timeout=180, check=False)
        if p.returncode != 0:
            raise RuntimeError('QA command failed (exit '+str(p.returncode)+')')
        report=validate(p.stdout)
        print(json.dumps(report, sort_keys=True, separators=(',',':')))
        return 0
    except (OSError, subprocess.TimeoutExpired, ValueError, RuntimeError, json.JSONDecodeError) as exc:
        print(json.dumps({'schema':'devnet-qa-verified-v1','evidence':'INVALID',
                          'master_qa':'NOT_VERIFIED','release_approved':False,
                          'decision':'BLOCKED','error':str(exc)},sort_keys=True))
        return 1

if __name__=='__main__':
    sys.exit(main())
