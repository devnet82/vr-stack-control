#!/usr/bin/env python3
"""Restricted disposable QEMU/KVM test worker for the ONE Devnet Master QA controller.

Unprivileged diagnostic VM worker: NO signing, NO release authority, NO installer,
NO arbitrary shell commands. All test names/targets come from preauthorised plan.
"""
from __future__ import annotations
import importlib.util
import json
from pathlib import Path
import re
import subprocess
import sys
import zipfile


def worker(action, work):
    work=Path(work)
    if (not re.fullmatch(r'/tmp/devnet-master-cycle-[A-Za-z0-9]{8,12}',str(work))
            or work.is_symlink() or not work.is_dir() or work.stat().st_mode & 0o077):
        raise ValueError('UNSAFE_VM_WORKSPACE')
    virt=subprocess.run(['systemd-detect-virt','--vm'],capture_output=True,text=True,timeout=5)
    if virt.returncode!=0 or virt.stdout.strip() not in ('kvm','qemu'):
        raise ValueError('ISOLATED_QEMU_KVM_VM_REQUIRED')
    controller=work/'module/devnet-qa-automation/controller.py'
    sys.path.insert(0,str(controller.parent))
    spec=importlib.util.spec_from_file_location('devnet_vm_worker_controller',controller)
    m=importlib.util.module_from_spec(spec)
    spec.loader.exec_module(m)
    plan=json.loads((work/'plan.json').read_text())
    src=work/'source'
    if action=='initial':
        src.mkdir(mode=0o700)
        with zipfile.ZipFile(work/'source.zip') as z:
            info=z.infolist()
            if not info or len(info)>128 or sum(x.file_size for x in info)>4*1024*1024:
                raise ValueError('UNSAFE_SOURCE_ARCHIVE')
            for x in info:
                path=Path(x.filename)
                if (x.is_dir() or path.is_absolute() or any(p.startswith('.') or p=='..' for p in path.parts)
                        or path.suffix not in ('.py','.json','.txt') or x.file_size>256*1024):
                    raise ValueError('UNSAFE_SOURCE_ARCHIVE')
            if len({x.filename for x in info})!=len(info):raise ValueError('DUPLICATE_SOURCE_FILES')
            z.extractall(src)
        digest=m.master_source_tree_digest(src)
        if digest!=plan['revision_sha256']:
            raise ValueError('SOURCE_HASH_MISMATCH')
        results=m.master_execute_tests(plan,'vm',src,work/'logs')
        if set(results)!={t['name'] for t in plan['tests']}:
            raise ValueError('INCOMPLETE_INITIAL_TESTS')
        record={'decision':'FAILED_REPAIR_REQUIRED' if any(v['status']=='FAIL' for v in results.values()) else 'PRELIMINARY_PASS_UNTRUSTED',
                'job_id':json.loads((work/'job.json').read_text())['job_id'],
                'revision_sha256':digest,'results':results,'release_approved':False}
        if not m.master_verify_stage_logs(record,work/'logs') or m.master_source_tree_digest(src)!=digest:
            raise ValueError('EVIDENCE_OR_SOURCE_MUTATED')
        m._master_atomic_json(work/'record.json',record)
        return {'decision':record['decision'],'source_sha256':digest,'release_approved':False}
    if action=='retest':
        proposal=json.loads((work/'proposal.json').read_text())
        job=json.loads((work/'job.json').read_text())
        if m.master_source_tree_digest(src)!=plan['revision_sha256']:
            raise ValueError('ORIGINAL_SOURCE_CHANGED')
        result=m.master_apply_reviewed_repair(
            proposal,src,work/'staged',plan,job['allowed_files'],
            authorisation=job['authorised_vm_diagnostic'],stage='vm',evidence_dir=work/'retest_logs')
        if not m.master_verify_stage_logs(result,work/'retest_logs'):
            raise ValueError('VM_RETEST_LOGS_INVALID')
        # This result is only a preliminary diagnostic test, not attested proof.
        result['release_approved']=False
        result['user_acceptance_ready']=False
        m._master_atomic_json(work/'retest.json',result)
        return {'decision':result['decision'],'release_approved':False}
    raise ValueError('UNKNOWN_WORKER_ACTION')


if __name__=='__main__':
    try:
        if len(sys.argv)!=3 or sys.argv[1] not in ('initial','retest'):
            raise ValueError('INVALID_VM_WORKER_COMMAND')
        print(json.dumps(worker(sys.argv[1],sys.argv[2]),sort_keys=True))
    except Exception as exc:
        print(json.dumps({'decision':'BLOCKED','reason':type(exc).__name__,'release_approved':False}),flush=True)
        sys.exit(2)
