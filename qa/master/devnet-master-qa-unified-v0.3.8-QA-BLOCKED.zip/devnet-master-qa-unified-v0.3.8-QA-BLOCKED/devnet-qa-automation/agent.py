#!/usr/bin/env python3
"""Devnet local-only unattended QA, game pause and privacy guard.

Deliberately no OpenCode shell integration, remote arbitrary command execution,
GitHub write support, or outbound network services. Runs only the already
restricted remote QA runner's allowlisted operations.
"""
from __future__ import annotations

import argparse
import datetime as dt
import ipaddress
import json
import os
from pathlib import Path
import re
import subprocess
import sys
import time

VERSION = "0.4.4"
ALLOWED = ("status", "self-test", "evaluate")
QA_VM_IP = "192.168.122.71"
QA_VM_USER = "devnet"
KEY_NAME = "devnet-ai-qa-ed25519"
APP_KEY_NAME = "devnet-app-qa-ed25519"
MODEL = "qwen3.5:9b"
GUARD_INTERVAL = 5
STATE_ROOT = Path.home() / ".local/state/devnet-qa-automation"
SETTINGS_DIR = Path.home() / ".config/devnet-qa-automation"
MANUAL_PAUSE = SETTINGS_DIR / "gaming-on"
STOP_FILE = SETTINGS_DIR / "stop-all"
USER_QA_SERVICE = "devnet-qa-automation.service"
USER_QA_TIMER = "devnet-qa-automation.timer"
MEMORY_TIMER = "devnet-openwebui-memory-sync.timer"
MEMORY_SERVICE = "devnet-openwebui-memory-sync.service"
# Deliberately don't treat idle Steam launcher, Discord, GPU drivers, SteamWebHelper,
# PipeWire, games downloaded to disk, or standby VR-related system services as games.
GAME_NAMES = {
    "gamescope", "wine64-preloader", "wine-preloader", "vrchat.exe",
    "vrserver", "vrcompositor", "vrmonitor", "steamvr", "steamvr.exe",
    "hlvr.exe", "wineserver", "umu-run", "proton", "wivrn-server"
}


def safe_dirs() -> None:
    for directory in (STATE_ROOT, SETTINGS_DIR):
        directory.mkdir(mode=0o700, parents=True, exist_ok=True)
        os.chmod(directory, 0o700)


def utcnow() -> str:
    return dt.datetime.now(dt.timezone.utc).isoformat(timespec="seconds")


def process_is_game(comm: str, cmdline: str) -> bool:
    name = comm.lower().strip()
    if name in GAME_NAMES:
        return True
    cmd = cmdline.lower()
    if "/steamapps/common/" in cmd or "/steamapps/compatdata/" in cmd:
        return True
    # Wine game processes are commonly .exe; conservatively pause on them.
    if name.endswith(".exe") and name not in ("explorer.exe", "services.exe", "steam.exe"):
        return True
    return False


def gaming_now(proc_root: Path = Path("/proc")) -> bool:
    # Manual override for native games where process heuristics cannot prove activity.
    if MANUAL_PAUSE.exists() or STOP_FILE.exists():
        return True
    # Fail closed if procfs is unavailable.
    if not proc_root.is_dir():
        return True
    try:
        for item in proc_root.iterdir():
            if not item.name.isdigit():
                continue
            try:
                comm = (item / "comm").read_text(errors="replace").strip()[:128]
                cmd = (item / "cmdline").read_bytes()[:8192].replace(b"\0", b" ").decode(errors="replace")
            except (ProcessLookupError, FileNotFoundError, PermissionError, OSError):
                continue  # a process may have exited; never log its arguments
            if process_is_game(comm, cmd):
                return True
    except OSError:
        return True
    return False


def check_key() -> Path:
    # No SSH agent forwarding, network proxy, fallback identity or shell command.
    ip = ipaddress.ip_address(QA_VM_IP)
    if not ip.is_private or str(ip) != "192.168.122.71":
        raise RuntimeError("VM destination not allowlisted")
    key = Path.home() / ".ssh" / KEY_NAME
    st = key.lstat()
    if not key.is_file() or key.is_symlink() or (st.st_mode & 0o077):
        raise RuntimeError("Restricted VM private key missing or permissions unsafe")
    return key


def ssh_query(action: str) -> tuple[int, str]:
    if action not in ALLOWED:
        raise ValueError("Refusing non-allowlisted QA action")
    key = check_key()
    cmd = ["/usr/bin/ssh", "-F", "/dev/null", "-i", str(key),
           "-o", "IdentitiesOnly=yes", "-o", "BatchMode=yes",
           "-o", "ForwardAgent=no", "-o", "ClearAllForwardings=yes",
           "-o", "StrictHostKeyChecking=yes", "-o", "ConnectTimeout=5",
           "-o", "ServerAliveInterval=5", "-o", "ServerAliveCountMax=2",
           "-T", f"{QA_VM_USER}@{QA_VM_IP}", action]
    # No shell execution or arbitrary user/project input is allowed.
    p = subprocess.run(cmd, text=True, capture_output=True,
                       timeout={"status": 12, "self-test": 90, "evaluate": 150}[action], check=False)
    # Output stays in memory; never save raw CLI output, paths or projects.
    return p.returncode, p.stdout + "\n" + p.stderr


APP_TEST_RESULTS = ("PASS", "FAIL", "NOT_TESTED", "BLOCKED")
APP_CHECKS = ("package_integrity", "source_integrity", "script_syntax", "tray_lock", "package_python_tests", "package_shell_tests", "gui_process_smoke", "tray_process_smoke", "gui_tab_navigation", "gui_clean_close", "tray_menu_wiring", "gui_sidebar_activation", "gui_pointer_navigation")


def ssh_application_test() -> tuple[int, str]:
    """Second forced-command VM key: exact run operation, never shell access."""
    key = Path.home() / ".ssh" / APP_KEY_NAME
    try:
        st = key.lstat()
        if not key.is_file() or key.is_symlink() or (st.st_mode & 0o077):
            raise RuntimeError("App QA private key missing or permissions unsafe")
    except FileNotFoundError as exc:
        raise RuntimeError("App QA not provisioned") from exc
    cmd = ["/usr/bin/ssh", "-F", "/dev/null", "-i", str(key),
           "-o", "IdentitiesOnly=yes", "-o", "BatchMode=yes",
           "-o", "ForwardAgent=no", "-o", "ClearAllForwardings=yes",
           "-o", "StrictHostKeyChecking=yes", "-o", "ConnectTimeout=5",
           "-o", "ServerAliveInterval=5", "-o", "ServerAliveCountMax=2",
           "-T", f"{QA_VM_USER}@{QA_VM_IP}", "run"]
    p = subprocess.run(cmd, text=True, capture_output=True, timeout=175, check=False)
    return p.returncode, p.stdout + "\n" + p.stderr


def application_test_result(rc: int, output: str) -> str:
    # Privacy: never persist raw output; accept one small exact-format record.
    if rc != 0 or len(output) > 4096:
        return "FAIL"
    lines = [x for x in output.splitlines() if x.startswith("{") and x.endswith("}")]
    if len(lines) != 1:
        return "FAIL"
    try:
        d = json.loads(lines[0])
    except json.JSONDecodeError:
        return "FAIL"
    if not isinstance(d, dict) or set(d) != {"schema", "release", "decision", "checks"}:
        return "FAIL"
    if (d["schema"] != "devnet-app-qa-v1" or d["release"] != "vr-stack-v0.6.132"
            or d["decision"] != "BLOCKED" or not isinstance(d["checks"], dict)
            or set(d["checks"]) != set(APP_CHECKS)):
        return "FAIL"
    if any(v not in APP_TEST_RESULTS for v in d["checks"].values()):
        return "FAIL"
    if any(v == "FAIL" or v == "BLOCKED" for v in d["checks"].values()):
        return "BLOCKED"
    if any(v == "NOT_TESTED" for v in d["checks"].values()):
        return "PARTIAL"
    return "PASS_LIMITED"


def status_result(rc: int, output: str) -> bool:
    if rc != 0:
        return False
    try:
        lines = [x for x in output.splitlines() if x.startswith("{") and x.endswith("}")]
        result = json.loads(lines[-1])
        return result.get("runner") == "devnet-qa-v0.1.1" and result.get("qa") == "NOT_APPROVED"
    except (IndexError, json.JSONDecodeError):
        return False


def self_test_result(rc: int, output: str) -> bool:
    return rc == 0 and bool(re.search(r"(?m)^Ran 9 tests in ", output)) and bool(re.search(r"(?m)^OK\s*$", output))


def evaluate_result(rc: int, output: str) -> bool:
    expected = {"rgb", "vr_stack", "wayvr", "chatbox", "wrapper", "proton", "sonic", "repair"}
    lines = [x for x in output.splitlines() if re.match(r"^(rgb|vr_stack|wayvr|chatbox|wrapper|proton|sonic|repair) ", x)]
    ids = set()
    for line in lines:
        m = re.fullmatch(r"(rgb|vr_stack|wayvr|chatbox|wrapper|proton|sonic|repair) BLOCKED PASS 0 FAIL 0 NOT_TESTED 18\s+EVIDENCE_ERROR\s*", line)
        if m is None or m.group(1) in ids:
            return False
        ids.add(m.group(1))
    return rc == 2 and "DEVNET_MASTER_QA_v0.1.7_BLOCKED" in output and ids == expected and len(lines) == 8


def report_write(report: dict) -> None:
    safe_dirs()
    target = STATE_ROOT / "latest.json"
    # Only redacted, categorical data is persisted. No model prompts, project
    # content, machine paths, usernames, console output, IP or GitHub credentials.
    fields = ("schema", "utc", "gaming", "qa", "runner", "framework", "evidence_gate", "application_suite", "app_approvals", "decisions")
    redacted = {x: report[x] for x in fields if x in report}
    data = (json.dumps(redacted, indent=2, sort_keys=True) + "\n").encode()
    import tempfile
    fd, tmp = tempfile.mkstemp(prefix="qa-", dir=STATE_ROOT)
    try:
        os.fchmod(fd, 0o600)
        with os.fdopen(fd, "wb") as f:
            f.write(data)
            f.flush()
            os.fsync(f.fileno())
        os.replace(tmp, target)
    finally:
        if os.path.exists(tmp):
            os.unlink(tmp)


def user_systemctl(*args: str) -> subprocess.CompletedProcess:
    return subprocess.run(["/usr/bin/systemctl", "--user", *args], capture_output=True,
                          text=True, timeout=12, check=False)


def unload_local_model() -> None:
    # Local Ollama CLI unloads GPU memory; it does not stop or require sudo
    # for the system Ollama daemon. The daemon itself stays running.
    path = "/usr/bin/ollama"
    if not Path(path).is_file():
        return
    try:
        subprocess.run([path, "stop", MODEL], stdout=subprocess.DEVNULL,
                       stderr=subprocess.DEVNULL, timeout=8, check=False)
    except (OSError, subprocess.TimeoutExpired):
        pass


def cycle() -> int:
    result = {"schema": "devnet-private-qa-summary-v1", "utc": utcnow(),
              "gaming": False, "qa": "NOT_RUN", "runner": "NOT_TESTED",
              "framework": "NOT_TESTED", "evidence_gate": "NOT_TESTED",
              "application_suite": "NOT_TESTED",
              "app_approvals": 0, "decisions": "RELEASES_BLOCKED"}
    if gaming_now():
        result["gaming"], result["qa"] = True, "PAUSED_GAME"
        report_write(result)
        print("PAUSED_GAME: QA not executed; GPU model unload requested by game guard")
        return 0
    # Must check before each network task: gaming takes precedence even mid-cycle.
    try:
        rc, output = ssh_query("status")
        result["runner"] = "PASS" if status_result(rc, output) else "FAIL"
        if result["runner"] != "PASS":
            result["qa"] = "BLOCKED_SECURITY"
            return 2
        if gaming_now():
            result["gaming"], result["qa"] = True, "PAUSED_GAME"
            return 0
        rc, output = ssh_query("self-test")
        result["framework"] = "PASS" if self_test_result(rc, output) else "FAIL"
        if result["framework"] != "PASS":
            result["qa"] = "BLOCKED_TEST"
            return 2
        if gaming_now():
            result["gaming"], result["qa"] = True, "PAUSED_GAME"
            return 0
        rc, output = ssh_query("evaluate")
        result["evidence_gate"] = "PASS_BLOCKED" if evaluate_result(rc, output) else "FAIL"
        result["qa"] = "SAFE_GATE_CHECKS_PASSED" if result["evidence_gate"] == "PASS_BLOCKED" else "BLOCKED_GATE"
        if result["evidence_gate"] != "PASS_BLOCKED":
            return 2
        if gaming_now():
            result["gaming"], result["qa"] = True, "PAUSED_GAME"
            return 0
        try:
            # Controller uses only the existing forced-command app key and a
            # local loopback LLM. Do not spawn arbitrary shell commands.
            controller = Path(__file__).with_name("controller.py")
            if controller.is_symlink() or not controller.is_file():
                raise RuntimeError("controller unavailable")
            cp = subprocess.run(["/usr/bin/python3", str(controller), "once"],
                                capture_output=True, text=True, timeout=360,
                                check=False)
            status = cp.stdout.strip()
            if cp.returncode in (0, 2) and status in (
                    "PASS_LIMITED", "PARTIAL", "BLOCKED", "BLOCKED_UNAVAILABLE", "PAUSED_GAME"):
                result["application_suite"] = status
            else:
                result["application_suite"] = "BLOCKED_UNAVAILABLE"
        except (OSError, RuntimeError, subprocess.TimeoutExpired):
            result["application_suite"] = "BLOCKED_UNAVAILABLE"
        # This suite is NOT a full hardware/UI acceptance or a release approval.
        return 0 if result["application_suite"] in ("PASS_LIMITED", "PARTIAL") else 2
    except (OSError, RuntimeError, subprocess.TimeoutExpired, ValueError):
        result["qa"] = "BLOCKED_UNAVAILABLE"
        return 2
    finally:
        report_write(result)
        print("QA:", result["qa"], "| RUNNER:", result["runner"], "| SELF_TEST:",
              result["framework"], "| EVIDENCE_GATE:", result["evidence_gate"],
              "| APPLICATION_SUITE:", result["application_suite"],
              "| APPLICATION_APPROVALS: 0")


def guard_loop() -> None:
    safe_dirs()
    was_gaming = None
    paused_marker = STATE_ROOT / "memory-paused-by-guard"
    paused_memory = paused_marker.is_file()
    while True:
        active = gaming_now()
        if active and was_gaming is not True:
            # Stop our own scheduler and any in-progress remote QA operation.
            user_systemctl("stop", USER_QA_TIMER)
            user_systemctl("stop", USER_QA_SERVICE)
            # Pause memory sync only if it was active, so we don't enable
            # previously disabled services when gaming ends.
            state = user_systemctl("is-active", MEMORY_TIMER)
            user_systemctl("stop", MEMORY_SERVICE)  # no sync writes while gaming
            if state.returncode == 0 and state.stdout.strip() == "active":
                paused_memory = user_systemctl("stop", MEMORY_TIMER).returncode == 0
                if paused_memory:
                    paused_marker.touch(mode=0o600)
            unload_local_model()
            print("GAME_ON: automation paused, local Qwen model unload requested", flush=True)
        elif not active and (was_gaming is True or paused_marker.exists()):
            if not STOP_FILE.exists():
                user_systemctl("start", USER_QA_TIMER)
                if paused_memory:
                    user_systemctl("start", MEMORY_TIMER)
            paused_memory = False
            paused_marker.unlink(missing_ok=True)
            print("GAME_OFF: allowed QA automation resumed; no application approvals", flush=True)
        elif active:
            # If a user manually starts Ollama during a game, unload on each check.
            unload_local_model()
        was_gaming = active
        time.sleep(GUARD_INTERVAL)


def main() -> int:
    os.umask(0o077)
    parser = argparse.ArgumentParser(description="Strictly local Devnet QA game-aware worker")
    parser.add_argument("mode", choices=("once", "guard", "status", "pause", "resume"))
    args = parser.parse_args()
    if args.mode == "once":
        return cycle()
    if args.mode == "guard":
        guard_loop()
        return 0
    if args.mode == "status":
        print("GAME_PAUSE" if gaming_now() else "IDLE_READY")
        p = STATE_ROOT / "latest.json"
        if p.is_file():
            obj = json.loads(p.read_text())
            print("LAST_QA:", obj.get("qa", "NOT_TESTED"))
        return 0
    safe_dirs()
    if args.mode == "pause":
        MANUAL_PAUSE.touch(mode=0o600, exist_ok=True)
        print("GAME_PAUSE enabled")
    else:
        MANUAL_PAUSE.unlink(missing_ok=True)
        print("Manual game pause cleared (automatic detection remains active)")
    return 0


if __name__ == "__main__":
    sys.exit(main())
