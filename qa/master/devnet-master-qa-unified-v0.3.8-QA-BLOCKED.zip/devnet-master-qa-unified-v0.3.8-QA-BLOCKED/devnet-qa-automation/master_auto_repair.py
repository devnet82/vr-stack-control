"""Devnet Master QA v0.3.6: durable, fail-closed, host-driven VM repair coordination.

This is a component of the ONE Master QA controller, not a service or release gate.
Remote VM tests are diagnostic/preliminary. Any modified candidate MUST go back
through GitHub first, then independently attested VM and host stages.
"""
from __future__ import annotations
import fcntl
import hashlib
import json
import os
from pathlib import Path
import re

SCHEMA = 'devnet-master-auto-repair-job-v1'
STATE = 'devnet-master-auto-repair-state-v1'
ALLOWED_STATES = frozenset(('READY', 'INITIAL_FAILED', 'AI_PROPOSED', 'RETEST_FAILED',
                            'AWAITING_GITHUB_RETEST', 'BLOCKED', 'PAUSED'))


def _persist(master, file, data):
    master._master_atomic_json(file, data)


def _safe_workspace(path):
    path=Path(path)
    if path.is_symlink() or (path.exists() and (not path.is_dir() or path.stat().st_mode & 0o077)):
        raise ValueError('UNSAFE_STATE_WORKSPACE')
    path.mkdir(mode=0o700, parents=True, exist_ok=True)
    if path.stat().st_mode & 0o077:
        raise ValueError('UNSAFE_STATE_WORKSPACE')
    return path


def validate_repair_job(master, job, plan, source_root):
    """Require an explicit operator-controlled bounded VM diagnostic job."""
    if (not isinstance(job,dict) or set(job)!={'schema','job_id','revision_sha256','allowed_files','max_attempts','authorised_vm_diagnostic'}
            or job['schema']!=SCHEMA or not isinstance(job['job_id'],str)
            or not re.fullmatch(r'[A-Za-z0-9_.-]{1,80}',job['job_id'])
            or job['authorised_vm_diagnostic'] is not True
            or type(job['max_attempts']) is not int or not 1<=job['max_attempts']<=3):
        raise ValueError('INVALID_AUTOREPAIR_JOB')
    allow=master._master_repair_allowlist(job['allowed_files'])
    source_root=Path(source_root)
    if source_root.is_symlink() or not source_root.is_dir():
        raise ValueError('UNSAFE_SOURCE_ROOT')
    digest=master.master_source_tree_digest(source_root)
    if digest != job['revision_sha256'] or not isinstance(plan,dict) or plan.get('revision_sha256')!=digest:
        raise ValueError('SOURCE_REVISION_MISMATCH')
    tests=plan.get('tests')
    if (plan.get('schema')!='devnet-test-plan-v1' or not isinstance(tests,list) or not tests
            or any(not isinstance(t,dict) or set(t)!={'name','stage','kind','target','timeout'} or t['stage']!='vm' for t in tests)
            or len(set(t['name'] for t in tests))!=len(tests)):
        raise ValueError('VM_PLAN_REQUIRED')
    targets={t['target'] for t in tests}
    if set(allow)&targets:
        raise ValueError('TEST_FILE_ON_REPAIR_ALLOWLIST')
    for t in tests:
        if (t['kind'] not in master.MASTER_EXEC_ALLOWED or not isinstance(t['target'],str)
                or t['target'].startswith('/') or '..' in Path(t['target']).parts
                or not t['target'].endswith('.py') or not (source_root/t['target']).is_file()
                or (source_root/t['target']).is_symlink()):
            raise ValueError('UNSAFE_TEST_PLAN')
    return digest,allow


def _state_default(job):
    return {'schema':STATE,'job_id':job['job_id'],'revision_sha256':job['revision_sha256'],
            'attempts':0,'phase':'READY','history':[],
            'release_approved':False,'user_acceptance_ready':False}


def _checked_state(state,job):
    if (not isinstance(state,dict) or set(state)!={'schema','job_id','revision_sha256','attempts','phase','history','release_approved','user_acceptance_ready'}
            or state['schema']!=STATE or state['job_id']!=job['job_id']
            or state['release_approved'] is not False or state['user_acceptance_ready'] is not False
            or state['phase'] not in ALLOWED_STATES or type(state['attempts']) is not int
            or state['attempts']<0 or state['attempts']>job['max_attempts']
            or not isinstance(state['history'],list) or len(state['history'])>3):
        raise ValueError('INVALID_OR_TAMPERED_CHECKPOINT')
    if state['revision_sha256'] != job['revision_sha256']:
        raise ValueError('REVISION_CHANGED_FRESH_GITHUB_REQUIRED')


def master_vm_auto_repair_cycle(master, job, plan, source_root, workspace, transport,
                                *, proposer=None, gaming=None):
    """Execute one bounded VM diagnostic AI repair attempt; persist checkpoint.

    transport.initial(source, plan, attempt_dir) -> (record, logs_dir)
    transport.retest(source, plan, proposal, allowlist, attempt_dir) -> (result, logs_dir)
    The transport MUST execute inside the QA VM. A local fake is valid for unit
    testing ONLY; no transport can certify release approval.
    """
    if os.environ.get('GITHUB_ACTIONS')=='true':
        raise ValueError('LOCAL_AI_AND_VM_BRIDGE_HOST_ONLY')
    digest,allow=validate_repair_job(master,job,plan,source_root)
    work=_safe_workspace(workspace)
    source_root=Path(source_root)
    # State/outputs must be strictly separate from candidate source tree.
    if work.resolve().is_relative_to(source_root.resolve()) or source_root.resolve().is_relative_to(work.resolve()):
        raise ValueError('STATE_MUST_BE_SEPARATE')
    if not callable(getattr(transport,'initial',None)) or not callable(getattr(transport,'retest',None)):
        raise ValueError('VM_EXECUTOR_REQUIRED')
    statefile=work/'checkpoint.json'
    with (work/'cycle.lock').open('a+b') as lock:
        os.fchmod(lock.fileno(),0o600)
        fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
        if statefile.is_symlink():raise ValueError('UNSAFE_CHECKPOINT_SYMLINK')
        state=json.loads(statefile.read_text()) if statefile.is_file() else _state_default(job)
        _checked_state(state,job)
        if state['phase'] in ('AWAITING_GITHUB_RETEST','BLOCKED'):
            return {'decision':state['phase'],'reason':'NO_UNTRUSTED_AUTORESTART','attempts':state['attempts'],
                    'release_approved':False}
        if state['attempts']>=job['max_attempts']:
            state['phase']='BLOCKED';_persist(master,statefile,state)
            return {'decision':'BLOCKED','reason':'REPAIR_ATTEMPTS_EXHAUSTED','attempts':state['attempts'],'release_approved':False}
        game=gaming or master.game_active
        if game():
            state['phase']='PAUSED';_persist(master,statefile,state)
            return {'decision':'PAUSED','reason':'GAMING_GPU_PROTECTION','attempts':state['attempts'],'release_approved':False}
        # Reserve attempt BEFORE VM execution. A crash cannot silently repeat an
        # unlimited number of potentially expensive attempts.
        state['attempts']+=1
        n=state['attempts']
        state['phase']='READY'
        _persist(master,statefile,state)
        folder=work/('attempt-%d'%n)
        folder.mkdir(mode=0o700,exist_ok=False)
        report={'attempt':n,'stage':'vm','release_approved':False}
        try:
            record,logs=transport.initial(source_root,plan,folder)
            if game():
                state['phase']='PAUSED'; _persist(master,statefile,state)
                return {'decision':'PAUSED','reason':'GAMING_GPU_PROTECTION','attempts':n,'release_approved':False}
            results=record.get('results') if isinstance(record,dict) else None
            names={t['name'] for t in plan['tests']}
            if (not isinstance(results,dict) or set(results)!=names
                    or record.get('revision_sha256')!=digest
                    or record.get('decision') not in ('FAILED_REPAIR_REQUIRED','PRELIMINARY_PASS_UNTRUSTED')
                    or not master.master_verify_stage_logs(record,logs)
                    or any(x.get('stage')!='vm' or x.get('test_revision_sha256')!=digest for x in results.values())
                    or master.master_source_tree_digest(source_root)!=digest):
                raise ValueError('VM_INITIAL_EVIDENCE_INVALID')
            report['initial']={k:v['status'] for k,v in results.items()}
            if all(v=='PASS' for v in report['initial'].values()):
                # Even a real VM pass cannot replace independent GitHub-first
                # verification or separate trusted executor provenance.
                state['phase']='AWAITING_GITHUB_RETEST'
                report['outcome']='ALREADY_PASSES_PRELIMINARY_ONLY'
            else:
                if record.get('decision')!='FAILED_REPAIR_REQUIRED':
                    raise ValueError('VM_FAILURE_DECISION_MISMATCH')
                state['phase']='INITIAL_FAILED';_persist(master,statefile,state)
                propose=proposer or master.master_propose_local_ai_patch
                q=propose(record,logs,folder/'proposal.json',allow,source_root=source_root,gaming=game())
                if not isinstance(q,dict) or q.get('decision')!='PROPOSAL_ONLY':
                    reason=q.get('diagnostic_code',q.get('reason','INVALID')) if isinstance(q,dict) else 'INVALID'
                    report['outcome']='WEB_RESEARCH_BLOCKED' if str(reason).startswith('WEB_RESEARCH_') else 'AI_PROPOSAL_BLOCKED'
                    report['diagnostic']=reason
                    state['phase']=('BLOCKED' if str(reason).startswith('WEB_RESEARCH_') or n>=job['max_attempts'] else 'RETEST_FAILED')
                else:
                    master._master_validate_repair_patch(q['patch'],allow)
                    if q.get('research_evidence_sha256'):
                        report['web_research']={'status':'RESEARCH_COMPLETE_UNTRUSTED',
                          'evidence_sha256':q['research_evidence_sha256'],
                          'evidence_path':str(folder/'web-research.json')}
                    if (q.get('job_id')!=record.get('job_id') or q.get('revision_sha256')!=digest
                            or q.get('allowed_files')!=allow or q.get('release_approved') is not False):
                        raise ValueError('AI_PROPOSAL_MISMATCH')
                    state['phase']='AI_PROPOSED';_persist(master,statefile,state)
                    if game():
                        state['phase']='PAUSED';_persist(master,statefile,state)
                        return {'decision':'PAUSED','reason':'GAMING_GPU_PROTECTION','attempts':n,'release_approved':False}
                    result,retest_logs=transport.retest(source_root,plan,q,allow,folder)
                    if (not isinstance(result,dict) or result.get('release_approved') is not False
                            or result.get('source_unchanged') is not True
                            or result.get('logs_verified') is not True
                            or not master.master_verify_stage_logs(result,retest_logs)
                            or result.get('candidate_sha256')==digest
                            or not re.fullmatch('[a-f0-9]{64}',str(result.get('candidate_sha256','')))
                            or master.master_source_tree_digest(source_root)!=digest):
                        raise ValueError('VM_RETEST_EVIDENCE_INVALID')
                    retest=result.get('results')
                    if not isinstance(retest,dict) or set(retest)!=names:
                        raise ValueError('INCOMPLETE_VM_RETEST')
                    if any(e.get('stage')!='vm' or e.get('test_revision_sha256')!=result['candidate_sha256'] for e in retest.values()):
                        raise ValueError('VM_RETEST_REVISION_MISMATCH')
                    report['candidate_sha256']=result['candidate_sha256']
                    report['retest']={k:v['status'] for k,v in retest.items()}
                    if all(x=='PASS' for x in report['retest'].values()) and result.get('decision')=='PRELIMINARY_PASS_UNTRUSTED':
                        state['phase']='AWAITING_GITHUB_RETEST'
                        report['outcome']='VM_DIAGNOSTIC_PASS_GITHUB_RETEST_REQUIRED'
                    else:
                        state['phase']='BLOCKED' if n>=job['max_attempts'] else 'RETEST_FAILED'
                        report['outcome']='REPAIR_DID_NOT_PASS'
            state['history'].append(report)
        except Exception as exc:
            # Preserve failure evidence, but never accept partial success.
            report['outcome']='BLOCKED_EXCEPTION';report['error_type']=type(exc).__name__
            state['phase']='BLOCKED'
            state['history'].append(report)
        finally:
            state['release_approved']=False
            state['user_acceptance_ready']=False
            _persist(master,statefile,state)
        return {'decision':state['phase'],'attempts':n,'report':report,
                'trusted_evidence':False,'release_approved':False,'user_acceptance_ready':False}
