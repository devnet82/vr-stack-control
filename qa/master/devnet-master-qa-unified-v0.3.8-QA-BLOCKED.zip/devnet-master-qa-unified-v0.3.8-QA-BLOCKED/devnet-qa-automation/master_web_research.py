"""Devnet Master QA v0.3.7: bounded online upstream research before AI repairs.

Only operator-approved, public repository search terms leave this host.
No logs, source text, file paths, tokens, identities or model output are sent.
Search results are UNTRUSTED advisory context and never authorise a fix.
"""
from __future__ import annotations
import datetime as dt
import hashlib
import json
import os
from pathlib import Path
import re
import urllib.parse
import urllib.request

CONFIG_SCHEMA='devnet-master-web-research-config-v1'
RECORD_SCHEMA='devnet-master-web-research-v1'
REPO=re.compile(r'[A-Za-z0-9][A-Za-z0-9_.-]{0,49}/[A-Za-z0-9][A-Za-z0-9_.-]{0,99}\Z')
TEXT=re.compile(r'[A-Za-z0-9][A-Za-z0-9 _+.:#-]{1,95}\Z')
HASH=re.compile(r'[0-9a-f]{64}\Z')

class _NoRedirect(urllib.request.HTTPRedirectHandler):
    def redirect_request(self,req,fp,code,msg,headers,newurl):
        return None

# Explicitly drop environment HTTP(S) proxies so an unexpected proxy cannot
# redirect this diagnostic request to arbitrary hosts or carry secrets.
_DIRECT_OPENER=urllib.request.build_opener(urllib.request.ProxyHandler({}),_NoRedirect())


def _hash(data):
    return hashlib.sha256(data).hexdigest()


def _json_hash(data):
    return _hash(json.dumps(data,sort_keys=True,separators=(',',':'),ensure_ascii=True).encode())


def validate_config(config,job):
    if (not isinstance(config,dict) or set(config)!={'schema','job_id','revision_sha256','topics'}
        or config['schema']!=CONFIG_SCHEMA or config['job_id']!=job.get('job_id')
        or config['revision_sha256']!=job.get('revision_sha256')
        or not isinstance(config['topics'],list) or not 1<=len(config['topics'])<=2):
        raise ValueError('WEB_RESEARCH_CONFIGURATION_REQUIRED')
    if not HASH.fullmatch(str(config['revision_sha256'])):
        raise ValueError('WEB_RESEARCH_BAD_REVISION')
    seen=set();total=0
    for topic in config['topics']:
        if not isinstance(topic,dict) or set(topic)!={'product','version','repository','queries'}:
            raise ValueError('WEB_RESEARCH_BAD_TOPIC')
        if (not isinstance(topic['product'],str) or not TEXT.fullmatch(topic['product'])
            or not isinstance(topic['version'],str) or not re.fullmatch(r'[A-Za-z0-9][A-Za-z0-9.+_:-]{0,49}',topic['version'])
            or not isinstance(topic['repository'],str) or not REPO.fullmatch(topic['repository'])
            or not isinstance(topic['queries'],list) or not 1<=len(topic['queries'])<=2):
            raise ValueError('WEB_RESEARCH_BAD_TOPIC')
        if topic['repository'] in seen:raise ValueError('WEB_RESEARCH_DUPLICATE_REPOSITORY')
        seen.add(topic['repository'])
        for q in topic['queries']:
            if not isinstance(q,str) or not TEXT.fullmatch(q) or '  ' in q or q.lower().startswith('repo:'):
                raise ValueError('WEB_RESEARCH_UNSAFE_QUERY')
        if len(set(topic['queries']))!=len(topic['queries']):raise ValueError('WEB_RESEARCH_DUPLICATE_QUERY')
        total+=len(topic['queries'])
    # Two public searches, each scoped to issues AND pull requests: <=4 API calls.
    if total>2:raise ValueError('WEB_RESEARCH_TOO_MANY_QUERIES')
    return True


def _safe_result(item,repo):
    if not isinstance(item,dict):raise ValueError('WEB_RESEARCH_BAD_RESULT')
    url=item.get('html_url','');parsed=urllib.parse.urlsplit(url) if isinstance(url,str) else None
    if (parsed is None or parsed.scheme!='https' or parsed.hostname!='github.com' or parsed.username
        or parsed.password or parsed.port or parsed.query or parsed.fragment
        or not re.fullmatch('/'+re.escape(repo)+r'/(issues|pull)/[1-9][0-9]*',parsed.path)):
        raise ValueError('WEB_RESEARCH_WRONG_REPOSITORY')
    title=item.get('title');updated=item.get('updated_at');created=item.get('created_at')
    if (not isinstance(title,str) or not 1<=len(title)<=250
        or not isinstance(updated,str) or not re.fullmatch(r'\d{4}-\d\d-\d\dT\d\d:\d\d:\d\dZ',updated)
        or not isinstance(created,str) or not re.fullmatch(r'\d{4}-\d\d-\d\dT\d\d:\d\d:\d\dZ',created)
        or item.get('state') not in ('open','closed')):
        raise ValueError('WEB_RESEARCH_BAD_RESULT')
    # Never store comments/body. Titles are untrusted and bounded.
    return {'url':url,'title':title,'updated_at':updated,'created_at':created,
            'state':item['state'],'type':'pull_request' if 'pull_request' in item else 'issue'}


def verify(record,job,config,stage_record):
    try:
        validate_config(config,job)
        if (not isinstance(record,dict) or set(record)!={'schema','decision','job_id','revision_sha256',
                'failed_log_hashes','configuration_sha256','retrieved_at','products','sources',
                'evidence_sha256','release_approved','trusted_evidence'}
            or record['schema']!=RECORD_SCHEMA or record['decision']!='RESEARCH_COMPLETE_UNTRUSTED'
            or record['job_id']!=job['job_id'] or record['revision_sha256']!=job['revision_sha256']
            or record['release_approved'] is not False or record['trusted_evidence'] is not False
            or record['configuration_sha256']!=_json_hash(config)
            or record['products']!=[{'product':t['product'],'version':t['version'],'repository':t['repository']} for t in config['topics']]
            or not HASH.fullmatch(str(record['evidence_sha256']))
            or _json_hash({k:v for k,v in record.items() if k!='evidence_sha256'})!=record['evidence_sha256']
            or not isinstance(stage_record,dict) or stage_record.get('revision_sha256')!=job['revision_sha256']):
            return False
        failures={k:v['log_sha256'] for k,v in stage_record.get('results',{}).items() if v.get('status')=='FAIL'}
        if not failures or record['failed_log_hashes']!=failures:return False
        if not isinstance(record['sources'],list) or not record['sources'] or len(record['sources'])>4:return False
        permitted={(t['repository'],q,kind) for t in config['topics'] for q in t['queries'] for kind in ('issue','pull-request')}
        observed=set();found=0
        for source in record['sources']:
            if (not isinstance(source,dict) or set(source)!={'repository','query','kind','url','response_sha256','hits'}
                or (source['repository'],source['query'],source['kind']) not in permitted
                or (source['repository'],source['query'],source['kind']) in observed
                or not HASH.fullmatch(str(source['response_sha256']))
                or not isinstance(source['hits'],list) or len(source['hits'])>4):return False
            observed.add((source['repository'],source['query'],source['kind']))
            expected=_search_url(source['repository'],source['query'],source['kind'])
            if source['url']!=expected:return False
            for hit in source['hits']:
                if hit.get('type')!=('pull_request' if source['kind']=='pull-request' else 'issue'):
                    return False
                if _safe_result({'html_url':hit.get('url'),'title':hit.get('title'),
                    'updated_at':hit.get('updated_at'),'created_at':hit.get('created_at'),
                    'state':hit.get('state'), **({'pull_request':{}} if hit.get('type')=='pull_request' else {})}, source['repository'])!=hit:
                    return False
                found+=1
        return observed==permitted and found>0
    except (KeyError,TypeError,ValueError,AttributeError):return False


def _search_url(repo,query,kind):
    if kind not in ('issue','pull-request'):
        raise ValueError('WEB_RESEARCH_UNAPPROVED_SEARCH_KIND')
    q=query+' repo:'+repo+' is:'+kind
    return 'https://api.github.com/search/issues?'+urllib.parse.urlencode({'q':q,'sort':'updated','order':'desc','per_page':'4'})


def run(master,config,job,stage_record,logs,out_file,*,opener=None,gaming=None):
    """Search actual upstream GitHub issues/PRs; record links and digests.

    This step executes on the host after VM failure and before asking Ollama
    to draft any repair. GitHub CI, unavailable internet and no sources block.
    """
    try: validate_config(config,job)
    except (ValueError,KeyError,TypeError):
        return {'decision':'BLOCKED','reason':'WEB_RESEARCH_CONFIGURATION_REQUIRED','release_approved':False}
    if os.environ.get('GITHUB_ACTIONS')=='true':
        return {'decision':'BLOCKED','reason':'WEB_RESEARCH_HOST_ONLY','release_approved':False}
    game=gaming or master.game_active
    if game():return {'decision':'PAUSED','reason':'GAMING_GPU_PROTECTION','release_approved':False}
    if (not isinstance(stage_record,dict) or stage_record.get('decision')!='FAILED_REPAIR_REQUIRED'
        or stage_record.get('revision_sha256')!=job['revision_sha256']
        or not master.master_verify_stage_logs(stage_record,logs)):
        return {'decision':'BLOCKED','reason':'WEB_RESEARCH_FAILURE_EVIDENCE_REQUIRED','release_approved':False}
    failures={k:v['log_sha256'] for k,v in stage_record['results'].items() if v['status']=='FAIL'}
    if not failures or any(not HASH.fullmatch(str(v)) for v in failures.values()):
        return {'decision':'BLOCKED','reason':'WEB_RESEARCH_FAILURE_EVIDENCE_REQUIRED','release_approved':False}
    target=Path(out_file)
    if target.is_symlink() or (target.exists() and not target.is_file()):
        return {'decision':'BLOCKED','reason':'WEB_RESEARCH_OUTPUT_UNSAFE','release_approved':False}
    sources=[];hits=0
    try:
        for topic in config['topics']:
            for query in topic['queries']:
                for kind in ('issue','pull-request'):
                    if game():return {'decision':'PAUSED','reason':'GAMING_GPU_PROTECTION','release_approved':False}
                    url=_search_url(topic['repository'],query,kind)
                    req=urllib.request.Request(url,headers={'Accept':'application/vnd.github+json',
                        'User-Agent':'Devnet-Master-QA-Research/0.3.7','X-GitHub-Api-Version':'2022-11-28'},method='GET')
                    with (opener or _DIRECT_OPENER.open)(req,timeout=15) as response:
                        if response.status!=200 or response.geturl()!=url:
                            raise ValueError('WEB_RESEARCH_UNEXPECTED_RESPONSE')
                        data=response.read(131073)
                    if len(data)>131072:raise ValueError('WEB_RESEARCH_RESPONSE_OVERSIZE')
                    doc=json.loads(data)
                    if (not isinstance(doc,dict) or set(doc)<{'total_count','incomplete_results','items'}
                        or doc['incomplete_results'] is not False or type(doc['total_count']) is not int
                        or not isinstance(doc['items'],list) or len(doc['items'])>4):
                        raise ValueError('WEB_RESEARCH_RESPONSE_INVALID')
                    found=[_safe_result(x,topic['repository']) for x in doc['items']]
                    if any(h['type']!=('pull_request' if kind=='pull-request' else 'issue') for h in found):
                        raise ValueError('WEB_RESEARCH_RESULT_TYPE_MISMATCH')
                    sources.append({'repository':topic['repository'],'query':query,'kind':kind,'url':url,
                                   'response_sha256':_hash(data),'hits':found})
                    hits+=len(found)
        if game():return {'decision':'PAUSED','reason':'GAMING_GPU_PROTECTION','release_approved':False}
        if not hits:
            return {'decision':'BLOCKED','reason':'WEB_RESEARCH_INCONCLUSIVE','release_approved':False}
        record={'schema':RECORD_SCHEMA,'decision':'RESEARCH_COMPLETE_UNTRUSTED',
            'job_id':job['job_id'],'revision_sha256':job['revision_sha256'],
            'failed_log_hashes':failures,'configuration_sha256':_json_hash(config),
            'retrieved_at':dt.datetime.now(dt.timezone.utc).isoformat(timespec='seconds'),
            'products':[{'product':t['product'],'version':t['version'],'repository':t['repository']} for t in config['topics']],
            'sources':sources,'release_approved':False,'trusted_evidence':False}
        record['evidence_sha256']=_json_hash(record)
        if not verify(record,job,config,stage_record):
            raise ValueError('WEB_RESEARCH_VERIFICATION_FAILED')
        master._master_atomic_json(target,record)
        if target.is_symlink() or json.loads(target.read_text())!=record:
            raise ValueError('WEB_RESEARCH_PERSISTENCE_MISMATCH')
        return record
    except (OSError,TimeoutError,ValueError,TypeError,KeyError,UnicodeError,OverflowError) as exc:
        # Never log raw remote/API content or response header secrets.
        return {'decision':'BLOCKED','reason':'WEB_RESEARCH_BLOCKED',
                'error_type':type(exc).__name__,'release_approved':False}
