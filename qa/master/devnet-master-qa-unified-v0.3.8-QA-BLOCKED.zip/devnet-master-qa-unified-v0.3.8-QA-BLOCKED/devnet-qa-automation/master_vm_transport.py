"""Fixed-target SSH/SCP transport for disposable QA-VM diagnostics.

The transport does not attest host identity or sign release evidence; all
outcomes are preliminary and must pass GitHub-first independent gates.
"""
from __future__ import annotations
import json
import os
from pathlib import Path
import re
import subprocess
import tempfile
import zipfile

VM='devnet@192.168.122.71'
SSH_OPTS=['-o','BatchMode=yes','-o','ForwardAgent=no','-o','ClearAllForwardings=yes',
          '-o','ConnectTimeout=8','-o','StrictHostKeyChecking=yes']


def _call(argv,timeout=120):
    p=subprocess.run(argv,stdin=subprocess.DEVNULL,stdout=subprocess.PIPE,stderr=subprocess.PIPE,timeout=timeout)
    if p.returncode:
        raise RuntimeError('VM_TRANSPORT_FAILED_'+str(p.returncode))
    if len(p.stdout)>65536:
        raise RuntimeError('VM_REPLY_TOO_LARGE')
    return p.stdout.decode('utf-8')


class FixedVmTransport:
    def __init__(self,master,job,controller_dir):
        self.master=master
        self.job=job
        self.dir=Path(controller_dir).resolve()
        self.remote=None

    def _ssh(self,*args):
        return _call(['ssh',*SSH_OPTS,'-T',VM,*args],timeout=180)

    def _scp(self,*args):
        return _call(['scp','-q',*SSH_OPTS,*args],timeout=90)

    def initial(self,source,plan,folder):
        source=Path(source)
        if self.master.master_source_tree_digest(source)!=plan['revision_sha256']:
            raise ValueError('SOURCE_CHANGED_BEFORE_VM_TRANSFER')
        # Whitelist file types and cap volume; do not transfer credentials.
        entries=sorted(p for p in source.rglob('*') if p.is_file())
        if not entries or len(entries)>128 or sum(p.stat().st_size for p in entries)>4*1024*1024:
            raise ValueError('SOURCE_VOLUME_LIMIT')
        for p in entries:
            rel=p.relative_to(source)
            if (p.is_symlink() or any(part.startswith('.') or part=='..' for part in rel.parts)
                    or p.suffix not in ('.py','.json','.txt') or p.stat().st_size>256*1024):
                raise ValueError('SOURCE_CONTAINS_UNSAFE_FILE')
        self.remote=self._ssh('mktemp','-d','/tmp/devnet-master-cycle-XXXXXXXX').strip()
        if not re.fullmatch(r'/tmp/devnet-master-cycle-[A-Za-z0-9]{8,12}',self.remote):
            raise RuntimeError('UNEXPECTED_VM_TEMP_PATH')
        self._ssh('mkdir','-p',self.remote+'/module/devnet-qa-automation')
        local=Path(folder)
        with zipfile.ZipFile(local/'source.zip','w',zipfile.ZIP_DEFLATED) as z:
            for p in entries:z.write(p,p.relative_to(source).as_posix())
        (local/'plan.json').write_text(json.dumps(plan,sort_keys=True))
        (local/'job.json').write_text(json.dumps(self.job,sort_keys=True))
        if self.master.master_source_tree_digest(source)!=plan['revision_sha256']:
            raise ValueError('SOURCE_CHANGED_DURING_TRANSFER')
        self._scp(str(local/'source.zip'),str(local/'plan.json'),str(local/'job.json'),VM+':'+self.remote+'/')
        for name in ('controller.py','agent.py','master_vm_worker.py'):
            self._scp(str(self.dir/name),VM+':'+self.remote+'/module/devnet-qa-automation/')
        self._scp(str(self.dir.parent/'devnet-qa-verified.py'),VM+':'+self.remote+'/module/')
        self._ssh('python3',self.remote+'/module/devnet-qa-automation/master_vm_worker.py','initial',self.remote)
        self._scp(VM+':'+self.remote+'/record.json',str(local/'record.json'))
        self._scp('-r',VM+':'+self.remote+'/logs',str(local/'logs'))
        return json.loads((local/'record.json').read_text()),local/'logs'

    def retest(self,source,plan,proposal,allowed_files,folder):
        if self.remote is None:raise ValueError('VM_INITIAL_REQUIRED')
        if self.master.master_source_tree_digest(source)!=plan['revision_sha256']:
            raise ValueError('SOURCE_CHANGED_BEFORE_RETEST')
        local=Path(folder)
        # The proposal is bound by exact source/revision and independently
        # revalidated by the VM worker against the installed allowlist.
        self.master._master_atomic_json(local/'proposal.json',proposal)
        self._scp(str(local/'proposal.json'),VM+':'+self.remote+'/proposal.json')
        self._ssh('python3',self.remote+'/module/devnet-qa-automation/master_vm_worker.py','retest',self.remote)
        self._scp(VM+':'+self.remote+'/retest.json',str(local/'retest.json'))
        self._scp('-r',VM+':'+self.remote+'/retest_logs',str(local/'retest_logs'))
        # Export only a NONEXECUTED staging copy for GitHub-first review.
        # Never replace the operator's original source or installed software.
        self._scp('-r',VM+':'+self.remote+'/staged',str(local/'staged_candidate'))
        result=json.loads((local/'retest.json').read_text())
        exported=local/'staged_candidate'
        if self.master.master_source_tree_digest(exported)!=result.get('candidate_sha256'):
            raise ValueError('VM_EXPORTED_CANDIDATE_HASH_MISMATCH')
        source_paths={p.relative_to(source).as_posix() for p in Path(source).rglob('*') if p.is_file()}
        staged_paths={p.relative_to(exported).as_posix() for p in exported.rglob('*') if p.is_file()}
        if source_paths!=staged_paths:
            raise ValueError('VM_EXPORTED_CANDIDATE_FILES_CHANGED')
        changed={n for n in source_paths if (Path(source)/n).read_bytes()!=(exported/n).read_bytes()}
        if changed != {proposal['patch']['path']} or not changed.issubset(set(allowed_files)):
            raise ValueError('VM_EXPORTED_CANDIDATE_UNAUTHORISED_DIFF')
        if self.master.master_source_tree_digest(source)!=plan['revision_sha256']:
            raise ValueError('ORIGINAL_CHANGED_DURING_VM_REPAIR')
        return result,local/'retest_logs'
