
import ast,hashlib,json,os,tempfile,unittest
from pathlib import Path
from unittest.mock import patch
SOURCE=Path(__file__).parent/'devnet-qa-automation/controller.py'
import importlib.util
sp=importlib.util.spec_from_file_location('devnet_v029_controller', SOURCE)
mod=importlib.util.module_from_spec(sp); sp.loader.exec_module(mod)
REV='a'*64
class LiveStageTests(unittest.TestCase):
 def setUp(self):
  self.tmp=tempfile.TemporaryDirectory();self.addCleanup(self.tmp.cleanup)
  d=Path(self.tmp.name);self.root=d/'project';self.root.mkdir()
  (self.root/'sample.py').write_text('import unittest\nclass Test(unittest.TestCase):\n def test_ok(self): self.assertTrue(True)\n')
  self.logs=d/'logs';self.logs.mkdir(mode=0o700)
  self.checkpoint=d/'progress/stage.json'
  self.job={'schema':'devnet-master-job-v1','job_id':'live','revision_sha256':REV,
   'requirements':['unit'], 'stages':{'github':['unit'],'vm':[],'host':[]}}
  self.progress={'schema':mod.MASTER_STATE_SCHEMA,'job_id':'live','revision_sha256':REV,'status':'QUEUED'}
  self.plan={'schema':'devnet-test-plan-v1','revision_sha256':REV,
   'tests':[{'name':'unit','stage':'github','kind':'python-unittest','target':'sample.py','timeout':5}]}
 def call(self,stage='github',**kwargs):
  with patch.dict(os.environ,{'GITHUB_ACTIONS':'true'}):
   return mod.master_run_stage_cycle(self.job,self.progress,self.plan,stage,self.root,self.logs,self.checkpoint,**kwargs)
 def test_real_pass_and_checkpoint(self):
  r=self.call();self.assertEqual(r['decision'],'PRELIMINARY_PASS_UNTRUSTED');self.assertFalse(r['user_acceptance_ready']);self.assertEqual(json.loads(self.checkpoint.read_text()),r)
 def test_real_failure_and_checkpoint(self):
  (self.root/'sample.py').write_text('import unittest\nclass T(unittest.TestCase):\n def test_no(self): self.fail("REALFAIL")\n')
  r=self.call();self.assertEqual(r['decision'],'FAILED_REPAIR_REQUIRED');self.assertEqual(r['results']['unit']['status'],'FAIL')
 def test_repair_reruns_complete_stage(self):
  first=self.call();other=self.call();self.assertNotEqual(first['results']['unit']['execution_id'],other['results']['unit']['execution_id'])
 def test_failing_then_corrected_revision_requires_reset(self):
  self.call();self.job['revision_sha256']='b'*64;self.plan['revision_sha256']='b'*64
  with self.assertRaisesRegex(ValueError,'REVISION_MISMATCH'):self.call()
 def test_github_environment_required(self):
  with patch.dict(os.environ,{'GITHUB_ACTIONS':'false'}):
   with self.assertRaisesRegex(ValueError,'GITHUB_RUNNER_REQUIRED'):
    mod.master_run_stage_cycle(self.job,self.progress,self.plan,'github',self.root,self.logs,self.checkpoint)
 def test_vm_requires_trusted_prior_evidence(self):
  with self.assertRaisesRegex(ValueError,'TRUSTED_PRIOR_STAGE'):self.call(stage='vm')
 def test_missing_test_refused(self):
  self.plan['tests']=[]
  with self.assertRaisesRegex(ValueError,'PLAN_DOES_NOT_COVER'):self.call()
 def test_stage_mismatch_refused(self):
  self.plan['tests'][0]['stage']='vm'
  with self.assertRaisesRegex(ValueError,'PLAN_STAGE_MISMATCH'):self.call()
 def test_gaming_paused_before_execution(self):
  r=self.call(gaming=True);self.assertEqual(r['decision'],'PAUSED');self.assertFalse(self.checkpoint.exists())
 def test_no_claimed_approval(self):
  r=self.call();self.assertFalse(r['release_approved']);self.assertNotIn('signature',r)
 def test_corrupt_target_rejected(self):
  self.plan['tests'][0]['target']='../outside.py'
  with self.assertRaises(ValueError):self.call()
  self.assertFalse(self.checkpoint.exists())
 def test_controller_legacy_entrypoint_unchanged(self):
  p=SOURCE.read_text(); self.assertIn("['master-cycle']",p);self.assertIn("['master-status']",p)
if __name__=='__main__':unittest.main()
