"""Regression tests for source-bound Ollama repair proposals (mock transport)."""
import importlib.util,json,os,tempfile,unittest
from pathlib import Path
from unittest.mock import patch

ROOT=Path(__file__).resolve().parent
S=importlib.util.spec_from_file_location('devnet_ai_source_controller',ROOT/'devnet-qa-automation/controller.py')
m=importlib.util.module_from_spec(S);S.loader.exec_module(m)

class Response:
    def __init__(self,data):self.data=data
    def __enter__(self):return self
    def __exit__(self,*args):pass
    def read(self,n):return self.data

class SourceBoundAITests(unittest.TestCase):
    def setUp(self):
        e=patch.dict(os.environ,{'GITHUB_ACTIONS':'false'});e.start();self.addCleanup(e.stop)
        t=tempfile.TemporaryDirectory();self.addCleanup(t.cleanup);self.root=Path(t.name)
        self.src=self.root/'source';self.src.mkdir()
        (self.src/'app.py').write_text('def calculate_total():\n    return 5\n')
        (self.src/'test_total.py').write_text('import unittest\nfrom app import calculate_total\nclass T(unittest.TestCase):\n def test_value(self): self.assertEqual(calculate_total(),4)\n')
        (self.src/'test_other.py').write_text('import unittest\nclass T(unittest.TestCase):\n def test_other(self):self.assertTrue(True)\n')
        self.digest=m.master_source_tree_digest(self.src)
        self.plan={'schema':'devnet-test-plan-v1','revision_sha256':self.digest,'tests':[
            {'name':n,'stage':'host','kind':'python-unittest','target':f,'timeout':15}
            for n,f in [('total','test_total.py'),('other','test_other.py')]]}
        self.logs=self.root/'logs'
        self.results=m.master_execute_tests(self.plan,'host',self.src,self.logs)
        self.record={'decision':'FAILED_REPAIR_REQUIRED','job_id':'source-test','revision_sha256':self.digest,'results':self.results}
        self.assertEqual(self.results['total']['status'],'FAIL')
        self.assertTrue(m.master_verify_stage_logs(self.record,self.logs))
        self.output=self.root/'proposal.json'
        self.calls=[]
        self.patch={'path':'app.py','old':'return 5','new':'return 4','explanation':'correct total','risk':'low'}
    def open(self,req,timeout):
        self.calls.append(json.loads(req.data))
        return Response(json.dumps({'done':True,'done_reason':'stop','response':json.dumps(self.patch)}).encode())
    def propose(self,**kw):
        return m.master_propose_local_ai_patch(self.record,self.logs,self.output,['app.py'],opener=self.open,source_root=self.src,**kw)
    def test_verified_source_context_and_schema(self):
        r=self.propose()
        self.assertEqual(r['decision'],'PROPOSAL_ONLY')
        self.assertEqual(r['patch'],self.patch)
        req=self.calls[0]
        self.assertEqual(req['format']['additionalProperties'],False)
        self.assertFalse(req['think'])
        self.assertIn('def calculate_total():',req['prompt'])
        self.assertIn('return 5',req['prompt'])
        self.assertEqual(m.master_source_tree_digest(self.src),self.digest)
        self.assertFalse(r['release_approved'])
    def test_real_full_retest_after_mock_proposal(self):
        r=self.propose()
        result=m.master_apply_reviewed_repair(r,self.src,self.root/'staged',self.plan,['app.py'],authorisation=True,stage='host',evidence_dir=self.root/'retest')
        self.assertEqual(result['decision'],'PRELIMINARY_PASS_UNTRUSTED')
        self.assertEqual(set(result['results']),{'total','other'})
        self.assertTrue(all(x['status']=='PASS' for x in result['results'].values()))
        self.assertTrue(result['logs_verified'])
        self.assertFalse(result['release_approved'])
        self.assertEqual(m.master_source_tree_digest(self.src),self.digest)
        self.assertEqual((self.src/'test_total.py').read_bytes(),(self.root/'staged/test_total.py').read_bytes())
    def test_missing_source_root_fails_closed(self):
        x=m.master_propose_local_ai_patch(self.record,self.logs,self.output,['app.py'],opener=self.open)
        self.assertEqual(x['reason'],'SOURCE_CONTEXT_REQUIRED');self.assertEqual(self.calls,[])
    def test_stale_revision_fails_closed(self):
        (self.src/'app.py').write_text('def calculate_total():\n    return 8\n')
        self.assertEqual(self.propose()['reason'],'SOURCE_REVISION_MISMATCH');self.assertEqual(self.calls,[])
    def test_missing_allowed_file_fails_closed(self):
        x=m.master_propose_local_ai_patch(self.record,self.logs,self.output,['other.py'],opener=self.open,source_root=self.src)
        self.assertEqual(x['reason'],'UNSAFE_REPAIR_SOURCE');self.assertEqual(self.calls,[])
    def test_symlink_file_fails_closed(self):
        (self.src/'app.py').unlink();(self.src/'app.py').symlink_to(self.root/'out-of-tree')
        x=self.propose();self.assertEqual(x['reason'],'SOURCE_CONTEXT_INVALID' if x['reason']=='SOURCE_CONTEXT_INVALID' else x['reason'])
        self.assertEqual(x['decision'],'BLOCKED');self.assertEqual(self.calls,[])
    def test_long_source_fails_closed(self):
        (self.src/'app.py').write_text('X'*4100)
        self.record['revision_sha256']=m.master_source_tree_digest(self.src)
        self.assertEqual(self.propose()['reason'],'SOURCE_CONTEXT_TOO_LARGE')
        self.assertEqual(self.calls,[])
    def test_hallucinated_old_text_rejected(self):
        self.patch['old']='return 99'
        r=self.propose()
        self.assertEqual(r['diagnostic_code'],'REPAIR_CONTEXT_NOT_UNIQUE')
        self.assertFalse(self.output.exists())
    def test_incomplete_response_is_explained(self):
        def incomplete(req,timeout):return Response(json.dumps({'done':True,'done_reason':'length','response':'{}'}).encode())
        r=m.master_propose_local_ai_patch(self.record,self.logs,self.output,['app.py'],opener=incomplete,source_root=self.src)
        self.assertEqual(r['diagnostic_code'],'AI_RESPONSE_INCOMPLETE')
    def test_invalid_json_is_explained(self):
        def invalid(req,timeout):return Response(json.dumps({'done':True,'done_reason':'stop','response':'{bad'}).encode())
        r=m.master_propose_local_ai_patch(self.record,self.logs,self.output,['app.py'],opener=invalid,source_root=self.src)
        self.assertEqual(r['diagnostic_code'],'INVALID_MODEL_JSON')
    def test_ai_cannot_edit_tests(self):
        self.patch['path']='test_total.py'
        self.assertEqual(self.propose()['diagnostic_code'],'UNAUTHORISED_REPAIR_PATH')
    def test_github_never_calls_model(self):
        with patch.dict(os.environ,{'GITHUB_ACTIONS':'true'}):
            self.assertEqual(self.propose()['reason'],'AI_PATCH_HOST_ONLY')
        self.assertEqual(self.calls,[])
    def test_broken_log_rejected_without_ai(self):
        next(self.logs.glob('*.log')).write_text('tampered')
        self.assertEqual(self.propose()['reason'],'VERIFIED_FAILURE_REQUIRED');self.assertEqual(self.calls,[])
    def test_output_symlink_rejected(self):
        self.output.symlink_to(self.root/'outside')
        with self.assertRaisesRegex(ValueError,'OUTPUT_SYMLINK_REFUSED'):self.propose()

if __name__=='__main__':unittest.main()
