#!/usr/bin/env python3
"""Local, policy-bound QA controller v0.4.3.

Only categorical test results go to localhost Qwen (optional); no filesystem
paths, commands, prompts from other projects, SSH output, or secrets. The LLM
cannot acquire additional permissions or define test operations. Full release
approval is explicitly outside this controller's authority.
"""
from __future__ import annotations
import datetime as dt
import fcntl
import http.client
import json
import os
from pathlib import Path
import re
import subprocess
import sys
import tempfile

VERSION = '0.4.4'
TARGET = 'devnet@192.168.122.71'
KEY = Path.home()/'.ssh/devnet-app-qa-ed25519'
STATE = Path.home()/'.local/state/devnet-qa-controller'
STOP = Path.home()/'.config/devnet-qa-automation/stop-all'
PAUSE = Path.home()/'.config/devnet-qa-automation/gaming-on'
CHECKS = ('package_integrity','source_integrity','script_syntax','tray_lock',
          'package_python_tests','package_shell_tests','gui_process_smoke',
          'tray_process_smoke','gui_tab_navigation','gui_clean_close','tray_menu_wiring','gui_sidebar_activation','gui_pointer_navigation')
PREREQS = ('sandbox','display','original_package','original_tray','pinned_baseline','pointer_xvfb','pointer_xtest','pointer_gtk3')
STATUS = {'PASS','FAIL','NOT_TESTED','BLOCKED'}
HEALTH = {'READY','MISSING','MISMATCH'}
# No runtime paths, URLs, or commands are accepted from an AI model.
SSH = ('/usr/bin/ssh', '-F','/dev/null','-i',str(KEY),'-o','IdentitiesOnly=yes',
       '-o','BatchMode=yes','-o','ForwardAgent=no',
       '-o','ClearAllForwardings=yes','-o','StrictHostKeyChecking=yes',
       '-o','ConnectTimeout=5','-o','ServerAliveInterval=5',
       '-o','ServerAliveCountMax=2','-T',TARGET)

# DEVNET_DETERMINISTIC_EVIDENCE_V1
import importlib.util as _devnet_importlib
_devnet_spec = _devnet_importlib.spec_from_file_location('devnet_qa_verified_validator', '/mnt/devnet-ai/memory/bin/devnet-qa-verified.py')
if _devnet_spec is None or _devnet_spec.loader is None:
    raise RuntimeError('verified QA validator unavailable')
_devnet_module = _devnet_importlib.module_from_spec(_devnet_spec)
_devnet_spec.loader.exec_module(_devnet_module)
_devnet_validate = _devnet_module.validate

# DEVNET_DETERMINISTIC_EVIDENCE_V1
def verified_vm_run_response(raw):
    """Validate the SAME VM response; no additional SSH execution."""
    if not isinstance(raw, dict):
        raise RuntimeError('VM evidence is not a dictionary')
    try:
        evidence = _devnet_validate(json.dumps(raw, sort_keys=True))
    except (ValueError, TypeError, json.JSONDecodeError) as exc:
        raise RuntimeError('deterministic VM evidence validation failed') from exc
    if (evidence.get('evidence') != 'VERIFIED'
            or evidence.get('release_approved') is not False
            or evidence.get('master_qa') != 'NOT_VERIFIED'
            or evidence.get('decision') != 'BLOCKED'
            or evidence.get('source_schema') != 'devnet-app-qa-v1'
            or evidence.get('release') != 'vr-stack-v0.6.132'
            or evidence.get('checks') != raw['checks']
            or evidence.get('total') != len(CHECKS)
            or set(evidence['checks']) != set(CHECKS)
            or sum(evidence['counts'].values()) != len(CHECKS)):
        raise RuntimeError('deterministic VM evidence consistency failure')
    return evidence



def game_active() -> bool:
    # Reuse the known-good, real-process game detection from the existing guard.
    try:
        import agent
        return bool(agent.gaming_now())
    except Exception:
        return True  # fail closed


def assert_key() -> None:
    st=KEY.lstat()
    if KEY.is_symlink() or not KEY.is_file() or (st.st_mode & 0o077):
        raise RuntimeError('unsafe restricted SSH key')


def remote(action: str) -> dict:
    if action not in ('run','probe','repair-xvfb'):
        raise ValueError('action not allowlisted')
    assert_key()
    proc=subprocess.run([*SSH,action],stdin=subprocess.DEVNULL,
                        capture_output=True,text=True,timeout=225 if action=='run' else (115 if action=='repair-xvfb' else 12))
    # Strictly one small JSON line; no raw remote data is persisted or printed.
    if proc.returncode or len(proc.stdout)>4096 or proc.stderr.strip():
        raise RuntimeError('remote response rejected')
    lines=proc.stdout.splitlines()
    if len(lines)!=1:
        raise RuntimeError('not an exact JSON response')
    d=json.loads(lines[0])
    if not isinstance(d,dict):
        raise RuntimeError('response type invalid')
    if action=='run':
        if (set(d)!={'schema','release','decision','checks'}
                or d['schema']!='devnet-app-qa-v1'
                or d['release']!='vr-stack-v0.6.132'
                or d['decision']!='BLOCKED' or not isinstance(d['checks'],dict)
                or set(d['checks'])!=set(CHECKS)
                or any(v not in STATUS for v in d['checks'].values())):
            raise RuntimeError('untrusted test result')
    elif action=='repair-xvfb':
        if (set(d)!={'schema','release','dependency','status'}
                or d['schema']!='devnet-app-repair-v1'
                or d['release']!='vr-stack-v0.6.132'
                or d['dependency']!='pointer_xvfb'
                or d['status'] not in {'INSTALLED','ALREADY_READY','PREVIOUS_ATTEMPT','FAILED','BLOCKED'}):
            raise RuntimeError('untrusted repair result')
    else:
        if (set(d)!={'schema','release','prerequisites'}
                or d['schema']!='devnet-app-probe-v1'
                or d['release']!='vr-stack-v0.6.132'
                or not isinstance(d['prerequisites'],dict)
                or set(d['prerequisites'])!=set(PREREQS)
                or any(v not in HEALTH for v in d['prerequisites'].values())):
            raise RuntimeError('untrusted VM probe')
    if action == 'run':
        verified_vm_run_response(d)
    return d


def model_suggestion(checks: dict, health: dict) -> str:
    """Local-only Qwen advice; never gives model any permission to execute.

    Only fixed enums enter the prompt. HTTPConnection to a numeric loopback IP
    avoids DNS, proxy settings, GitHub, remote endpoints and accidental uploads.
    If local inference is unavailable/invalid, fail closed (no AI retry).
    """
    snapshot={k:checks[k] for k in CHECKS}
    prerequisites={k:health[k] for k in PREREQS}
    prompt=('You are a local QA triage helper. Select only a safe action. '
            'JSON object ONLY: {"action":"retry_once"} or {"action":"stop"}. '
            'Never decide PASS, approve a release, or issue a command. '
            'If in doubt select stop. No private data is included. '\
            + json.dumps({'statuses':snapshot,'vm_health':prerequisites},
                         sort_keys=True,separators=(',',':')))
    body=json.dumps({'model':'qwen3.5:9b','prompt':prompt,'stream':False,
                     'format':'json','options':{'num_predict':32,'temperature':0}}).encode()
    conn=http.client.HTTPConnection('127.0.0.1',11434,timeout=10)
    try:
        conn.request('POST','/api/generate',body=body,
                     headers={'Content-Type':'application/json'})
        response=conn.getresponse()
        if response.status != 200:
            return 'stop'
        raw=response.read(2049)
        if len(raw)>2048:
            return 'stop'
        d=json.loads(raw.decode())
        if not isinstance(d,dict) or not isinstance(d.get('response'),str):
            return 'stop'
        proposed=json.loads(d['response'])
        if (isinstance(proposed,dict) and set(proposed)=={'action'}
                and proposed['action'] in ('retry_once','stop')):
            return proposed['action']
    except (OSError,TimeoutError,ValueError,json.JSONDecodeError,UnicodeError):
        return 'stop'
    finally:
        conn.close()
    return 'stop'


def classify(checks: dict) -> str:
    values=set(checks.values())
    if 'FAIL' in values or 'BLOCKED' in values:
        return 'BLOCKED'
    if 'NOT_TESTED' in values:
        return 'PARTIAL'
    return 'PASS_LIMITED'


def eligible_retry(checks: dict, health: dict) -> bool:
    """Only incomplete/transient smoke tests; a FAIL never becomes a PASS."""
    if any(v in ('FAIL','BLOCKED') for v in checks.values()):
        return False
    if any(health[k]!='READY' for k in PREREQS):
        return False
    incomplete=[k for k in CHECKS if checks[k]=='NOT_TESTED']
    return bool(incomplete) and all(k in ('gui_process_smoke','tray_process_smoke','gui_tab_navigation','gui_clean_close','tray_menu_wiring') for k in incomplete)


def sanitized_write(report: dict) -> None:
    STATE.mkdir(parents=True,mode=0o700,exist_ok=True)
    os.chmod(STATE,0o700)
    allowed={'schema','utc','qa','release_approved','attempts','triage',
             'checks','prerequisites','release_gate','dependency_repair'}
    data={k:v for k,v in report.items() if k in allowed}
    raw=(json.dumps(data,sort_keys=True,indent=2)+'\n').encode()
    fd,tmp=tempfile.mkstemp(prefix='qa-',dir=STATE)
    try:
        os.fchmod(fd,0o600)
        with os.fdopen(fd,'wb') as f:
            f.write(raw);f.flush();os.fsync(f.fileno())
        os.replace(tmp,STATE/'latest.json')
    finally:
        if os.path.exists(tmp):os.unlink(tmp)


def run_once() -> str:
    result={'schema':'devnet-controller-v1','utc':dt.datetime.now(dt.timezone.utc).isoformat(),
            'qa':'BLOCKED_UNAVAILABLE','release_approved':False,
            'release_gate':'MASTER_QA_BLOCKED', 'attempts':0,
            'triage':'NOT_RUN','dependency_repair':'NOT_REQUIRED','checks':dict.fromkeys(CHECKS,'NOT_TESTED'),
            'prerequisites':dict.fromkeys(PREREQS,'MISSING')}
    try:
        if game_active() or STOP.exists() or PAUSE.exists():
            result['qa']='PAUSED_GAME'; result['triage']='PAUSED'
            return result['qa']
        # Preflight is read-only and signed-package/integrity prerequisites must
        # be READY before even attempting the single allowlisted repair.
        pre=remote('probe')['prerequisites']
        result['prerequisites']=pre
        if any(pre[k]=='MISMATCH' for k in PREREQS):
            result['qa']='BLOCKED';result['triage']='INTEGRITY_BLOCKED'
            return result['qa']
        if pre['pointer_xvfb']=='MISSING':
            other=('sandbox','display','original_package','original_tray','pinned_baseline','pointer_xtest','pointer_gtk3')
            if all(pre[k]=='READY' for k in other):
                if game_active() or STOP.exists() or PAUSE.exists():
                    result['qa']='PAUSED_GAME';result['triage']='PAUSED'
                    return result['qa']
                repair=remote('repair-xvfb')
                result['dependency_repair']=repair['status']
                if repair['status'] in ('INSTALLED','ALREADY_READY'):
                    post=remote('probe')['prerequisites']
                    result['prerequisites']=post
                    if post['pointer_xvfb']!='READY' or any(post[k]!='READY' for k in other):
                        result['qa']='BLOCKED';result['triage']='REPAIR_VERIFICATION_FAILED'
                        return result['qa']
            else:
                result['dependency_repair']='NOT_AUTHORISED'
        if game_active():
            result['qa']='PAUSED_GAME';result['triage']='PAUSED'
            return result['qa']
        checks=remote('run')['checks']
        result['attempts']=1
        result['checks']=checks
        result['qa']=classify(checks)
        if result['qa']=='PASS_LIMITED':
            result['triage']='COMPLETE_WITHIN_SCOPE'
            return result['qa']
        if game_active():
            result['qa']='PAUSED_GAME';result['triage']='PAUSED'
            return result['qa']
        health=remote('probe')['prerequisites']
        result['prerequisites']=health
        if result['dependency_repair'] in ('FAILED','BLOCKED','PREVIOUS_ATTEMPT'):
            result['triage']='DEPENDENCY_REPAIR_BLOCKED'
        elif any(v=='MISMATCH' for v in health.values()):
            result['triage']='INTEGRITY_BLOCKED'
        elif any(v=='MISSING' for v in health.values()):
            result['triage']='PREREQUISITE_MISSING'
        elif not eligible_retry(checks,health):
            result['triage']='NOT_SAFE_TO_RETRY'
        elif game_active():
            result['qa']='PAUSED_GAME';result['triage']='PAUSED'
        elif model_suggestion(checks,health)=='retry_once' and not game_active():
            updated=remote('run')['checks']
            result['attempts']=2
            # Preserve any first-run FAIL; never overwrite negatives.
            result['checks']={k:(checks[k] if checks[k] in ('FAIL','BLOCKED')
                                 else updated[k]) for k in CHECKS}
            result['qa']=classify(result['checks'])
            result['triage']='ONE_POLICY_APPROVED_RETRY'
        else:
            result['triage']='MODEL_STOP_OR_UNAVAILABLE'
        return result['qa']
    except (OSError,subprocess.SubprocessError,RuntimeError,ValueError,KeyError,
            json.JSONDecodeError,TimeoutError):
        result['qa']='BLOCKED_UNAVAILABLE';result['triage']='ERROR_BLOCKED'
        return result['qa']
    finally:
        sanitized_write(result)


def main():
    if sys.argv[1:] not in (['once'],['status']):
        return 64
    os.umask(0o077)
    if sys.argv[1]=='status':
        try:
            d=json.loads((STATE/'latest.json').read_text())
            print('QA:',d['qa'],'TRIAGE:',d['triage'],'ATTEMPTS:',d['attempts'],
                  'APPROVALS:',0)
        except (OSError,KeyError,ValueError):
            print('QA: NOT_TESTED')
        return 0
    STATE.mkdir(mode=0o700,parents=True,exist_ok=True)
    with (STATE/'controller.lock').open('a+b') as lock:
        try:
            fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
        except BlockingIOError:
            print('BLOCKED_UNAVAILABLE')
            return 2
        state=run_once()
    print(state)
    return 0 if state in ('PASS_LIMITED','PARTIAL','PAUSED_GAME') else 2

if __name__=='__main__':
    raise SystemExit(main())
