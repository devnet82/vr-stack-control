"""v0.3.6 persistent VM-diagnostic repair tests with a synthetic VM adapter.

The adapter executes actual Python subprocess tests locally but is NOT an
attestation of real VM availability. That requires later CachyOS acceptance.
"""
from __future__ import annotations
import importlib.util
import json
import os
from pathlib import Path
import sys
import tempfile
import unittest
from unittest.mock import patch

ROOT=Path(__file__).resolve().parent
CONTROLLER=ROOT/'devnet-qa-automation/controller.py'
sys.path.insert(0,str(CONTROLLER.parent))
spec=importlib.util.spec_from_file_location('devnet_v036_controller',CONTROLLER)
m=importlib.util.module_from_spec(spec)
spec.loader.exec_module(m)


class FakeVm:
    def __init__(self,*,broken_logs=False,bad_retest=False,mutate_source=False):
        self.initial_calls=0;self.retest_calls=0
        self.broken_logs=broken_logs
        self.bad_retest=bad_retest
        self.mutate_source=mutate_source

    def initial(self,src,plan,folder):
        self.initial_calls+=1
        logs=folder/'logs'
        results=m.master_execute_tests(plan,'vm',src,logs)
        record={'job_id':'fixture','revision_sha256':plan['revision_sha256'],
                'decision':'FAILED_REPAIR_REQUIRED' if any(r['status']=='FAIL' for r in results.values()) else 'PRELIMINARY_PASS_UNTRUSTED',
                'results':results,'release_approved':False}
        if self.broken_logs:
            (logs/(next(iter(results.values()))['execution_id']+'.log')).write_text('TAMPERED')
        return record,logs

    def retest(self,src,plan,proposal,allowed,folder):
        self.retest_calls+=1
        if self.mutate_source:
            (src/'app.py').write_text('def calculate_total():\n    return 9\n')
        result=m.master_apply_reviewed_repair(proposal,src,folder/'staged',plan,allowed,
                                               authorisation=True,stage='vm',evidence_dir=folder/'retest_logs')
        if self.bad_retest:
            result['results'].pop('other',None)
        return result,folder/'retest_logs'


class AutoRepairTests(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory(prefix='v036-auto-')
        self.addCleanup(self.tmp.cleanup)
        self.root=Path(self.tmp.name)
        self.src=self.root/'candidate'
        self.src.mkdir()
        (self.src/'app.py').write_text('def calculate_total():\n    return 5\n')
        (self.src/'test_total.py').write_text('import unittest\nfrom app import calculate_total\nclass T(unittest.TestCase):\n def test_value(self): self.assertEqual(calculate_total(),4)\n')
        (self.src/'test_other.py').write_text('import unittest\nclass T(unittest.TestCase):\n def test_other(self): self.assertTrue(True)\n')
        self.digest=m.master_source_tree_digest(self.src)
        self.plan={'schema':'devnet-test-plan-v1','revision_sha256':self.digest,'tests':[
            {'name':'total','stage':'vm','kind':'python-unittest','target':'test_total.py','timeout':15},
            {'name':'other','stage':'vm','kind':'python-unittest','target':'test_other.py','timeout':15}]}
        self.job={'schema':'devnet-master-auto-repair-job-v1','job_id':'fixture',
                  'revision_sha256':self.digest,'allowed_files':['app.py'],
                  'max_attempts':2,'authorised_vm_diagnostic':True}
        self.work=self.root/'workspace'
        self.patch_calls=0

    def proposer(self,record,logs,out,allow,*,source_root,gaming):
        self.patch_calls+=1
        self.assertFalse(gaming)
        self.assertEqual(record['revision_sha256'],m.master_source_tree_digest(source_root))
        self.assertTrue(m.master_verify_stage_logs(record,logs))
        result={'schema':'devnet-master-repair-proposal-v1','decision':'PROPOSAL_ONLY','job_id':'fixture',
                'revision_sha256':self.digest,'model':'mock-only','failure_log_hashes':{},
                'patch':{'path':'app.py','old':'return 5','new':'return 4','explanation':'correct arithmetic','risk':'low'},
                'allowed_files':allow,'source_mutated':False,'release_approved':False,'user_acceptance_ready':False}
        m._master_atomic_json(out,result)
        return result

    def run_cycle(self,transport=None,proposer=None,gaming=lambda:False):
        # Contract tests exercise the host coordinator even on GitHub CI,
        # while a separate test verifies the real GitHub prohibition.
        with patch.dict(os.environ,{'GITHUB_ACTIONS':'false'}):
            return m.master_persistent_vm_repair_cycle(self.job,self.plan,self.src,self.work,
                    transport or FakeVm(),proposer=proposer or self.proposer,gaming=gaming)

    def test_full_real_subprocess_retest_checkpoint(self):
        trans=FakeVm();r=self.run_cycle(trans)
        self.assertEqual(r['decision'],'AWAITING_GITHUB_RETEST')
        self.assertEqual(r['report']['initial'],{'total':'FAIL','other':'PASS'})
        self.assertEqual(r['report']['retest'],{'total':'PASS','other':'PASS'})
        self.assertEqual(r['attempts'],1)
        self.assertEqual(trans.initial_calls,1);self.assertEqual(trans.retest_calls,1)
        self.assertFalse(r['release_approved']);self.assertFalse(r['trusted_evidence'])
        self.assertEqual(self.digest,m.master_source_tree_digest(self.src))
        self.assertEqual((self.work/'attempt-1/staged/app.py').read_text().strip().splitlines()[-1],'    return 4')
        for f in ('test_total.py','test_other.py'):
            self.assertEqual((self.work/'attempt-1/staged'/f).read_bytes(),(self.src/f).read_bytes())
        checkpoint=json.loads((self.work/'checkpoint.json').read_text())
        self.assertEqual(checkpoint['phase'],'AWAITING_GITHUB_RETEST')
        self.assertEqual(checkpoint['history'][0]['candidate_sha256'],r['report']['candidate_sha256'])
        self.assertEqual((self.work/'checkpoint.json').stat().st_mode&0o077,0)

    def test_restart_does_not_self_approve_or_rerun(self):
        t=FakeVm();self.run_cycle(t);r=self.run_cycle(t)
        self.assertEqual(r['decision'],'AWAITING_GITHUB_RETEST')
        self.assertEqual(t.initial_calls,1);self.assertEqual(t.retest_calls,1)
        self.assertEqual(self.patch_calls,1)

    def test_paused_before_vm_or_ai(self):
        t=FakeVm();r=self.run_cycle(t,gaming=lambda:True)
        self.assertEqual(r['decision'],'PAUSED')
        self.assertEqual(t.initial_calls,0)
        self.assertEqual(self.patch_calls,0)
        self.assertEqual(json.loads((self.work/'checkpoint.json').read_text())['attempts'],0)

    def test_resume_from_gaming_pause(self):
        t=FakeVm();self.run_cycle(t,gaming=lambda:True)
        r=self.run_cycle(t,gaming=lambda:False)
        self.assertEqual(r['decision'],'AWAITING_GITHUB_RETEST')

    def test_pause_between_vm_and_ai(self):
        checks=iter([False,True])
        t=FakeVm();r=self.run_cycle(t,gaming=lambda:next(checks))
        self.assertEqual(r['decision'],'PAUSED')
        self.assertEqual(t.initial_calls,1);self.assertEqual(t.retest_calls,0)
        self.assertEqual(self.patch_calls,0)

    def test_invalid_vm_evidence_blocks(self):
        r=self.run_cycle(FakeVm(broken_logs=True))
        self.assertEqual(r['decision'],'BLOCKED')
        self.assertEqual(r['report']['error_type'],'ValueError')
        self.assertEqual(self.patch_calls,0)

    def test_tampered_source_after_vm_blocks(self):
        r=self.run_cycle(FakeVm(mutate_source=True))
        self.assertEqual(r['decision'],'BLOCKED')
        self.assertFalse(r['release_approved'])

    def test_missing_retest_result_blocks(self):
        r=self.run_cycle(FakeVm(bad_retest=True))
        self.assertEqual(r['decision'],'BLOCKED')
        self.assertEqual(r['report']['outcome'],'BLOCKED_EXCEPTION')

    def test_proposal_unavailable_bounded(self):
        t=FakeVm()
        def no_ai(*args,**kwargs):
            return {'decision':'BLOCKED','reason':'AI_PATCH_UNAVAILABLE_OR_INVALID'}
        a=self.run_cycle(t,proposer=no_ai);b=self.run_cycle(t,proposer=no_ai);c=self.run_cycle(t,proposer=no_ai)
        self.assertEqual(a['decision'],'RETEST_FAILED')
        self.assertEqual(b['decision'],'BLOCKED')
        self.assertEqual(c['reason'],'NO_UNTRUSTED_AUTORESTART')
        self.assertEqual(t.initial_calls,2)
        self.assertEqual(json.loads((self.work/'checkpoint.json').read_text())['attempts'],2)

    def test_bad_ai_patch_does_not_run_vm_retest(self):
        t=FakeVm()
        def fake(*args,**kw):
            q=self.proposer(*args,**kw)
            q['patch']['path']='test_total.py'
            return q
        r=self.run_cycle(t,proposer=fake)
        self.assertEqual(r['decision'],'BLOCKED')
        self.assertEqual(t.retest_calls,0)

    def test_test_file_never_authorised(self):
        self.job['allowed_files']=['test_total.py']
        with self.assertRaisesRegex(ValueError,'INVALID_REPAIR_ALLOWLIST'):
            self.run_cycle()

    def test_not_authorised_refused(self):
        self.job['authorised_vm_diagnostic']=False
        with self.assertRaisesRegex(ValueError,'INVALID_AUTOREPAIR_JOB'):
            self.run_cycle()

    def test_excess_attempts_refused(self):
        self.job['max_attempts']=9
        with self.assertRaisesRegex(ValueError,'INVALID_AUTOREPAIR_JOB'):
            self.run_cycle()

    def test_mismatch_revision_refused(self):
        self.job['revision_sha256']='a'*64
        with self.assertRaisesRegex(ValueError,'SOURCE_REVISION_MISMATCH'):
            self.run_cycle()

    def test_source_mutation_requires_new_job(self):
        (self.src/'app.py').write_text('return 5\n# source changed\n')
        with self.assertRaisesRegex(ValueError,'SOURCE_REVISION_MISMATCH'):
            self.run_cycle()

    def test_github_runner_never_calls_local_ai(self):
        with patch.dict(os.environ,{'GITHUB_ACTIONS':'true'}):
            with self.assertRaisesRegex(ValueError,'LOCAL_AI_AND_VM_BRIDGE_HOST_ONLY'):
                m.master_persistent_vm_repair_cycle(self.job,self.plan,self.src,self.work,FakeVm(),
                    proposer=self.proposer,gaming=lambda:False)

    def test_invalid_state_refuses(self):
        self.work.mkdir(mode=0o700)
        (self.work/'checkpoint.json').write_text('{broken')
        with self.assertRaises(json.JSONDecodeError):
            self.run_cycle()

    def test_forged_release_flag_rejected(self):
        self.work.mkdir(mode=0o700)
        state={'schema':'devnet-master-auto-repair-state-v1','job_id':'fixture','revision_sha256':self.digest,
               'attempts':0,'phase':'READY','history':[],'release_approved':True,'user_acceptance_ready':False}
        (self.work/'checkpoint.json').write_text(json.dumps(state))
        with self.assertRaisesRegex(ValueError,'INVALID_OR_TAMPERED_CHECKPOINT'):
            self.run_cycle()

    def test_symlinked_state_refused(self):
        self.work.symlink_to(self.src)
        with self.assertRaisesRegex(ValueError,'UNSAFE_STATE_WORKSPACE'):
            self.run_cycle()

    def test_stage_mismatch_refused(self):
        self.plan['tests'][0]['stage']='host'
        with self.assertRaisesRegex(ValueError,'VM_PLAN_REQUIRED'):
            self.run_cycle()

    def test_changed_proposal_revision_refused(self):
        t=FakeVm()
        def bad(*args,**kwargs):
            q=self.proposer(*args,**kwargs)
            q['revision_sha256']='a'*64
            return q
        r=self.run_cycle(t,proposer=bad)
        self.assertEqual(r['decision'],'BLOCKED')
        self.assertEqual(t.retest_calls,0)

    def test_existing_controller_cli_still_fail_closed(self):
        # Running without a registered, restricted job cannot launch work.
        import subprocess
        with tempfile.TemporaryDirectory() as home:
            p=subprocess.run([sys.executable,str(CONTROLLER),'master-autorepair'],
                env={**os.environ,'HOME':home},capture_output=True,text=True,timeout=15)
        self.assertEqual(p.returncode,0)
        self.assertEqual(json.loads(p.stdout)['decision'],'BLOCKED')

if __name__=='__main__': unittest.main()
