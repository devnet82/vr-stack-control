import ast, json, pathlib, tempfile, unittest, hashlib, fcntl, os
from pathlib import Path
from unittest.mock import patch
SOURCE=Path(__file__).parent/'devnet-qa-automation/controller.py'
tree=ast.parse(SOURCE.read_text())
names={'master_next_step','master_cycle','_master_atomic_json'}
selected=[n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name in names]
assert len(selected)==3
ns={'json':json,'Path':Path,'re':__import__('re'),'tempfile':tempfile,'os':os,'fcntl':fcntl,'MASTER_RESULTS':frozenset(('PASS','FAIL','BLOCKED','NOT_TESTED')),'MASTER_STAGES':('github','vm','host'),'MASTER_STATE_SCHEMA':'devnet-master-progress-v1'}
exec(compile(ast.Module(body=selected,type_ignores=[]),str(SOURCE),'exec'),ns)
step=ns['master_next_step']; cycle=ns['master_cycle']; REV='a'*64
JOB={'schema':'devnet-master-job-v1','job_id':'job-01','revision_sha256':REV,'requirements':['g','v','h'],'stages':{'github':['g'],'vm':['v'],'host':['h']}}
PROGRESS={'schema':'devnet-master-progress-v1','job_id':'job-01','revision_sha256':REV,'status':'QUEUED','attempts':0}
class EngineTests(unittest.TestCase):
    def test_no_ai_claims(self): self.assertEqual(step(JOB,PROGRESS)['decision'],'BLOCKED')
    def test_github_first(self): self.assertEqual(step(JOB,PROGRESS,{'g':'NOT_TESTED','v':'NOT_TESTED','h':'NOT_TESTED'})['next_stage'],'github')
    def test_vm_next(self): self.assertEqual(step(JOB,PROGRESS,{'g':'PASS','v':'NOT_TESTED','h':'NOT_TESTED'})['next_stage'],'vm')
    def test_host_next(self): self.assertEqual(step(JOB,PROGRESS,{'g':'PASS','v':'PASS','h':'NOT_TESTED'})['next_stage'],'host')
    def test_fail_blocks(self): self.assertEqual(step(JOB,PROGRESS,{'g':'PASS','v':'FAIL','h':'NOT_TESTED'})['decision'],'BLOCKED')
    def test_gaming_pauses(self): self.assertEqual(step(JOB,PROGRESS,{'g':'PASS','v':'PASS','h':'PASS'},game=True)['decision'],'PAUSED')
    def test_verified_never_approves_release(self): self.assertEqual(step(JOB,PROGRESS,{'g':'PASS','v':'PASS','h':'PASS'})['decision'],'AI_TESTS_VERIFIED')
    def test_revision_invalidates(self):
        p={**PROGRESS,'revision_sha256':'b'*64}; self.assertEqual(step(JOB,p,{'g':'PASS','v':'PASS','h':'PASS'})['reason'],'REVISION_CHANGED_REQUIRE_FULL_RETEST')
    def test_missing_check_rejected(self): self.assertEqual(step(JOB,PROGRESS,{'g':'PASS'})['decision'],'BLOCKED')
    def test_stage_requirement_mismatch(self):
        j={**JOB,'stages':{'github':['g'],'vm':['h'],'host':['v']}}; self.assertEqual(step(j,PROGRESS,{'g':'PASS','v':'PASS','h':'PASS'})['decision'],'BLOCKED')
    def test_checkpoint_survives_restart(self):
        with tempfile.TemporaryDirectory() as d:
            jf=Path(d)/'job.json'; st=Path(d)/'progress.json'; jf.write_text(json.dumps(JOB))
            first=cycle(jf,st,{'g':'PASS','v':'NOT_TESTED','h':'NOT_TESTED'}); self.assertEqual(first['next_stage'],'vm')
            second=cycle(jf,st,{'g':'PASS','v':'PASS','h':'NOT_TESTED'}); self.assertEqual(second['next_stage'],'host')
            self.assertFalse(json.loads(st.read_text())['release_approved'])
    def test_pause_then_resume(self):
        with tempfile.TemporaryDirectory() as d:
            jf=Path(d)/'job.json'; st=Path(d)/'progress.json'; jf.write_text(json.dumps(JOB))
            self.assertEqual(cycle(jf,st,{'g':'PASS','v':'PASS','h':'PASS'},True)['decision'],'PAUSED')
            self.assertEqual(cycle(jf,st,{'g':'PASS','v':'PASS','h':'PASS'},False)['decision'],'AI_TESTS_VERIFIED')
    def test_new_revision_fails_closed(self):
        with tempfile.TemporaryDirectory() as d:
            jf=Path(d)/'job.json'; st=Path(d)/'progress.json'; jf.write_text(json.dumps(JOB))
            cycle(jf,st,{'g':'PASS','v':'PASS','h':'PASS'})
            new={**JOB,'revision_sha256':'b'*64}; jf.write_text(json.dumps(new))
            r=cycle(jf,st,{'g':'PASS','v':'PASS','h':'PASS'}); self.assertEqual(r['decision'],'BLOCKED');self.assertFalse(json.loads(st.read_text())['user_acceptance_ready'])
    def test_corrupt_checkpoint_rejected(self):
        with tempfile.TemporaryDirectory() as d:
            jf=Path(d)/'job.json'; st=Path(d)/'progress.json'; jf.write_text(json.dumps(JOB));st.write_text('INVALID')
            with self.assertRaises(ValueError): cycle(jf,st)
if __name__=='__main__':unittest.main()
