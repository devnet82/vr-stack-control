"""Contract tests for isolated VM worker; VM identity is mocked, not attested."""
import importlib.util
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
import unittest
import uuid
import zipfile
from unittest.mock import patch

HERE=Path(__file__).resolve().parent
P=HERE/'devnet-qa-automation/master_vm_worker.py'
spec=importlib.util.spec_from_file_location('devnet_restricted_vm_test_worker',P)
w=importlib.util.module_from_spec(spec)
spec.loader.exec_module(w)


class VmWorkerTests(unittest.TestCase):
    def setUp(self):
        self.dir=Path('/tmp/devnet-master-cycle-'+uuid.uuid4().hex[:8])
        self.dir.mkdir(mode=0o700)
        self.addCleanup(shutil.rmtree,self.dir,ignore_errors=True)
        controller_dir=self.dir/'module/devnet-qa-automation'
        controller_dir.mkdir(mode=0o700,parents=True)
        for name in ('controller.py','agent.py'):
            shutil.copy2(HERE/'devnet-qa-automation'/name,controller_dir/name)
        shutil.copy2(HERE/'devnet-qa-verified.py',self.dir/'module/devnet-qa-verified.py')
        self.files={
            'app.py':'def calculate_total():\n    return 5\n',
            'test_total.py':'import unittest\nfrom app import calculate_total\nclass T(unittest.TestCase):\n def test_value(self): self.assertEqual(calculate_total(),4)\n',
            'test_other.py':'import unittest\nclass T(unittest.TestCase):\n def test_other(self): self.assertTrue(True)\n'}
        source=self.dir/'expected'
        source.mkdir()
        for n,content in self.files.items():
            (source/n).write_text(content)
        sys.path.insert(0,str(controller_dir))
        self.addCleanup(lambda:sys.path.remove(str(controller_dir)))
        c_spec=importlib.util.spec_from_file_location('worker_contract_controller',controller_dir/'controller.py')
        self.m=importlib.util.module_from_spec(c_spec)
        c_spec.loader.exec_module(self.m)
        self.digest=self.m.master_source_tree_digest(source)
        self.plan={'schema':'devnet-test-plan-v1','revision_sha256':self.digest,'tests':[
            {'name':'total','stage':'vm','kind':'python-unittest','target':'test_total.py','timeout':15},
            {'name':'other','stage':'vm','kind':'python-unittest','target':'test_other.py','timeout':15}]}
        self.job={'job_id':'fixture','allowed_files':['app.py'],'authorised_vm_diagnostic':True}
        (self.dir/'plan.json').write_text(json.dumps(self.plan))
        (self.dir/'job.json').write_text(json.dumps(self.job))
        with zipfile.ZipFile(self.dir/'source.zip','w') as z:
            for n,content in self.files.items():z.writestr(n,content)
        # The worker's VM detection is mocked for local contract tests only.
        real=subprocess.run
        def fake(args,*a,**kw):
            if args==['systemd-detect-virt','--vm']:
                return subprocess.CompletedProcess(args,0,stdout='kvm\n',stderr='')
            return real(args,*a,**kw)
        self.patched=patch.object(w.subprocess,'run',side_effect=fake)

    def test_vm_initial_then_repair_full_retest(self):
        with self.patched:
            init=w.worker('initial',self.dir)
            self.assertEqual(init['decision'],'FAILED_REPAIR_REQUIRED')
            record=json.loads((self.dir/'record.json').read_text())
            self.assertEqual({k:v['status'] for k,v in record['results'].items()}, {'total':'FAIL','other':'PASS'})
            proposal={'schema':'devnet-master-repair-proposal-v1','decision':'PROPOSAL_ONLY',
                      'job_id':'fixture','revision_sha256':self.digest,'allowed_files':['app.py'],
                      'source_mutated':False,'release_approved':False,
                      'patch':{'path':'app.py','old':'return 5','new':'return 4','explanation':'repair','risk':'low'}}
            (self.dir/'proposal.json').write_text(json.dumps(proposal))
            done=w.worker('retest',self.dir)
        self.assertEqual(done['decision'],'PRELIMINARY_PASS_UNTRUSTED')
        result=json.loads((self.dir/'retest.json').read_text())
        self.assertEqual({k:v['status'] for k,v in result['results'].items()}, {'total':'PASS','other':'PASS'})
        self.assertTrue(result['logs_verified'])
        self.assertFalse(result['release_approved'])
        self.assertFalse(result['user_acceptance_ready'])
        self.assertEqual((self.dir/'source/app.py').read_text(),self.files['app.py'])
        self.assertEqual((self.dir/'staged/test_total.py').read_text(),self.files['test_total.py'])

    def test_real_vm_identity_required(self):
        with patch.object(w.subprocess,'run',return_value=subprocess.CompletedProcess([],1,stdout='',stderr='')):
            with self.assertRaisesRegex(ValueError,'ISOLATED_QEMU_KVM_VM_REQUIRED'):
                w.worker('initial',self.dir)
        self.assertFalse((self.dir/'source').exists())

    def test_traversal_archive_rejected(self):
        with zipfile.ZipFile(self.dir/'source.zip','w') as z:z.writestr('../escape.py','x=5')
        with self.patched:
            with self.assertRaisesRegex(ValueError,'UNSAFE_SOURCE_ARCHIVE'):
                w.worker('initial',self.dir)

    def test_missing_proposal_blocks(self):
        with self.patched:
            w.worker('initial',self.dir)
            with self.assertRaises(FileNotFoundError):
                w.worker('retest',self.dir)

if __name__=='__main__':unittest.main()
