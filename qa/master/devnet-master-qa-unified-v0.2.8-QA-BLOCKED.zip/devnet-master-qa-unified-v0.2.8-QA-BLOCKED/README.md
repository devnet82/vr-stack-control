# Devnet Unified Master QA v0.2.8 — QA BLOCKED

Single-controller candidate; no competing daemon or production installation. Preserves the original VR Stack controller and v0.2.7 queue logic. Adds a restricted **real test execution** function (`master_execute_tests`) with fixed kinds (`python-unittest`, `python-compile`), no shell, isolated outputs, timeout, exit-code and immutable log SHA256 evidence. It runs actual tests, not model-generated PASS claims. Only an administrator-approved immutable test plan may be used.

**Limitations:** This is NOT a trusted production executor, does NOT attest GitHub runner identity, does NOT provide separate privileged signing, DOES NOT run GUI/VM actions or autonomous AI repairs yet, and is NOT wired to the persistent queue or a daemon. The AI must never supply a mutable plan or read a protected signing key. Until authenticated GitHub evidence, OS-isolated test execution and the repair loop are implemented, all releases remain BLOCKED.

GitHub test first; CachyOS VM second; host last; user acceptance only after independently verified all-applicable PASS. Every revision reruns all applicable tests. Preserve installed controller until full verification.
