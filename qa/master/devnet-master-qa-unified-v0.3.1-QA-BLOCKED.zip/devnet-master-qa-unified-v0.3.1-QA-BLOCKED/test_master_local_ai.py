import importlib.util,json,os,tempfile,unittest
from pathlib import Path
from unittest.mock import patch
SOURCE=Path(__file__).parent/'devnet-qa-automation/controller.py'
sp=importlib.util.spec_from_file_location('devnet_v031',SOURCE)
mod=importlib.util.module_from_spec(sp);sp.loader.exec_module(mod)
class Response:
 def __init__(self,payload):self.payload=payload
 def __enter__(self):return self
 def __exit__(self,*args):pass
 def read(self,n):return self.payload
class LocalAITests(unittest.TestCase):
 def setUp(self):
  self.t=tempfile.TemporaryDirectory();self.addCleanup(self.t.cleanup);self.root=Path(self.t.name)
  self.logs=self.root/'logs';self.logs.mkdir();self.data=b'Traceback: known error\n'
  (self.logs/'a'*0) if False else None
  (self.logs/('a'*32+'.log')).write_bytes(self.data)
  self.record={'decision':'FAILED_REPAIR_REQUIRED','job_id':'case','revision_sha256':'a'*64,'results':{'test':{'status':'FAIL','exit_code':1,'execution_id':'a'*32,'log_sha256':mod._master_digest(self.data)}}}
  self.out=self.root/'ai.json';self.calls=[]
 def open(self,req,timeout):
  self.calls.append((req,timeout))
  content={'cause':'missing dependency','proposed_fix':'inspect setup','risk':'low','files_to_review':['setup.py']}
  return Response(json.dumps({'response':json.dumps(content)}).encode())
 def invoke(self,**kw):return mod.master_local_ai_triage(self.record,self.logs,self.out,opener=self.open,**kw)
 def test_real_evidence_produces_advisory(self):
  r=self.invoke();self.assertEqual(r['decision'],'PROPOSAL_ONLY');self.assertFalse(r['release_approved']);self.assertEqual(json.loads(self.out.read_text())['diagnosis']['cause'],'missing dependency')
 def test_uses_local_model_and_structured_json(self):
  self.invoke();q=json.loads(self.calls[0][0].data);self.assertEqual(q['model'],'qwen3.5:9b');self.assertFalse(q['stream']);self.assertEqual(q['format'],'json')
 def test_game_pause_no_model_call(self):self.assertEqual(self.invoke(gaming=True)['decision'],'PAUSED');self.assertEqual(self.calls,[])
 def test_github_blocked(self):
  with patch.dict(os.environ,{'GITHUB_ACTIONS':'true'}):self.assertEqual(self.invoke()['reason'],'AI_TRIAGE_HOST_ONLY')
 def test_untrusted_evidence_blocked(self):
  (self.logs/('a'*32+'.log')).write_text('changed');self.assertEqual(self.invoke()['reason'],'INVALID_EVIDENCE')
 def test_pass_is_not_sent_to_ai(self):
  self.record['decision']='PRELIMINARY_PASS_UNTRUSTED';self.assertEqual(self.invoke()['reason'],'NO_VERIFIED_FAILURE')
 def test_external_endpoint_forbidden(self):
  with self.assertRaisesRegex(ValueError,'LOCAL_OLLAMA_ENDPOINT_REQUIRED'):self.invoke(endpoint='http://example.com:11434/api/generate')
 def test_localhost_endpoint_allowed(self):self.assertEqual(self.invoke(endpoint='http://localhost:11434/api/generate')['decision'],'PROPOSAL_ONLY')
 def test_invalid_model_forbidden(self):
  with self.assertRaisesRegex(ValueError,'INVALID_LOCAL_MODEL'):self.invoke(model='qwen;rm -rf /')
 def test_invalid_model_response_blocks(self):
  r=mod.master_local_ai_triage(self.record,self.logs,self.out,opener=lambda req,timeout:Response(b'{bad'))
  self.assertEqual(r['reason'],'LOCAL_AI_UNAVAILABLE_OR_INVALID');self.assertFalse(self.out.exists())
 def test_model_cannot_claim_approval(self):
  def opener(req,timeout):return Response(json.dumps({'response':json.dumps({'cause':'x','proposed_fix':'y','risk':'z','files_to_review':[],'release_approved':True})}).encode())
  r=mod.master_local_ai_triage(self.record,self.logs,self.out,opener=opener);self.assertEqual(r['decision'],'BLOCKED')
 def test_model_cannot_modify_source(self):
  marker=self.root/'source.py';marker.write_text('original');self.invoke();self.assertEqual(marker.read_text(),'original')
 def test_network_failure_fails_closed(self):
  def broken(req,timeout):raise ConnectionRefusedError('offline')
  r=mod.master_local_ai_triage(self.record,self.logs,self.out,opener=broken);self.assertEqual(r['decision'],'BLOCKED')
 def test_traversal_output_refused(self):
  self.out.symlink_to(self.root/'outside');
  with self.assertRaisesRegex(ValueError,'OUTPUT_SYMLINK_REFUSED'):self.invoke()
if __name__=='__main__':unittest.main()
