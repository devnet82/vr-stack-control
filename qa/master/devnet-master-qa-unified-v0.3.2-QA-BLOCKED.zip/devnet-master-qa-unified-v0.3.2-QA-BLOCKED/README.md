# Devnet unified Master QA v0.3.2 — QA BLOCKED

One candidate controller, preserving existing v0.4.4 application controller. Adds source-tree-bound preliminary evidence, independent actual log SHA verification and revision-change blocking to the v0.2.9 live-stage executor. These checks are part of the same controller, not a second QA service.

**Important remaining blockers:** Production protected signer/attestation, authentic GitHub run provenance validation, approved job-specific test plan management, privileged cross-stage evidence validation, autonomous AI repair and full real GUI and application tests are NOT operational. Local verification is not GitHub or VM verification. No release approval. No production replacement.

The source digest covers the entire supplied project directory, including Python-generated __pycache__. Consequently source trees should be read-only/immutable and tests should write caches elsewhere; any changes fail closed. The bound stage may have to be upgraded to operate on immutable clean trees for real production use.


Local AI triage integration: `master_local_ai_triage` passes only hash-verified failed test logs to local Ollama qwen3.5:9b on 127.0.0.1:11434, after host gaming safety check. It saves strictly advisory, non-executable proposals. No source mutation, no release permission, no AI repairs in this release. Host Ollama integration requires actual host testing; bundled tests mock transport.

QA regression correction: local Ollama transport tests explicitly simulate host environment; GitHub-host prohibition is separately tested with GITHUB_ACTIONS=true.
