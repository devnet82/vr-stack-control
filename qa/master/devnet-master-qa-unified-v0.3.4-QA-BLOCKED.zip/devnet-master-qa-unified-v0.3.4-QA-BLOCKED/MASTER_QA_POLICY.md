# Devnet Master QA — Consolidated policy candidate

ONE authoritative local QA service/controller, one job registry, one evidence gate, one report. The v0.4.4 controller remains the source for existing restricted-VM testing; no competing services or supplemental active gates may be installed.

## Mandatory requirements for EVERY software job and EVERY revision

1. Before work begins, register the COMPLETE job-specific checklist, including original requirements, accumulated bug findings, install/upgrade/rollback, security, privacy, GUI/tray and hardware/VM tests where applicable. Missing or unregistered checks block acceptance. Do not silently mark a check non-applicable.
2. The AI must perform ALL applicable tests itself on the EXACT revision EVERY time, even when those tests passed on prior builds. No inherited PASS and no cherry-picked test subsets.
3. Test the actual application in the existing CachyOS VM where applicable. Host-only GPU/VR tests must run on the host with safe scheduling. Unit tests do not substitute for real GUI, network, security or recovery tests.
4. When any test fails, the AI may apply only authorised safe fixes, then rerun the FULL applicable job-specific checklist for the new revision. Log every failure and intervention. Preserve originals and evidence.
5. The AI can diagnose and execute tests, but its PASS prose is not evidence. A separately privileged trusted executor must produce tamper-resistant execution receipts, bound to the registered checklist and exact revision. No unsigned, AI-authored, stale or simulated PASS.
6. **Do not offer the software for the user's acceptance testing until ALL applicable AI tests have verifiably PASSED.** User acceptance is the last stage, never a substitute for missing AI testing. User-reported failures become mandatory regression requirements on subsequent revisions.
7. Persist unfinished jobs, results and checkpoints so the local controller can resume safely after interruptions and across chats. Pause during gaming/VR, respect stop-all/gaming-on, do not interrupt independent work. Resume only when preconditions are safe.
8. A genuine unresolvable blocker must be reported honestly. FAIL, BLOCKED and NOT_TESTED never become PASS, and no system may silently approve a release. Release approval remains separately gated by explicit authorised acceptance.

## Scope of THIS candidate

The one existing controller now includes a built-in fail-closed per-job evidence gate (`master-status`). It requires a separately secured trusted executor and registered job checklist that the supplied archive does not include. Until those are provisioned, `master-status` must show BLOCKED; this candidate does NOT run every arbitrary software test, implement persistent job-queue recovery or approve a release. It is not installed and is **QA BLOCKED**.

## v0.2.5 mandatory environment sequence — EVERY job, EVERY revision

The ONE authoritative Master QA controller MUST enforce GitHub CI/hosted runner testing FIRST. All applicable requirements assigned to the `github` stage must execute and independently pass for the EXACT revision before any test runs in the user's personal CachyOS QA VM. All applicable `vm` checks must pass before hardware-specific `host` checks run. The user is asked to perform final acceptance only when all these checks have genuinely passed. A new revision or fix resets the entire sequence; previous GitHub, VM and host PASS results MUST NOT be inherited. Tests that cannot run on GitHub are explicitly registered for later stages, never silently omitted. GitHub Actions is not automatically a CachyOS GUI/VM environment; job-specific tests must be assigned to realistic runners. Failures/blocked tests stop downstream execution and trigger authorised repair followed by a fresh full sequence. The AI performs tests; a separate trusted executor produces receipts; the AI cannot self-approve. No new add-on or competing service.

This v0.2.5 candidate adds stage binding and ordering checks to the existing `master-status` validator but DOES NOT install GitHub Actions or a trusted signer, and does not execute the full workload. Missing trusted execution remains BLOCKED.

Portable controller-preservation regression: compare AST functions with pinned original baseline/controller.py embedded from the user-supplied current baseline archive. Every subsequent revision must repeat the full applicable QA checklist.

## v0.2.8 test execution
The integrated restricted harness runs real tests and captures log digests and exit statuses. It cannot attest its environment, and its unsigned results MUST NOT satisfy the trusted production gate. No automatic repairs or deployment until independently secured execution and end-to-end integration are tested.


### v0.2.9 restricted live-stage loop
The unified controller now executes the full registered GitHub-stage test list and checkpoints actual exit codes and log digests. Those results are preliminary UNTRUSTED evidence, never a release signature. Later VM/host execution is fail-closed pending separately protected GitHub and VM attestation. AI repair invocation, privilege separation, automatic service scheduling and full application GUI testing remain NOT IMPLEMENTED.

## v0.3.0 source identity and logs
Every test result must correspond to an exact immutable source tree revision, and actual output log bytes must match recorded hashes. Source drift or tampered/absent logs blocks approval. AI cannot grant itself signing authority. Before user acceptance: trusted GitHub, VM and host evidence, all applicable tests, authorised repairs and full retests must pass.


## v0.3.3 local AI gate
Only local Ollama diagnosis on verified failures; proposal remains untrusted and must be reviewed before authorised changes. Do not mistake a model suggestion for a test or trusted attestation.

QA regression correction: local Ollama transport tests explicitly simulate host environment; GitHub-host prohibition is separately tested with GITHUB_ACTIONS=true.

Local Ollama reliability v0.3.3: disable model reasoning (`think:false`), bound generated tokens, and fail closed if the model response is empty, incomplete, or ended due to length limits. Verified real-host inference still requires QA testing on the user machine.


### v0.3.4 controlled-repair constraint
AI may propose only a bounded exact text replacement within a pre-authorised production `.py` file. Independent authorisation and allowlisting are required before applying it to an isolated copy. Complete applicable stage retesting is mandatory. Any preliminary PASS is untrusted and must never enable release.
