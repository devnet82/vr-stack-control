# Devnet unified Master QA v0.3.6 — QA BLOCKED

One candidate controller, preserving existing v0.4.4 application controller. Adds source-tree-bound preliminary evidence, independent actual log SHA verification and revision-change blocking to the v0.2.9 live-stage executor. These checks are part of the same controller, not a second QA service.

**Important remaining blockers:** Production protected signer/attestation, authentic GitHub run provenance validation, full integrated cross-stage job management, automatically scheduled durable repair cycles, and full real GUI/application testing are NOT operational. Local verification is not GitHub or VM verification. No release approval. No production replacement.

The source digest covers the entire supplied project directory, including Python-generated __pycache__. Consequently source trees should be read-only/immutable and tests should write caches elsewhere; any changes fail closed. The bound stage may have to be upgraded to operate on immutable clean trees for real production use.


Local AI triage integration: `master_local_ai_triage` passes only hash-verified failed test logs to local Ollama qwen3.5:9b on 127.0.0.1:11434, after host gaming safety check. It saves strictly advisory, non-executable proposals. No source mutation by the triage function and no release permission. Subsequent experimental repair functions use separate allowlist checks and disposable VM copies.

QA regression correction: local Ollama transport tests explicitly simulate host environment; GitHub-host prohibition is separately tested with GITHUB_ACTIONS=true.

Local Ollama reliability v0.3.3: disable model reasoning (`think:false`), bound generated tokens, and fail closed if the model response is empty, incomplete, or ended due to length limits. Verified real-host inference still requires QA testing on the user machine.


## v0.3.4 experimental repair stage
`master_propose_local_ai_patch` asks local Ollama for a structured exact-replacement proposal using verified failed logs. `master_apply_reviewed_repair` requires explicit operator authorisation plus a separately supplied narrow allowlist. It copies untouched source into a new disposable directory and retests every declared test on the selected stage, preserving logs. It cannot modify test files, install to the host, sign results, approve releases, or claim trusted evidence. Full autonomous repair and cross-stage production attestation are still NOT IMPLEMENTED.


## v0.3.5 — Source-bound AI repair prompts
The v0.3.4 live-model repair proposal was rejected without diagnostic detail. The
new function requires an explicit source_root whose tree digest matches the
failed-stage revision. It includes only bounded authorised production source
text in the model prompt, with a constrained JSON schema and exact-substring
validation. Rejections report a stable diagnostic_code, not raw model output.
No production source changes, release approval or trusted signing are permitted.

## v0.3.6: persistent local-AI + disposable-VM repair coordinator (QA BLOCKED)

The existing controller now has **`master-autorepair`**. It reads an explicitly
registered, permission-0600 job from `~/.config/devnet-qa-automation/master-repair-job.json`.
Each invocation attempts at most **one** bounded, authorised diagnosis/repair in
`devnet@192.168.122.71`, retaining private execution logs, source/plan hashes,
AI proposals and a persistent checkpoint in `/mnt/devnet-ai/qa/`.

The source must reside below `/mnt/devnet-ai/projects/`. Only up to three VM
diagnostic attempts are allowed per registered source revision. The local model
is used **only on the host**, with `think:false`, and receives verified failure
logs and only allowlisted small source files. The worker applies an authorised
single-file replacement in a **disposable VM copy** and reruns every declared VM
test; the original source, tests, and installed QA controller remain untouched.

A passing VM smoke test is labelled `AWAITING_GITHUB_RETEST`: the candidate is
copied into a protected staging workspace after verifying its source digest and
exact production-file diff. The candidate has **NOT** passed GitHub-first QA,
independent executor signing, GUI/tray application testing or host acceptance.
Nothing approves a release. The registered CLI does not auto-install a timer;
repeated calls may be scheduled using the existing Master QA service **only
after** an authorised installation and real VM end-to-end acceptance.

Example operator registration JSON (the digest must be measured from the exact
project source and never supplied by AI):

```json
{
  "schema": "devnet-master-auto-repair-registration-v1",
  "source_root": "/mnt/devnet-ai/projects/EXAMPLE",
  "workspace": "/mnt/devnet-ai/qa/EXAMPLE",
  "job": {
    "schema": "devnet-master-auto-repair-job-v1",
    "job_id": "EXAMPLE",
    "revision_sha256": "MEASURED_64_CHARACTER_SOURCE_DIGEST",
    "allowed_files": ["app.py"],
    "max_attempts": 2,
    "authorised_vm_diagnostic": true
  },
  "plan": {
    "schema": "devnet-test-plan-v1",
    "revision_sha256": "SAME_MEASURED_SOURCE_DIGEST",
    "tests": [
      {"name":"example_test","stage":"vm","kind":"python-unittest","target":"test_example.py","timeout":15}
    ]
  }
}
```

**Limits:** only bounded Python tests and small `.py/.txt/.json` source trees;
no application install/GUI automation yet; real VM transport acceptance pending.
Individual VM test passes are provisional until the protected independent
executor and exact GitHub run establish separately trusted provenance.
