Devnet Master QA Unified v0.2.6 — QA BLOCKED

Fixes VM integration failure: the standalone candidate loads its bundled deterministic validator; the original installed validator path remains the fallback for the existing host layout. No installed files are changed.

GitHub-first verification must run on THIS exact v0.2.6 ZIP before personal VM/host revision testing. Unit tests now execute the real controller master-status entrypoint and verify fail-closed behaviour when trusted execution infrastructure is absent.

The single controller still lacks operational autonomous job execution and a secured trusted executor. Full Master QA remains BLOCKED.
