import ast, hashlib, hmac, json, pathlib, unittest
from unittest.mock import patch
from pathlib import Path
SOURCE=Path(__file__).parent/'devnet-qa-automation/controller.py'
source=SOURCE.read_text()
tree=ast.parse(source)
selected=[node for node in tree.body if isinstance(node,ast.FunctionDef) and node.name in ('_master_digest','master_job_decision','master_job_gate_from_registered_files')]
assert len(selected)==3
namespace={'json':json,'Path':Path,'re':__import__('re'),'_master_hashlib':hashlib,'_master_hmac':hmac,'MASTER_GATE_SCHEMA':'devnet-master-job-gate-v2','MASTER_RESULTS':frozenset(('PASS','FAIL','BLOCKED','NOT_TESTED')),'MASTER_TRUSTED_RECEIPT_DIR':Path('/var/lib/devnet-master-qa/receipts'),'MASTER_TRUSTED_KEY':Path('/etc/devnet-master-qa/executor-hmac.key')}
exec(compile(ast.Module(body=selected,type_ignores=[]),str(SOURCE),'exec'),namespace)
gate=namespace['master_job_decision']
KEY=b'a'*32
REV='0'*64

def fixture(requirements=None, statuses=None):
    requirements=requirements if requirements is not None else ['package','vm','host','regression']
    stages={'github':[requirements[0]] if requirements else [],'vm':requirements[1:3],'host':requirements[3:]}; job={'schema':'devnet-master-job-v1','job_id':'example','revision_sha256':REV,'requirements':requirements,'stages':stages}
    statuses=statuses or {}
    checks={name:{'status':statuses.get(name,'PASS'),'execution_id':'run-'+name,'test_revision_sha256':REV,'log_sha256':'1'*64,'exit_code':0,'stage':next(k for k,v in stages.items() if name in v),'sequence':i+1} for i,name in enumerate(requirements)}
    rec={'schema':'devnet-trusted-executor-receipt-v1','job_id':'example','revision_sha256':REV,'requirements_sha256':hashlib.sha256(json.dumps({'requirements':requirements,'stages':stages},sort_keys=True,separators=(',',':')).encode()).hexdigest(),'executor':'devnet-trusted-executor-v1','checks':checks}
    sign(rec)
    return job,rec

def sign(rec):
    rec['signature']=hmac.new(KEY,json.dumps({k:v for k,v in rec.items() if k!='signature'},sort_keys=True,separators=(',',':'),ensure_ascii=True).encode(),hashlib.sha256).hexdigest()

class Tests(unittest.TestCase):
    def test_exact_complete_verified(self):
        a,b=fixture(); r=gate(a,b,KEY); self.assertEqual(r['decision'],'AI_TESTS_VERIFIED'); self.assertTrue(r['user_acceptance_ready']); self.assertFalse(r['release_approved'])
    def test_missing_test(self):
        a,b=fixture(); del b['checks']['vm']; sign(b); self.assertEqual(gate(a,b,KEY)['decision'],'BLOCKED')
    def test_extra_test(self):
        a,b=fixture(); b['checks']['new']={'status':'PASS'}; sign(b); self.assertEqual(gate(a,b,KEY)['decision'],'BLOCKED')
    def test_incomplete_statuses(self):
        for v in ('FAIL','BLOCKED','NOT_TESTED'):
            a,b=fixture(statuses={'vm':v}); self.assertFalse(gate(a,b,KEY)['user_acceptance_ready'])
    def test_forged_signature(self):
        a,b=fixture(); b['signature']='0'*64; self.assertEqual(gate(a,b,KEY)['decision'],'BLOCKED')
    def test_untrusted_key(self):
        a,b=fixture(); self.assertEqual(gate(a,b,b'b'*32)['decision'],'BLOCKED')
    def test_missing_key(self):
        a,b=fixture(); self.assertEqual(gate(a,b,None)['decision'],'BLOCKED')
    def test_old_revision(self):
        a,b=fixture(); a['revision_sha256']='2'*64; self.assertEqual(gate(a,b,KEY)['decision'],'BLOCKED')
    def test_stale_test_revision(self):
        a,b=fixture(); b['checks']['vm']['test_revision_sha256']='2'*64; sign(b); self.assertEqual(gate(a,b,KEY)['decision'],'BLOCKED')
    def test_revised_checklist(self):
        a,b=fixture(); a['requirements'].append('new_mandatory'); self.assertEqual(gate(a,b,KEY)['decision'],'BLOCKED')
    def test_duplicate_checklist(self):
        a,b=fixture(); a['requirements'].append('package'); self.assertEqual(gate(a,b,KEY)['decision'],'BLOCKED')
    def test_blank_checklist(self):
        a,b=fixture([]); self.assertEqual(gate(a,b,KEY)['decision'],'BLOCKED')
    def test_malformed_status(self):
        a,b=fixture(); b['checks']['vm']['status']='SUCCESS'; sign(b); self.assertEqual(gate(a,b,KEY)['decision'],'BLOCKED')
    def test_pass_nonzero_exit(self):
        a,b=fixture(); b['checks']['vm']['exit_code']=1; sign(b); self.assertEqual(gate(a,b,KEY)['decision'],'BLOCKED')
    def test_no_user_release_approval(self):
        a,b=fixture(); self.assertFalse(gate(a,b,KEY)['release_approved'])
    def test_missing_github_stage(self):
        a,b=fixture(); a['stages']['github']=[]; self.assertEqual(gate(a,b,KEY)['decision'],'BLOCKED')
    def test_vm_before_github(self):
        a,b=fixture(); b['checks']['package']['sequence']=8; sign(b); self.assertEqual(gate(a,b,KEY)['decision'],'BLOCKED')
    def test_host_before_vm(self):
        a,b=fixture(); b['checks']['host' if 'host' in b['checks'] else 'regression']['sequence']=2; sign(b); self.assertEqual(gate(a,b,KEY)['decision'],'BLOCKED')
    def test_github_failed_vm_was_run(self):
        a,b=fixture(statuses={'package':'FAIL'}); self.assertEqual(gate(a,b,KEY)['decision'],'BLOCKED')
    def test_omitted_stage_check(self):
        a,b=fixture(); a['stages']['vm'].remove('vm'); self.assertEqual(gate(a,b,KEY)['decision'],'BLOCKED')
    def test_forged_stage(self):
        a,b=fixture(); b['checks']['vm']['stage']='github'; sign(b); self.assertEqual(gate(a,b,KEY)['decision'],'BLOCKED')
    def test_duplicate_sequence(self):
        a,b=fixture(); b['checks']['vm']['sequence']=1; sign(b); self.assertEqual(gate(a,b,KEY)['decision'],'BLOCKED')
    def test_github_only_applicable_job(self):
        a,b=fixture(['package']); self.assertEqual(gate(a,b,KEY)['decision'],'AI_TESTS_VERIFIED')
    def test_original_controller_unchanged_functions(self):
        old=(Path(__file__).resolve().parent/'baseline/controller.py').read_text()
        for name in ('run_once','remote','classify','eligible_retry'):
            def segment(src):
                tree=ast.parse(src)
                return ast.dump(next(n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name==name))
            self.assertEqual(segment(old),segment(source))

if __name__=='__main__': unittest.main(verbosity=2)
