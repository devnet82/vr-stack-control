Devnet Master QA Unified v0.2.5 — QA BLOCKED

GitHub-first portability fix to v0.2.4: bundle the original controller reference and test it with an archive-relative path. Existing controller implementation is unchanged. This is not installed or approved.

Full GitHub, personal VM, host, persistent execution and trusted executor validations remain mandatory before handover.
