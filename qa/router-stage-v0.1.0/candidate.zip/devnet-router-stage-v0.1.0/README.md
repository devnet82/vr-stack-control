# Devnet Two-Model Router Stage v0.1.0 — QA BLOCKED

**Purpose:** an isolated, non-installing, two-phase Ollama routing proof. This is a replacement for testing a *specific* broken milestone, **not** a replacement for Devnet Master QA or the final autonomous development system.

## What it does

- Preserves the user's existing files and services. No installer, sudo, GitHub writes, VM changes, shell-command execution or release approval.
- Chooses `qwen3.5:9b` for a planning phase and `qwen3-coder:30b` for a coding-response phase; calls each **sequentially** through localhost Ollama `/api/generate`.
- Requests `think: false`, a 4,096-token context, and up to 256 generated tokens. Requires HTTP 200, the exact returned model name, `done: true`, and **nonempty generated text**. An empty `response` cannot be counted as successful, even if a model supplied a thinking field.
- Uses the installed, existing local `agent.py` gaming detector, plus explicit `stop-all` and `gaming-on` checks; fails closed if the detector cannot be loaded. Guards between model calls, **not while a request is already underway**.
- Reads actual `/proc/meminfo` `MemAvailable`. If exposed, also records AMD VRAM total/used from `/sys/class/drm`; otherwise reports VRAM as **unmeasured**, not invented. Fails closed below conservative RAM thresholds. Does **not** claim that it itself controls CPU/GPU offload; Ollama decides that.
- Stores checkpoint-like per-stage evidence atomically (0600) in `/mnt/devnet-ai/projects/devnet-orchestration/router-stage/latest.json`. Stores full generated text and model identity. It **does not** implement interrupted-job resume yet.
- Reports `ROUTER_STAGE_PASS_LIMITED` only if both phases genuinely finish. `master_qa` is always `BLOCKED_NOT_EXECUTED`.

## Local development QA (not a host integration or GitHub VM PASS)

`python3 -m unittest -v test_orchestrator` — 23/23 PASS in a separate isolated Python environment. Tests use **simulated Ollama HTTP responses** and injected guard/resource fixtures. No Ollama or CachyOS host integration occurred when the package was built.

The candidate itself **MUST** pass its applicable GitHub-first checks before execution on the user's host as required by Devnet Master QA. The attached files are not signed or released.

## How to ask local AI to use it

Provide this ZIP to the **existing OpenCode session**. Instruct it to verify its SHA256, unpack it **only** into `/mnt/devnet-ai/projects/devnet-orchestration/` in a new versioned directory, run source unit tests in a GitHub-hosted job first, then run the real `demo` against both installed Ollama models on the user's PC (only if not gaming and RAM threshold is met), and return the full genuine report. Do not alter the existing working `controller.py`, `agent.py`, services or SSH keys.

Example arguments for the AI's own terminal tool after GitHub-first passes: `python3 orchestrator.py demo --task 'Implement an add(a,b) function'`. `python3 orchestrator.py status` reports the last staged record. **User should not need to run these manually.**

## Still NOT TESTED / NOT IMPLEMENTED

Automatic arbitrary-task model classification, app code execution and repair, GitHub real app QA, installed KDE GUI and tray, upgrade and rollback, full job resume, between-request model unload proof, VR/gaming pause **during** an active HTTP inference, host/VM integration and independent Master QA acceptance. These must be completed in later revisions with the user's full applicable checklist. **Do not interpret this limited milestone as release approval.**
