import io
import json
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch
import orchestrator as o


class FakeReply:
    def __init__(self, payload, status=200):
        self.status=status
        self.data=json.dumps(payload).encode()
    def __enter__(self): return self
    def __exit__(self,*args): pass
    def read(self,n): return self.data[:n]


def backend(expected_model=None, text="READY", done=True, **kwargs):
    captured={}
    def fake_open(req, timeout):
        body=json.loads(req.data)
        captured.update(body)
        if expected_model is not None and body["model"] != expected_model:
            raise AssertionError("bad selection")
        value={"model":body["model"],"done":done,"response":text,
               "eval_count":12}
        value.update(kwargs)
        return FakeReply(value)
    return fake_open,captured


class RouterTests(unittest.TestCase):
    def setUp(self):
        self.temp=tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        self.root=Path(self.temp.name)

    def test_planner_actual_http_invocation(self):
        fake,seen=backend(o.PLANNER)
        response=o.call_model(o.PLANNER,"Plan a utility",opener=fake)
        self.assertEqual(response["returned_model"],o.PLANNER)
        self.assertEqual(response["response"],"READY")
        self.assertTrue(response["done"])
        self.assertFalse(seen["stream"])
        self.assertFalse(seen["think"])
        self.assertEqual(seen["options"]["num_ctx"],4096)

    def test_coder_actual_http_invocation(self):
        fake,seen=backend(o.CODER)
        response=o.call_model(o.CODER,"Implement it",opener=fake)
        self.assertEqual(response["requested_model"],o.CODER)
        self.assertEqual(seen["model"],o.CODER)

    def test_wrong_model_rejected(self):
        fake,_=backend(o.CODER,model=o.PLANNER)
        with self.assertRaisesRegex(o.Blocked,"actual model"):
            o.call_model(o.CODER,"Code",opener=fake)

    def test_empty_answer_rejected(self):
        fake,_=backend(o.PLANNER,text=" ")
        with self.assertRaisesRegex(o.Blocked,"empty generated"):
            o.call_model(o.PLANNER,"Plan",opener=fake)

    def test_thinking_only_rejected(self):
        fake,_=backend(o.PLANNER,text="",thinking="some thinking")
        with self.assertRaises(o.Blocked):
            o.call_model(o.PLANNER,"Plan",opener=fake)

    def test_incomplete_generation_rejected(self):
        fake,_=backend(o.PLANNER,done=False)
        with self.assertRaisesRegex(o.Blocked,"not complete"):
            o.call_model(o.PLANNER,"Plan",opener=fake)

    def test_error_generation_rejected(self):
        fake,_=backend(o.PLANNER,error="OOM")
        with self.assertRaisesRegex(o.Blocked,"returned an error"):
            o.call_model(o.PLANNER,"Plan",opener=fake)

    def test_nonallowlisted_model_rejected(self):
        with self.assertRaisesRegex(o.Blocked,"unapproved model"):
            o.call_model("unknown","Plan")

    def test_remote_host_rejected(self):
        with self.assertRaisesRegex(o.Blocked,"non-allowlisted"):
            o.call_model(o.PLANNER,"Plan",url="https://example.com/api/generate")

    def test_no_available_ram_rejected(self):
        with self.assertRaisesRegex(o.Blocked,"MemAvailable"):
            o.mem_available("MemTotal: 100 kB")

    def test_low_memory_blocks_coder(self):
        fake=self.root/"meminfo"
        fake.write_text("MemAvailable: 1000000 kB\n")
        with self.assertRaisesRegex(o.Blocked,"insufficient"):
            o.resources(o.CODER,mem_path=fake,drm_path=self.root)

    def test_real_memory_read_and_no_fake_vram(self):
        fake=self.root/"meminfo"
        fake.write_text("MemTotal: 35000000 kB\nMemAvailable: 20000000 kB\n")
        result=o.resources(o.CODER,mem_path=fake,drm_path=self.root)
        self.assertFalse(result["vram_measured"])
        self.assertFalse(result["cpu_offload_confirmed"])
        self.assertEqual(result["gpu_vram"],[])

    def test_stop_all_always_blocks(self):
        home=self.root/"home"
        flag=home/".config/devnet-qa-automation/stop-all"
        flag.parent.mkdir(parents=True)
        flag.touch()
        self.assertTrue(o.game_paused(home))

    def test_gaming_on_always_blocks(self):
        home=self.root/"home"
        flag=home/".config/devnet-qa-automation/gaming-on"
        flag.parent.mkdir(parents=True)
        flag.touch()
        self.assertTrue(o.game_paused(home))

    def test_missing_guard_fails_closed(self):
        self.assertTrue(o.game_paused(self.root))

    def test_real_guard_callable_used(self):
        guard=self.root/"agent.py"
        guard.write_text("def gaming_now():\n    return False\n")
        self.assertFalse(o.game_paused(self.root,guard))
        guard.write_text("def gaming_now():\n    return True\n")
        self.assertTrue(o.game_paused(self.root,guard))

    def test_staged_full_route_two_models_and_checkpoint(self):
        calls=[]
        def invoke(model,prompt):
            calls.append((model,prompt))
            return {"returned_model":model,"response":"PLAN" if model==o.PLANNER else "CODE",
                    "response_sha256":o.sha(("PLAN" if model==o.PLANNER else "CODE").encode()),
                    "done":True}
        result=o.demo("Make an add function",self.root,self.root,
                      gate=lambda:False,caller=invoke,
                      resource_fn=lambda model:{"measured":"fixture"})
        self.assertEqual([x[0] for x in calls],[o.PLANNER,o.CODER])
        self.assertIn("PLAN",calls[1][1])
        self.assertEqual(result["result"],"ROUTER_STAGE_PASS_LIMITED")
        self.assertEqual(result["master_qa"],"BLOCKED_NOT_EXECUTED")
        self.assertFalse(result["release_approved"])
        stored=json.loads((self.root/"latest.json").read_text())
        self.assertEqual(len(stored["stages"]),2)
        self.assertEqual([s["execution"] for s in stored["stages"]],
                         ["PASS_REAL_MODEL_RESPONSE"]*2)

    def test_resume_readback_unchanged_hashes(self):
        obj={"stages":[],"release_approved":False}
        path=self.root/"latest.json"
        o.atomic_json(path,obj)
        self.assertEqual(json.loads(path.read_text()),obj)
        self.assertEqual(path.stat().st_mode & 0o777,0o600)

    def test_failure_never_reports_router_pass(self):
        def fake(model,prompt):
            return {"returned_model":model,"response":"","done":True}
        with self.assertRaisesRegex(o.Blocked,"stage response is empty"):
            o.demo("Make function",self.root,self.root,
                   gate=lambda:False,caller=fake,resource_fn=lambda _: {})
        saved=json.loads((self.root/"latest.json").read_text())
        self.assertEqual(saved["result"],"INCOMPLETE")
        self.assertEqual(saved["stages"][0]["execution"],"BLOCKED")

    def test_mid_job_guard_blocks_without_coder_call(self):
        counter=[0]
        def gate():
            counter[0]+=1
            return counter[0]>=3
        calls=[]
        def fake(model,prompt):
            calls.append(model)
            return {"returned_model":model,"response":"PLAN","done":True}
        with self.assertRaisesRegex(o.Blocked,"game started"):
            o.demo("Make function",self.root,self.root,gate=gate,
                   caller=fake,resource_fn=lambda _: {})
        self.assertEqual(calls,[o.PLANNER])
        saved=json.loads((self.root/"latest.json").read_text())
        self.assertEqual(saved["result"],"INCOMPLETE")

    def test_missing_response_stage_not_success(self):
        def fake(model,prompt):
            return {"returned_model":"wrong","response":"looks good","done":True}
        with self.assertRaises(o.Blocked):
            o.demo("Make function",self.root,self.root,gate=lambda:False,
                   caller=fake,resource_fn=lambda _: {})
        self.assertEqual(json.loads((self.root/"latest.json").read_text())["result"],"INCOMPLETE")

    def test_no_task_or_too_long_rejected(self):
        for task in ("", "a"*1001):
            with self.assertRaises(o.Blocked):
                o.demo(task,self.root,self.root,gate=lambda:False)

    def test_state_symlink_rejected(self):
        destination=self.root/"outside.json"
        destination.write_text("do not change")
        symlink=self.root/"latest.json"
        symlink.symlink_to(destination)
        with self.assertRaisesRegex(o.Blocked,"symlink"):
            o.atomic_json(symlink,{"x":1})
        self.assertEqual(destination.read_text(),"do not change")


if __name__ == "__main__":
    unittest.main()
