#!/usr/bin/env python3
"""Devnet staged two-model inference router: NO install, shell tools, or release approval.

Strict stage: invoke BOTH local models for one task; verify returned model and
nonempty completed output, record append-like stage evidence via atomic checkpoints.
This is NOT a software-development agent or Master QA acceptance runner.
"""
from __future__ import annotations

import argparse
import datetime as dt
import fcntl
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import stat
import sys
import tempfile
import time
import urllib.error
import urllib.request
from typing import Callable

VERSION = "0.1.0"
PLANNER = "qwen3.5:9b"
CODER = "qwen3-coder:30b"
URL = "http://127.0.0.1:11434/api/generate"
MAX_RESPONSE_BYTES = 1_000_000
MODEL_MEMORY_MIN = {PLANNER: 6 * 1024**3, CODER: 10 * 1024**3}
DEFAULT_STATE = Path("/mnt/devnet-ai/projects/devnet-orchestration/router-stage")


class Blocked(Exception):
    pass


def sha(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def utc() -> str:
    return dt.datetime.now(dt.timezone.utc).isoformat(timespec="seconds")


def json_bytes(obj: dict) -> bytes:
    return (json.dumps(obj, sort_keys=True, indent=2, ensure_ascii=False) + "\n").encode()


def atomic_json(path: Path, obj: dict) -> None:
    path.parent.mkdir(mode=0o700, parents=True, exist_ok=True)
    if path.parent.is_symlink() or path.is_symlink():
        raise Blocked("state path is a symlink")
    fd, temp = tempfile.mkstemp(prefix=".write-", dir=path.parent)
    try:
        os.fchmod(fd, 0o600)
        with os.fdopen(fd, "wb") as handle:
            handle.write(json_bytes(obj))
            handle.flush()
            os.fsync(handle.fileno())
        os.replace(temp, path)
        dirfd = os.open(path.parent, os.O_DIRECTORY)
        try:
            os.fsync(dirfd)
        finally:
            os.close(dirfd)
    finally:
        if os.path.exists(temp):
            os.unlink(temp)


def mem_available(meminfo: str) -> int:
    entries = {}
    for line in meminfo.splitlines():
        if ":" in line:
            key, rest = line.split(":", 1)
            value = rest.strip().split()
            if len(value) == 2 and value[1] == "kB" and value[0].isdigit():
                entries[key] = int(value[0]) * 1024
    if "MemAvailable" not in entries:
        raise Blocked("MemAvailable missing: cannot establish RAM safety")
    return entries["MemAvailable"]


def resources(model: str, mem_path: Path = Path("/proc/meminfo"),
              drm_path: Path = Path("/sys/class/drm")) -> dict:
    try:
        available = mem_available(mem_path.read_text())
    except (OSError, UnicodeError) as error:
        raise Blocked("RAM measurement unavailable") from error
    if available < MODEL_MEMORY_MIN[model]:
        raise Blocked("insufficient MemAvailable for " + model)
    gpu = []
    for path in sorted(drm_path.glob("card*/device/mem_info_vram_total")):
        used = path.with_name("mem_info_vram_used")
        try:
            total_bytes = int(path.read_text().strip())
            used_bytes = int(used.read_text().strip())
            if 0 <= used_bytes <= total_bytes and total_bytes > 0:
                gpu.append({"total_bytes": total_bytes, "used_bytes": used_bytes})
        except (OSError, ValueError):
            pass
    return {"mem_available_bytes": available, "gpu_vram": gpu,
            "vram_measured": bool(gpu), "cpu_offload_confirmed": False}


def game_paused(home: Path, agent_path: Path | None = None) -> bool:
    flags = home / ".config" / "devnet-qa-automation"
    # STOP is always a STOP, never permission to proceed.
    if (flags / "stop-all").exists() or (flags / "gaming-on").exists():
        return True
    agent = agent_path or home / ".local/lib/devnet-qa-automation/agent.py"
    try:
        if agent.is_symlink() or not agent.is_file():
            return True
        modspec = importlib.util.spec_from_file_location("devnet_existing_game_guard", agent)
        if modspec is None or modspec.loader is None:
            return True
        module = importlib.util.module_from_spec(modspec)
        modspec.loader.exec_module(module)
        if not callable(getattr(module, "gaming_now", None)):
            return True
        return bool(module.gaming_now())
    except Exception:
        return True


def call_model(model: str, prompt: str, url: str = URL,
               opener: Callable | None = None) -> dict:
    if model not in (PLANNER, CODER):
        raise Blocked("unapproved model")
    # Absolutely no external Ollama or model endpoints.
    if url != URL and not getattr(call_model, "_test_local_override", False):
        raise Blocked("non-allowlisted Ollama endpoint")
    payload = {"model": model, "prompt": prompt, "stream": False,
               "think": False, "keep_alive": "30s",
               "options": {"num_ctx": 4096, "num_predict": 256, "temperature": 0}}
    request = urllib.request.Request(url, data=json.dumps(payload).encode(),
                                     headers={"Content-Type": "application/json"},
                                     method="POST")
    opener = opener or urllib.request.urlopen
    start = time.monotonic()
    try:
        with opener(request, timeout=240) as response:
            if response.status != 200:
                raise Blocked("Ollama HTTP " + str(response.status))
            raw = response.read(MAX_RESPONSE_BYTES + 1)
    except (urllib.error.URLError, TimeoutError, OSError) as error:
        raise Blocked("Ollama request failed: " + type(error).__name__) from error
    if not raw or len(raw) > MAX_RESPONSE_BYTES:
        raise Blocked("empty or oversized Ollama HTTP result")
    try:
        body = json.loads(raw)
    except (ValueError, UnicodeError) as error:
        raise Blocked("invalid Ollama JSON") from error
    if not isinstance(body, dict) or "error" in body:
        raise Blocked("Ollama returned an error")
    if body.get("model") != model:
        raise Blocked("actual model does not match requested model")
    if body.get("done") is not True:
        raise Blocked("Ollama generation not complete")
    output = body.get("response")
    if not isinstance(output, str) or not output.strip():
        raise Blocked("empty generated answer (thinking-only is not a PASS)")
    return {"requested_model": model, "returned_model": body["model"],
            "prompt_sha256": sha(prompt.encode()), "response_sha256": sha(output.encode()),
            "response": output, "wall_seconds": round(time.monotonic() - start, 3),
            "eval_count": body.get("eval_count"), "done": True}


def demo(task: str, state_dir: Path, home: Path,
         gate: Callable[[], bool] | None = None,
         caller: Callable[[str, str], dict] = call_model,
         resource_fn: Callable[[str], dict] = resources) -> dict:
    if not task or len(task) > 1000:
        raise Blocked("task must be between 1 and 1000 characters")
    gate = gate or (lambda: game_paused(home))
    if gate():
        raise Blocked("paused by game guard or stop-all")
    stages = (("plan", PLANNER,
               "Give a short plan (up to 80 words) for this isolated coding task. "
               "No shell commands or release claims. Task: " + task),
              ("implementation", CODER, None))
    state = {"schema": "devnet-two-model-routing-stage-v1", "version": VERSION,
             "utc": utc(), "task_sha256": sha(task.encode()),
             "stages": [], "master_qa": "BLOCKED_NOT_EXECUTED",
             "real_application_build": "NOT_TESTED", "release_approved": False,
             "result": "INCOMPLETE"}
    atomic_json(state_dir / "latest.json", state)
    for name, model, original_prompt in stages:
        if gate():
            raise Blocked("game started or stop-all enabled during job")
        snapshot = resource_fn(model)
        prompt = original_prompt
        if prompt is None:
            previous = state["stages"][0]["response"]
            prompt = ("Produce one concise pure Python add(a, b) implementation and "
                      "two simple unittest test cases. No external commands. "
                      "Respect this planning context:\n" + previous[:2500] + "\nTask: " + task)
        stage = {"phase": name, "model": model, "resources": snapshot,
                 "execution": "IN_PROGRESS"}
        state["stages"].append(stage)
        atomic_json(state_dir / "latest.json", state)
        try:
            generated = caller(model, prompt)
            if generated.get("returned_model") != model or generated.get("done") is not True:
                raise Blocked("stage result failed model identity/completion check")
            response = generated.get("response")
            if not isinstance(response, str) or not response.strip():
                raise Blocked("stage response is empty")
            stage.update(generated)
            stage["execution"] = "PASS_REAL_MODEL_RESPONSE"
        except (Blocked, OSError, ValueError) as error:
            stage["execution"] = "BLOCKED"
            stage["failure_type"] = type(error).__name__
            stage["failure_reason"] = str(error)[:240]
            atomic_json(state_dir / "latest.json", state)
            raise
        atomic_json(state_dir / "latest.json", state)
    state["result"] = "ROUTER_STAGE_PASS_LIMITED"
    state["utc_finished"] = utc()
    atomic_json(state_dir / "latest.json", state)
    return state


def main(argv=None) -> int:
    parser = argparse.ArgumentParser(description="Safe TWO-model Ollama routing demonstration, NOT full Master QA")
    parser.add_argument("action", choices=("demo", "status"))
    parser.add_argument("--task", default="Implement and test add(a, b) in a disposable project")
    parser.add_argument("--state-dir", type=Path, default=DEFAULT_STATE)
    args = parser.parse_args(argv)
    root = args.state_dir
    if root.is_symlink():
        print("BLOCKED: state directory must not be symlink", file=sys.stderr)
        return 2
    root.mkdir(parents=True, exist_ok=True, mode=0o700)
    os.chmod(root, 0o700)
    path = root / "latest.json"
    if args.action == "status":
        if path.is_file():
            print(path.read_text())
        else:
            print(json.dumps({"result": "NOT_TESTED", "master_qa": "BLOCKED_NOT_EXECUTED"}))
        return 0
    lock = root / "router.lock"
    if lock.is_symlink():
        print("BLOCKED: lock symlink", file=sys.stderr)
        return 2
    with lock.open("a+b") as handle:
        os.fchmod(handle.fileno(), 0o600)
        try:
            fcntl.flock(handle, fcntl.LOCK_EX | fcntl.LOCK_NB)
        except BlockingIOError:
            print("BLOCKED: job already running", file=sys.stderr)
            return 2
        try:
            result = demo(args.task, root, Path.home())
            print(json.dumps({"result": result["result"],
                              "models": [s["returned_model"] for s in result["stages"]],
                              "evidence": str(path), "master_qa": result["master_qa"]}))
            return 0
        except (Blocked, OSError, ValueError) as error:
            # Keep precise evidence including the last incomplete stage.
            print("BLOCKED:", error, file=sys.stderr)
            return 2


if __name__ == "__main__":
    raise SystemExit(main())
